--
-- PostgreSQL database dump
--

\restrict RjeUBRLuaKpoeGtdvFjjdS6p04vxoFzvSUChgNJlpLpNGoOkhwd3pKOnBsn7UBu

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_branches DROP CONSTRAINT IF EXISTS user_branches_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_branches DROP CONSTRAINT IF EXISTS user_branches_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_addresses DROP CONSTRAINT IF EXISTS user_addresses_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.product_categories DROP CONSTRAINT IF EXISTS product_categories_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_categories DROP CONSTRAINT IF EXISTS product_categories_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_branch_availability DROP CONSTRAINT IF EXISTS product_branch_availability_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_branch_availability DROP CONSTRAINT IF EXISTS product_branch_availability_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_branch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_order_id_orders_id_fk;
DROP INDEX IF EXISTS public.orders_guest_claim_token_unique;
DROP INDEX IF EXISTS public.orders_guest_access_token_unique;
DROP INDEX IF EXISTS public."IDX_session_expire";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_unique;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_unique;
ALTER TABLE IF EXISTS ONLY public.user_branches DROP CONSTRAINT IF EXISTS user_branches_user_id_branch_id_key;
ALTER TABLE IF EXISTS ONLY public.user_branches DROP CONSTRAINT IF EXISTS user_branches_pkey;
ALTER TABLE IF EXISTS ONLY public.user_addresses DROP CONSTRAINT IF EXISTS user_addresses_pkey;
ALTER TABLE IF EXISTS ONLY public.translations DROP CONSTRAINT IF EXISTS translations_pkey;
ALTER TABLE IF EXISTS ONLY public.themes DROP CONSTRAINT IF EXISTS themes_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_subdomain_key;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_custom_domain_key;
ALTER TABLE IF EXISTS ONLY public.store_settings DROP CONSTRAINT IF EXISTS store_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_pkey;
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS push_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.product_categories DROP CONSTRAINT IF EXISTS product_categories_product_id_category_id_key;
ALTER TABLE IF EXISTS ONLY public.product_categories DROP CONSTRAINT IF EXISTS product_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.product_branch_availability DROP CONSTRAINT IF EXISTS product_branch_availability_product_id_branch_id_key;
ALTER TABLE IF EXISTS ONLY public.product_branch_availability DROP CONSTRAINT IF EXISTS product_branch_availability_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.master_users DROP CONSTRAINT IF EXISTS master_users_pkey;
ALTER TABLE IF EXISTS ONLY public.master_users DROP CONSTRAINT IF EXISTS master_users_email_key;
ALTER TABLE IF EXISTS ONLY public.marketing_notifications DROP CONSTRAINT IF EXISTS marketing_notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.db_clusters DROP CONSTRAINT IF EXISTS db_clusters_pkey;
ALTER TABLE IF EXISTS ONLY public.db_clusters DROP CONSTRAINT IF EXISTS db_clusters_name_key;
ALTER TABLE IF EXISTS ONLY public.closed_dates DROP CONSTRAINT IF EXISTS closed_dates_pkey;
ALTER TABLE IF EXISTS ONLY public.closed_dates DROP CONSTRAINT IF EXISTS closed_dates_date_key;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_pkey;
ALTER TABLE IF EXISTS ONLY public.__drizzle_migrations DROP CONSTRAINT IF EXISTS __drizzle_migrations_pkey;
ALTER TABLE IF EXISTS ONLY drizzle.__drizzle_migrations DROP CONSTRAINT IF EXISTS __drizzle_migrations_pkey;
ALTER TABLE IF EXISTS public.user_branches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_addresses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tenants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.store_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.push_subscriptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_branch_availability ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.order_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketing_notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.db_clusters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.closed_dates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.branches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.__drizzle_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS drizzle.__drizzle_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_branches_id_seq;
DROP TABLE IF EXISTS public.user_branches;
DROP SEQUENCE IF EXISTS public.user_addresses_id_seq;
DROP TABLE IF EXISTS public.user_addresses;
DROP SEQUENCE IF EXISTS public.translations_id_seq;
DROP TABLE IF EXISTS public.translations;
DROP TABLE IF EXISTS public.themes;
DROP SEQUENCE IF EXISTS public.tenants_id_seq;
DROP TABLE IF EXISTS public.tenants;
DROP SEQUENCE IF EXISTS public.store_settings_id_seq;
DROP TABLE IF EXISTS public.store_settings;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.session;
DROP SEQUENCE IF EXISTS public.push_subscriptions_id_seq;
DROP TABLE IF EXISTS public.push_subscriptions;
DROP SEQUENCE IF EXISTS public.products_id_seq;
DROP TABLE IF EXISTS public.products;
DROP SEQUENCE IF EXISTS public.product_categories_id_seq;
DROP TABLE IF EXISTS public.product_categories;
DROP SEQUENCE IF EXISTS public.product_branch_availability_id_seq;
DROP TABLE IF EXISTS public.product_branch_availability;
DROP SEQUENCE IF EXISTS public.orders_id_seq;
DROP TABLE IF EXISTS public.orders;
DROP SEQUENCE IF EXISTS public.order_items_id_seq;
DROP TABLE IF EXISTS public.order_items;
DROP SEQUENCE IF EXISTS public.master_users_id_seq;
DROP TABLE IF EXISTS public.master_users;
DROP SEQUENCE IF EXISTS public.marketing_notifications_id_seq;
DROP TABLE IF EXISTS public.marketing_notifications;
DROP SEQUENCE IF EXISTS public.db_clusters_id_seq;
DROP TABLE IF EXISTS public.db_clusters;
DROP SEQUENCE IF EXISTS public.closed_dates_id_seq;
DROP TABLE IF EXISTS public.closed_dates;
DROP SEQUENCE IF EXISTS public.categories_id_seq;
DROP TABLE IF EXISTS public.categories;
DROP SEQUENCE IF EXISTS public.branches_id_seq;
DROP TABLE IF EXISTS public.branches;
DROP SEQUENCE IF EXISTS public.__drizzle_migrations_id_seq;
DROP TABLE IF EXISTS public.__drizzle_migrations;
DROP SEQUENCE IF EXISTS drizzle.__drizzle_migrations_id_seq;
DROP TABLE IF EXISTS drizzle.__drizzle_migrations;
DROP SCHEMA IF EXISTS drizzle;
--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: __drizzle_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE public.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.__drizzle_migrations_id_seq OWNED BY public.__drizzle_migrations.id;


--
-- Name: branches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    name_en character varying(255),
    name_he character varying(255),
    name_ar character varying(255)
);


ALTER TABLE public.branches OWNER TO postgres;

--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.branches_id_seq OWNER TO postgres;

--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    icon character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    name_en character varying(255),
    name_he character varying(255),
    name_ar character varying(255),
    description_en text,
    description_he text,
    description_ar text,
    image character varying(500)
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: closed_dates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.closed_dates (
    id integer NOT NULL,
    date character varying(10) NOT NULL,
    reason text NOT NULL,
    reason_en text,
    reason_he text,
    reason_ar text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.closed_dates OWNER TO postgres;

--
-- Name: closed_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.closed_dates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.closed_dates_id_seq OWNER TO postgres;

--
-- Name: closed_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.closed_dates_id_seq OWNED BY public.closed_dates.id;


--
-- Name: db_clusters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_clusters (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    connection_string text NOT NULL,
    max_tenants integer DEFAULT 100,
    current_tenants integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.db_clusters OWNER TO postgres;

--
-- Name: db_clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.db_clusters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.db_clusters_id_seq OWNER TO postgres;

--
-- Name: db_clusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.db_clusters_id_seq OWNED BY public.db_clusters.id;


--
-- Name: marketing_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_notifications (
    id integer NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    title_en text,
    message_en text,
    title_he text,
    message_he text,
    title_ar text,
    message_ar text,
    sent_count integer DEFAULT 0,
    created_by text NOT NULL,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.marketing_notifications OWNER TO postgres;

--
-- Name: marketing_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_notifications_id_seq OWNER TO postgres;

--
-- Name: marketing_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_notifications_id_seq OWNED BY public.marketing_notifications.id;


--
-- Name: master_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    role character varying(50) DEFAULT 'superadmin'::character varying NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.master_users OWNER TO postgres;

--
-- Name: master_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.master_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.master_users_id_seq OWNER TO postgres;

--
-- Name: master_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.master_users_id_seq OWNED BY public.master_users.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    price_per_kg numeric(10,2) NOT NULL,
    total_price numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    user_id character varying,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    customer_notes text,
    delivery_address text,
    payment_method character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    customer_phone character varying(20),
    requested_delivery_time timestamp without time zone,
    delivery_date character varying(20),
    delivery_time character varying(20),
    cancellation_reason text,
    guest_name character varying(255),
    guest_email character varying(255),
    guest_phone character varying(20),
    delivery_fee numeric(10,2) DEFAULT 0.00,
    guest_access_token character varying(255),
    guest_access_token_expires timestamp without time zone,
    guest_claim_token character varying(255),
    order_language character varying(5) DEFAULT 'ru'::character varying,
    branch_id integer
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: product_branch_availability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_branch_availability (
    id integer NOT NULL,
    product_id integer NOT NULL,
    branch_id integer NOT NULL,
    is_available boolean DEFAULT true NOT NULL,
    stock_status character varying DEFAULT 'in_stock'::character varying NOT NULL,
    availability_status character varying DEFAULT 'available'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.product_branch_availability OWNER TO postgres;

--
-- Name: product_branch_availability_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_branch_availability_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_branch_availability_id_seq OWNER TO postgres;

--
-- Name: product_branch_availability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_branch_availability_id_seq OWNED BY public.product_branch_availability.id;


--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categories (
    id integer NOT NULL,
    product_id integer NOT NULL,
    category_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.product_categories OWNER TO postgres;

--
-- Name: product_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_categories_id_seq OWNER TO postgres;

--
-- Name: product_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_categories_id_seq OWNED BY public.product_categories.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    price_per_kg numeric(10,2) NOT NULL,
    image_url character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    stock_status character varying DEFAULT 'in_stock'::character varying NOT NULL,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    is_available boolean DEFAULT true NOT NULL,
    price numeric(10,2) NOT NULL,
    unit character varying(20) DEFAULT '100g'::character varying NOT NULL,
    is_special_offer boolean DEFAULT false NOT NULL,
    discount_type character varying,
    discount_value numeric(10,2),
    availability_status character varying(50) DEFAULT 'available'::character varying NOT NULL,
    name_en character varying(255),
    name_he character varying(255),
    name_ar character varying(255),
    description_en text,
    description_he text,
    description_ar text,
    image_url_en character varying(500),
    image_url_he character varying(500),
    image_url_ar character varying(500),
    barcode character varying(50),
    ingredients text,
    ingredients_en text,
    ingredients_he text,
    ingredients_ar text,
    CONSTRAINT products_availability_status_check CHECK (((availability_status)::text = ANY (ARRAY[('available'::character varying)::text, ('out_of_stock_today'::character varying)::text, ('completely_unavailable'::character varying)::text])))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.push_subscriptions (
    id integer NOT NULL,
    user_id text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    user_agent text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.push_subscriptions OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_subscriptions_id_seq OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: store_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_settings (
    id integer NOT NULL,
    store_name character varying(255) NOT NULL,
    store_description text,
    contact_phone character varying(50),
    contact_email character varying(255),
    address text,
    working_hours jsonb,
    delivery_fee numeric(10,2) DEFAULT 15.00,
    free_delivery_from numeric(10,2) DEFAULT 50.00,
    payment_methods jsonb,
    is_delivery_enabled boolean DEFAULT true,
    is_pickup_enabled boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT now(),
    min_delivery_time_hours integer DEFAULT 2,
    max_delivery_time_days integer DEFAULT 4,
    logo_url character varying(500),
    delivery_info text,
    payment_info text,
    about_us_photos jsonb,
    welcome_title character varying(255),
    banner_image character varying(500),
    discount_badge_text character varying(50) DEFAULT 'Скидка'::character varying,
    show_banner_image boolean DEFAULT true,
    show_title_description boolean DEFAULT true,
    show_info_blocks boolean DEFAULT true,
    show_special_offers boolean DEFAULT true,
    show_category_menu boolean DEFAULT true,
    week_start_day character varying(10) DEFAULT 'monday'::character varying,
    bottom_banner1_url character varying(500),
    bottom_banner1_link character varying(500),
    bottom_banner2_url character varying(500),
    bottom_banner2_link character varying(500),
    show_bottom_banners boolean DEFAULT false,
    default_items_per_page integer DEFAULT 10,
    cancellation_reasons jsonb,
    header_html text,
    footer_html text,
    show_whatsapp_chat boolean DEFAULT false,
    whatsapp_phone_number character varying(20),
    whatsapp_default_message text,
    show_cart_banner boolean DEFAULT false,
    cart_banner_type character varying DEFAULT 'text'::character varying,
    cart_banner_image character varying(500),
    cart_banner_text text,
    cart_banner_bg_color character varying(7) DEFAULT '#f97316'::character varying,
    cart_banner_text_color character varying(7) DEFAULT '#ffffff'::character varying,
    auth_page_title character varying(255) DEFAULT 'Добро пожаловать в eDAHouse'::character varying,
    auth_page_subtitle text DEFAULT 'Готовые блюда высокого качества с доставкой на дом'::text,
    auth_page_feature1 character varying(255) DEFAULT 'Свежие готовые блюда каждый день'::character varying,
    auth_page_feature2 character varying(255) DEFAULT 'Быстрая доставка в удобное время'::character varying,
    auth_page_feature3 character varying(255) DEFAULT 'Широкий выбор блюд на любой вкус'::character varying,
    worker_permissions jsonb DEFAULT '{"canViewUsers": false, "canManageUsers": false, "canManageOrders": true, "canViewSettings": false, "canManageProducts": true, "canManageSettings": false, "canManageCategories": true}'::jsonb,
    default_language character varying(5) DEFAULT 'ru'::character varying,
    enabled_languages jsonb DEFAULT '["ru", "en", "he"]'::jsonb,
    info_blocks_position character varying(10) DEFAULT 'top'::character varying,
    header_style character varying DEFAULT 'classic'::character varying,
    banner_button_text character varying(100) DEFAULT 'Смотреть каталог'::character varying,
    banner_button_link character varying(500) DEFAULT '#categories'::character varying,
    modern_block1_icon character varying(50),
    modern_block1_text character varying(255),
    modern_block2_icon character varying(50),
    modern_block2_text character varying(255),
    modern_block3_icon character varying(50),
    modern_block3_text character varying(255),
    banner_image_url character varying(500),
    store_name_ar text,
    store_description_ar text,
    welcome_title_ar text,
    welcome_subtitle_ar text,
    delivery_info_ar text,
    store_name_he text,
    welcome_title_he text,
    store_description_he text,
    delivery_info_he text,
    store_name_en text,
    welcome_title_en text,
    store_description_en text,
    delivery_info_en text,
    about_text_ru text,
    about_text_en text,
    about_text_he text,
    about_text_ar text,
    banner_button_text_ru character varying(100),
    banner_button_text_en character varying(100),
    banner_button_text_he character varying(100),
    banner_button_text_ar character varying(100),
    discount_badge_text_en character varying(50),
    discount_badge_text_he character varying(50),
    discount_badge_text_ar character varying(50),
    whatsapp_default_message_en text,
    whatsapp_default_message_he text,
    whatsapp_default_message_ar text,
    cart_banner_text_en text,
    cart_banner_text_he text,
    cart_banner_text_ar text,
    payment_info_en text,
    payment_info_he text,
    payment_info_ar text,
    contact_phone_en character varying(50),
    contact_phone_he character varying(50),
    contact_phone_ar character varying(50),
    contact_email_en character varying(255),
    contact_email_he character varying(255),
    contact_email_ar character varying(255),
    address_en text,
    address_he text,
    address_ar text,
    pwa_icon character varying(500),
    pwa_name character varying(100) DEFAULT 'eDAHouse'::character varying,
    pwa_description text DEFAULT 'Готовые блюда с доставкой'::text,
    pwa_name_en character varying(100),
    pwa_description_en text,
    pwa_name_he character varying(100),
    pwa_description_he text,
    pwa_name_ar character varying(100),
    pwa_description_ar text,
    logo_url_en character varying(500) DEFAULT ''::character varying,
    logo_url_he character varying(500) DEFAULT ''::character varying,
    logo_url_ar character varying(500) DEFAULT ''::character varying,
    banner_image_url_en character varying(500) DEFAULT ''::character varying,
    banner_image_url_he character varying(500) DEFAULT ''::character varying,
    banner_image_url_ar character varying(500) DEFAULT ''::character varying,
    cart_banner_image_en character varying(500) DEFAULT ''::character varying,
    cart_banner_image_he character varying(500) DEFAULT ''::character varying,
    cart_banner_image_ar character varying(500) DEFAULT ''::character varying,
    pwa_icon_en character varying(500) DEFAULT ''::character varying,
    pwa_icon_he character varying(500) DEFAULT ''::character varying,
    pwa_icon_ar character varying(500) DEFAULT ''::character varying,
    barcode_system_enabled boolean DEFAULT false,
    barcode_product_code_start integer DEFAULT 2,
    barcode_product_code_end integer DEFAULT 5,
    barcode_weight_start integer DEFAULT 6,
    barcode_weight_end integer DEFAULT 10,
    barcode_weight_unit character varying(20) DEFAULT 'grams'::character varying,
    enable_admin_order_creation boolean DEFAULT true,
    slider_autoplay boolean DEFAULT true,
    slider_speed integer DEFAULT 5000,
    slider_effect character varying(20) DEFAULT 'fade'::character varying,
    slide1_image character varying(500),
    slide1_title character varying(255),
    slide1_subtitle text,
    slide1_button_text character varying(100),
    slide1_button_link character varying(500),
    slide1_text_position character varying(20) DEFAULT 'left'::character varying,
    slide2_image character varying(500),
    slide2_title character varying(255),
    slide2_subtitle text,
    slide2_button_text character varying(100),
    slide2_button_link character varying(500),
    slide2_text_position character varying(20) DEFAULT 'left'::character varying,
    slide3_image character varying(500),
    slide3_title character varying(255),
    slide3_subtitle text,
    slide3_button_text character varying(100),
    slide3_button_link character varying(500),
    slide3_text_position character varying(20) DEFAULT 'left'::character varying,
    slide4_image character varying(500),
    slide4_title character varying(255),
    slide4_subtitle text,
    slide4_button_text character varying(100),
    slide4_button_link character varying(500),
    slide4_text_position character varying(20) DEFAULT 'left'::character varying,
    slide5_image character varying(500),
    slide5_title character varying(255),
    slide5_subtitle text,
    slide5_button_text character varying(100),
    slide5_button_link character varying(500),
    slide5_text_position character varying(20) DEFAULT 'left'::character varying,
    slide1_title_en character varying(255),
    slide1_subtitle_en text,
    slide1_button_text_en character varying(100),
    slide1_title_he character varying(255),
    slide1_subtitle_he text,
    slide1_button_text_he character varying(100),
    slide1_title_ar character varying(255),
    slide1_subtitle_ar text,
    slide1_button_text_ar character varying(100),
    slide2_title_en character varying(255),
    slide2_subtitle_en text,
    slide2_button_text_en character varying(100),
    slide2_title_he character varying(255),
    slide2_subtitle_he text,
    slide2_button_text_he character varying(100),
    slide2_title_ar character varying(255),
    slide2_subtitle_ar text,
    slide2_button_text_ar character varying(100),
    slide3_title_en character varying(255),
    slide3_subtitle_en text,
    slide3_button_text_en character varying(100),
    slide3_title_he character varying(255),
    slide3_subtitle_he text,
    slide3_button_text_he character varying(100),
    slide3_title_ar character varying(255),
    slide3_subtitle_ar text,
    slide3_button_text_ar character varying(100),
    slide4_title_en character varying(255),
    slide4_subtitle_en text,
    slide4_button_text_en character varying(100),
    slide4_title_he character varying(255),
    slide4_subtitle_he text,
    slide4_button_text_he character varying(100),
    slide4_title_ar character varying(255),
    slide4_subtitle_ar text,
    slide4_button_text_ar character varying(100),
    slide5_title_en character varying(255),
    slide5_subtitle_en text,
    slide5_button_text_en character varying(100),
    slide5_title_he character varying(255),
    slide5_subtitle_he text,
    slide5_button_text_he character varying(100),
    slide5_title_ar character varying(255),
    slide5_subtitle_ar text,
    slide5_button_text_ar character varying(100),
    modern_block1_text_en character varying(255),
    modern_block2_text_en character varying(255),
    modern_block3_text_en character varying(255),
    modern_block1_text_he character varying(255),
    modern_block2_text_he character varying(255),
    modern_block3_text_he character varying(255),
    modern_block1_text_ar character varying(255),
    modern_block2_text_ar character varying(255),
    modern_block3_text_ar character varying(255),
    email_notifications_enabled boolean DEFAULT false,
    order_notification_email character varying(255),
    order_notification_from_name character varying(255) DEFAULT 'eDAHouse Store'::character varying,
    order_notification_from_email character varying(255) DEFAULT 'noreply@edahouse.com'::character varying,
    smtp_host character varying(255),
    smtp_port integer DEFAULT 587,
    smtp_secure boolean DEFAULT false,
    smtp_user character varying(255),
    smtp_password character varying(255),
    sendgrid_api_key character varying(255),
    use_sendgrid boolean DEFAULT false,
    delivery_time_mode character varying(20) DEFAULT 'hours'::character varying,
    facebook_pixel_id character varying(50),
    facebook_conversions_api_enabled boolean DEFAULT false,
    facebook_access_token character varying(500),
    delivery_hours jsonb,
    category_display_style character varying(20) DEFAULT 'default'::character varying,
    mobile_quick_buttons jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT store_settings_delivery_time_mode_check CHECK (((delivery_time_mode)::text = ANY (ARRAY[('hours'::character varying)::text, ('half_day'::character varying)::text, ('disabled'::character varying)::text]))),
    CONSTRAINT store_settings_header_style_check CHECK (((header_style)::text = ANY (ARRAY[('classic'::character varying)::text, ('modern'::character varying)::text, ('minimal'::character varying)::text, ('slider'::character varying)::text]))),
    CONSTRAINT store_settings_info_blocks_position_check CHECK (((info_blocks_position)::text = ANY (ARRAY[('top'::character varying)::text, ('bottom'::character varying)::text])))
);


ALTER TABLE public.store_settings OWNER TO postgres;

--
-- Name: store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.store_settings_id_seq OWNER TO postgres;

--
-- Name: store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_settings_id_seq OWNED BY public.store_settings.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id integer NOT NULL,
    subdomain character varying(100) NOT NULL,
    custom_domain character varying(255),
    db_cluster character varying(50) NOT NULL,
    store_name character varying(255),
    is_active boolean DEFAULT true,
    plan_type character varying(50) DEFAULT 'trial'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    contact_email character varying(255),
    contact_phone character varying(50),
    subscription_status character varying(50) DEFAULT 'trial'::character varying,
    subscription_start_date timestamp without time zone DEFAULT now(),
    subscription_end_date timestamp without time zone,
    last_payment_date timestamp without time zone,
    payment_method character varying(50),
    notes text
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tenants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: themes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.themes (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT false,
    primary_color text NOT NULL,
    primary_dark_color text NOT NULL,
    primary_light_color text NOT NULL,
    secondary_color text NOT NULL,
    accent_color text NOT NULL,
    success_color text NOT NULL,
    success_light_color text NOT NULL,
    warning_color text NOT NULL,
    warning_light_color text NOT NULL,
    error_color text NOT NULL,
    error_light_color text NOT NULL,
    info_color text NOT NULL,
    info_light_color text NOT NULL,
    white_color text NOT NULL,
    gray50_color text NOT NULL,
    gray100_color text NOT NULL,
    gray200_color text NOT NULL,
    gray300_color text NOT NULL,
    gray400_color text NOT NULL,
    gray500_color text NOT NULL,
    gray600_color text NOT NULL,
    gray700_color text NOT NULL,
    gray800_color text NOT NULL,
    gray900_color text NOT NULL,
    font_family_primary text NOT NULL,
    font_family_secondary text NOT NULL,
    primary_shadow text NOT NULL,
    success_shadow text NOT NULL,
    warning_shadow text NOT NULL,
    error_shadow text NOT NULL,
    info_shadow text NOT NULL,
    gray_shadow text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    primary_text_color character varying(20) DEFAULT 'hsl(0, 0%, 100%)'::character varying NOT NULL,
    tomorrow_shadow character varying(100) DEFAULT '0 4px 14px 0 rgba(147, 51, 234, 0.3)'::character varying NOT NULL,
    tomorrow_color character varying(20) DEFAULT 'hsl(262, 83%, 58%)'::character varying NOT NULL,
    tomorrow_light_color character varying(20) DEFAULT 'hsl(262, 83%, 96%)'::character varying NOT NULL,
    out_of_stock_color character varying(20) DEFAULT 'hsl(0, 84%, 60%)'::character varying NOT NULL,
    tomorrow_dark_color character varying(20) DEFAULT 'hsl(262, 83%, 48%)'::character varying NOT NULL,
    working_hours_icon_color character varying(20) DEFAULT 'hsl(220, 91%, 54%)'::character varying,
    contacts_icon_color character varying(20) DEFAULT 'hsl(142, 76%, 36%)'::character varying,
    payment_delivery_icon_color character varying(20) DEFAULT 'hsl(262, 83%, 58%)'::character varying,
    header_style character varying(20) DEFAULT 'classic'::character varying,
    banner_button_text character varying(100) DEFAULT 'Смотреть каталог'::character varying,
    banner_button_link character varying(200) DEFAULT '#categories'::character varying,
    modern_block1_icon character varying(50) DEFAULT ''::character varying,
    modern_block1_text character varying(200) DEFAULT ''::character varying,
    modern_block2_icon character varying(50) DEFAULT ''::character varying,
    modern_block2_text character varying(200) DEFAULT ''::character varying,
    modern_block3_icon character varying(50) DEFAULT ''::character varying,
    modern_block3_text character varying(200) DEFAULT ''::character varying,
    show_banner_image boolean DEFAULT true,
    show_title_description boolean DEFAULT true,
    show_info_blocks boolean DEFAULT true,
    info_blocks_position character varying(10) DEFAULT 'top'::character varying,
    show_prices boolean DEFAULT true,
    show_product_images boolean DEFAULT true,
    show_cart boolean DEFAULT true,
    show_special_offers boolean DEFAULT true,
    show_category_menu boolean DEFAULT true,
    show_whatsapp_chat boolean DEFAULT true,
    whatsapp_phone character varying(20) DEFAULT ''::character varying,
    whatsapp_message text DEFAULT 'Здравствуйте! У меня есть вопрос по заказу.'::text,
    logo_url character varying(500) DEFAULT ''::character varying,
    banner_image_url character varying(500) DEFAULT ''::character varying,
    show_cart_banner boolean DEFAULT false,
    cart_banner_type character varying(10) DEFAULT 'text'::character varying,
    cart_banner_image character varying(500) DEFAULT ''::character varying,
    cart_banner_text text DEFAULT ''::text,
    cart_banner_bg_color character varying(7) DEFAULT '#f97316'::character varying,
    cart_banner_text_color character varying(7) DEFAULT '#ffffff'::character varying,
    show_bottom_banners boolean DEFAULT false,
    bottom_banner1_url character varying(500) DEFAULT ''::character varying,
    bottom_banner1_link character varying(500) DEFAULT ''::character varying,
    bottom_banner2_url character varying(500) DEFAULT ''::character varying,
    bottom_banner2_link character varying(500) DEFAULT ''::character varying,
    name_en character varying(100),
    name_he character varying(100),
    name_ar character varying(100),
    description_en text,
    description_he text,
    description_ar text,
    banner_button_text_en character varying(100),
    banner_button_text_he character varying(100),
    banner_button_text_ar character varying(100),
    logourl_en text,
    logourl_he text,
    logourl_ar text,
    bannerimageurl_en text,
    bannerimageurl_he text,
    bannerimageurl_ar text,
    cartbannerimage_en text,
    cartbannerimage_he text,
    cartbannerimage_ar text,
    bottombanner1url_en text,
    bottombanner1url_he text,
    bottombanner1url_ar text,
    bottombanner2url_en text,
    bottombanner2url_he text,
    bottombanner2url_ar text,
    logo_url_en text DEFAULT ''::text,
    logo_url_he text DEFAULT ''::text,
    logo_url_ar text DEFAULT ''::text,
    banner_image_url_en text DEFAULT ''::text,
    banner_image_url_he text DEFAULT ''::text,
    banner_image_url_ar text DEFAULT ''::text,
    cart_banner_image_en text DEFAULT ''::text,
    cart_banner_image_he text DEFAULT ''::text,
    cart_banner_image_ar text DEFAULT ''::text,
    bottom_banner1_url_en text DEFAULT ''::text,
    bottom_banner1_url_he text DEFAULT ''::text,
    bottom_banner1_url_ar text DEFAULT ''::text,
    bottom_banner2_url_en text DEFAULT ''::text,
    bottom_banner2_url_he text DEFAULT ''::text,
    bottom_banner2_url_ar text DEFAULT ''::text,
    slider_autoplay boolean DEFAULT true,
    slider_speed integer DEFAULT 5000,
    slider_effect character varying(10) DEFAULT 'fade'::character varying,
    slide1_image character varying(500),
    slide1_title character varying(255),
    slide1_subtitle text,
    slide1_button_text character varying(100),
    slide1_button_link character varying(500),
    slide1_text_position character varying(10) DEFAULT 'left'::character varying,
    slide2_image character varying(500),
    slide2_title character varying(255),
    slide2_subtitle text,
    slide2_button_text character varying(100),
    slide2_button_link character varying(500),
    slide2_text_position character varying(10) DEFAULT 'left'::character varying,
    slide3_image character varying(500),
    slide3_title character varying(255),
    slide3_subtitle text,
    slide3_button_text character varying(100),
    slide3_button_link character varying(500),
    slide3_text_position character varying(10) DEFAULT 'left'::character varying,
    slide4_image character varying(500),
    slide4_title character varying(255),
    slide4_subtitle text,
    slide4_button_text character varying(100),
    slide4_button_link character varying(500),
    slide4_text_position character varying(10) DEFAULT 'left'::character varying,
    slide5_image character varying(500),
    slide5_title character varying(255),
    slide5_subtitle text,
    slide5_button_text character varying(100),
    slide5_button_link character varying(500),
    slide5_text_position character varying(10) DEFAULT 'left'::character varying,
    whatsapp_message_en text DEFAULT ''::text,
    whatsapp_message_he text DEFAULT ''::text,
    whatsapp_message_ar text DEFAULT ''::text,
    cart_banner_text_en text DEFAULT ''::text,
    cart_banner_text_he text DEFAULT ''::text,
    cart_banner_text_ar text DEFAULT ''::text,
    splash_bg_color character varying(20) DEFAULT 'hsl(0, 0%, 100%)'::character varying NOT NULL,
    category_display_style character varying(20) DEFAULT 'default'::character varying
);


ALTER TABLE public.themes OWNER TO postgres;

--
-- Name: translations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.translations (
    id integer NOT NULL,
    entity_type character varying NOT NULL,
    entity_id character varying NOT NULL,
    field character varying NOT NULL,
    language character varying(2) NOT NULL,
    value text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.translations OWNER TO postgres;

--
-- Name: translations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.translations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.translations_id_seq OWNER TO postgres;

--
-- Name: translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.translations_id_seq OWNED BY public.translations.id;


--
-- Name: user_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_addresses (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    label character varying(100) NOT NULL,
    address text NOT NULL,
    is_default boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_addresses OWNER TO postgres;

--
-- Name: user_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_addresses_id_seq OWNER TO postgres;

--
-- Name: user_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_addresses_id_seq OWNED BY public.user_addresses.id;


--
-- Name: user_branches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_branches (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    branch_id integer NOT NULL
);


ALTER TABLE public.user_branches OWNER TO postgres;

--
-- Name: user_branches_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_branches_id_seq OWNER TO postgres;

--
-- Name: user_branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_branches_id_seq OWNED BY public.user_branches.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    role character varying DEFAULT 'customer'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    phone character varying,
    default_address text,
    password character varying,
    password_reset_token character varying,
    password_reset_expires timestamp without time zone,
    username character varying(50) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('public.__drizzle_migrations_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: closed_dates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.closed_dates ALTER COLUMN id SET DEFAULT nextval('public.closed_dates_id_seq'::regclass);


--
-- Name: db_clusters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_clusters ALTER COLUMN id SET DEFAULT nextval('public.db_clusters_id_seq'::regclass);


--
-- Name: marketing_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_notifications ALTER COLUMN id SET DEFAULT nextval('public.marketing_notifications_id_seq'::regclass);


--
-- Name: master_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_users ALTER COLUMN id SET DEFAULT nextval('public.master_users_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: product_branch_availability id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_branch_availability ALTER COLUMN id SET DEFAULT nextval('public.product_branch_availability_id_seq'::regclass);


--
-- Name: product_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories ALTER COLUMN id SET DEFAULT nextval('public.product_categories_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: store_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_settings ALTER COLUMN id SET DEFAULT nextval('public.store_settings_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: translations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.translations ALTER COLUMN id SET DEFAULT nextval('public.translations_id_seq'::regclass);


--
-- Name: user_addresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_addresses ALTER COLUMN id SET DEFAULT nextval('public.user_addresses_id_seq'::regclass);


--
-- Name: user_branches id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_branches ALTER COLUMN id SET DEFAULT nextval('public.user_branches_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
\.


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	0000_even_machine_man	1761916027245
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.branches (id, name, is_active, sort_order, created_at, updated_at, name_en, name_he, name_ar) FROM stdin;
1	Хайфа	t	1	2026-04-13 18:23:52.186166	2026-04-13 18:23:52.186166	\N	\N	\N
2	Крайот	t	2	2026-04-13 18:24:37.982246	2026-04-13 18:24:37.982246	\N	\N	\N
3	Тель Авив	t	3	2026-04-13 18:34:18.004408	2026-04-13 18:34:18.004408	\N	\N	\N
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, icon, is_active, sort_order, created_at, updated_at, name_en, name_he, name_ar, description_en, description_he, description_ar, image) FROM stdin;
49	Гарниры	Каши, картофель, овощи	🍚	t	3	2025-06-17 18:46:47.834072	2025-07-04 19:52:46.066		גרירים			דייסה, תפוחי אדמה, ירקות		\N
50	Супы	Первые блюда	🍲	t	4	2025-06-17 18:46:47.834072	2025-07-04 19:52:46.111		מרקים			מנות ראשונות		\N
51	Выпечка и десерты	Блинчики, сырники, корндоги	🥞	t	5	2025-06-17 18:46:47.834072	2025-07-04 19:52:46.156		אפייה וקינוחים			לביבות, עוגות גבינה, קורנדוגי		\N
52	Пирожки	Свежие пирожки с разными начинками	🥟	t	6	2025-06-17 18:46:47.834072	2025-07-04 19:52:46.201		פשטידות			פשטידות טריות עם מילויים שונים		\N
48	Горячие блюда	Основные блюда на развес	🍖	t	2	2025-06-17 18:46:47.834072	2025-07-06 15:15:55.908		מנות חמות			מנות בסיסיות לספינה		\N
47	Салаты	Свежие салаты и закуски	🥗	t	1	2025-06-17 18:46:47.834072	2026-05-11 15:22:41.608		סלטים			סלטים וחטיפים טריים		
\.


--
-- Data for Name: closed_dates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.closed_dates (id, date, reason, reason_en, reason_he, reason_ar, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: db_clusters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.db_clusters (id, name, connection_string, max_tenants, current_tenants, is_active, created_at) FROM stdin;
2	cluster_1	postgresql://neondb_owner:npg_2cWXYsP4rgEU@ep-black-bonus-a6ft1m1n.us-west-2.aws.neon.tech/neondb?sslmode=require	100	0	t	2025-10-27 12:05:43.748745
\.


--
-- Data for Name: marketing_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_notifications (id, title, message, title_en, message_en, title_he, message_he, title_ar, message_ar, sent_count, created_by, sent_at, created_at) FROM stdin;
1	Привет	Тест	\N	\N	\N	\N	\N	\N	0	admin	2025-07-02 00:13:10.549	2025-07-02 00:13:10.567794
2	Все привет	У нас акция -30%	\N	\N	\N	\N	\N	\N	0	admin	2025-07-02 00:39:47.022	2025-07-02 00:39:47.040835
3	тест	уведомления от еда	\N	\N	\N	\N	\N	\N	4	admin	2025-07-02 00:41:04.046	2025-07-02 00:41:04.063921
4	Привет Мир	Скидка на рога и копыта 300%	\N	\N	\N	\N	\N	\N	4	admin	2025-07-02 01:12:55.819	2025-07-02 01:12:55.837683
5	тестовое	Вот такая скидка!	\N	\N	\N	\N	\N	\N	4	admin	2025-07-02 01:17:15.527	2025-07-02 01:17:15.545798
6	еще одно	Леша или спать	\N	\N	\N	\N	\N	\N	1	admin	2025-07-02 01:20:54.133	2025-07-02 01:20:54.151947
7	еще одна проверка	отправляем рекламное сообщение	\N	\N	\N	\N	\N	\N	1	admin	2025-07-02 01:22:47.851	2025-07-02 01:22:47.868641
8	еще	одно	\N	\N	\N	\N	\N	\N	1	admin	2025-07-02 01:23:03.239	2025-07-02 01:23:03.256465
9	Test	Test message	\N	\N	\N	\N	\N	\N	2	test	2025-07-02 01:33:43.853	2025-07-02 01:33:44.836203
10	Акция	Все салаты -15%	\N	\N	\N	\N	\N	\N	2	admin	2025-07-02 01:34:57.56	2025-07-02 01:34:57.578623
11	Тест модального окна	Проверка отображения уведомления в модальном окне	\N	\N	\N	\N	\N	\N	2	test	2025-07-02 01:39:46.673	2025-07-02 01:39:46.691075
12	тест	тут будет информация	\N	\N	\N	\N	\N	\N	2	admin	2025-07-02 01:41:23.689	2025-07-02 01:41:23.707226
13	Тест модального окна	Проверка логирования и отображения модального окна	\N	\N	\N	\N	\N	\N	2	test	2025-07-02 01:42:18.707	2025-07-02 01:42:18.727513
14	тест	окно	\N	\N	\N	\N	\N	\N	2	admin	2025-07-02 01:47:03.187	2025-07-02 01:47:03.205572
15	Тест алерта	Проверка получения сообщений от Service Worker	\N	\N	\N	\N	\N	\N	2	test	2025-07-02 01:49:12.542	2025-07-02 01:49:15.580385
16	Финальный тест	Проверяем работу модального окна	\N	\N	\N	\N	\N	\N	2	test	2025-07-02 01:49:37.894	2025-07-02 01:49:37.911852
17	Лютый тест	Проверяем	\N	\N	\N	\N	\N	\N	2	admin	2025-07-03 20:18:57.96	2025-07-03 20:18:57.978109
18	тест	тест	test	test	\N	\N	\N	\N	1	admin	2025-07-03 20:19:45.84	2025-07-03 20:19:45.858097
19	тест	тест	test	test	\N	\N	\N	\N	1	admin	2025-07-03 20:20:16.867	2025-07-03 20:20:16.883837
20	еше обно сообщение	Давай проверим	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 20:23:23.21	2025-07-03 20:23:23.229466
21	тест	тест	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 20:28:00.579	2025-07-03 20:28:00.597769
22	тест	тест	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:01:30.624	2025-07-03 21:01:30.643201
23	теск	порп олрплорпл	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:02:56.719	2025-07-03 21:02:56.737118
24	ыыыыы	ыыыыы	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:07:51.714	2025-07-03 21:07:51.733267
25	ыыыыы	ыыыыыыыыыыы	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:10:18.922	2025-07-03 21:10:18.941837
26	гнорапрп	рпп рпрол од	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:12:26.749	2025-07-03 21:12:26.767716
27	олрпорар	ерпплородлб	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:12:57.547	2025-07-03 21:12:57.564907
28	ggxf	Dftyyu	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:14:42.538	2025-07-03 21:14:42.556104
29	Пока не понятно	Пока не понятно как это все будет работать и сможет ли пользователь во всем этом разобраться	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:15:26.877	2025-07-03 21:15:26.896051
30	еще 	еще один тест	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:15:56.253	2025-07-03 21:15:56.271122
31	тетст	вои авлоавылдаыв	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:16:16.763	2025-07-03 21:16:16.7819
32	еще тест	тест еще	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:21:22.195	2025-07-03 21:21:22.214716
33	тест	тест	\N	\N	\N	\N	\N	\N	1	admin	2025-07-03 21:22:20.401	2025-07-03 21:22:20.417763
34	тест	тест	\N	\N	\N	\N	\N	\N	0	admin	2025-07-03 21:40:17.843	2025-07-03 21:40:17.862732
35	тест	тест	\N	\N	\N	\N	\N	\N	0	admin	2025-07-03 21:44:18.693	2025-07-03 21:44:18.711939
36	🎉 Тест после перезапуска	Проверка push уведомлений - должно появиться в браузере!	\N	\N	\N	\N	\N	\N	1	test	2025-07-05 23:43:54.211	2025-07-05 23:43:54.230781
37	Тест	Тестовое сообщение	\N	\N	\N	\N	\N	\N	0	test	2025-09-04 07:12:12.325	2025-09-04 07:12:12.491105
\.


--
-- Data for Name: master_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_users (id, email, password, first_name, last_name, role, is_active, created_at, updated_at) FROM stdin;
1	superadmin@edahouse.com	cbbf5115b14e3fe5e63db298dc9da9b9c85b1aa173b681b8cfdc5d05f7267ece7ea8dfeacaffd99eb21a84b34f3b2b6f182e4c22a0d7236db551273cc647d978.97161a8dd17ac83d439944c27bd4cd2b	Super	Admin	superadmin	t	2025-10-27 15:05:31.670966	2025-10-27 15:05:31.670966
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, product_id, quantity, price_per_kg, total_price, created_at) FROM stdin;
33	1	382	2.000	58.80	97.60	2025-06-18 13:42:33.672122
43	2	382	1.000	58.80	58.80	2025-06-18 14:30:32.850749
44	2	381	1.000	52.90	50.25	2025-06-18 14:30:32.850749
45	2	421	1.000	62.90	42.90	2025-06-18 14:30:32.850749
46	3	381	100.000	52.90	52.90	2025-06-18 15:46:57.762544
47	3	426	2.000	38.50	77.00	2025-06-18 15:46:57.762544
48	4	380	100.000	45.01	45.10	2025-06-18 16:03:52.340736
49	4	381	100.000	52.90	52.90	2025-06-18 16:03:52.340736
50	4	426	1.000	38.50	38.50	2025-06-18 16:03:52.340736
54	5	381	100.000	52.90	52.90	2025-06-18 22:55:36.794173
55	5	406	200.000	58.90	117.80	2025-06-18 22:55:36.794173
56	6	382	100.000	58.80	58.80	2025-06-18 23:51:11.741996
57	7	426	2.000	38.50	77.00	2025-06-19 00:16:26.722272
58	8	381	100.000	52.90	52.90	2025-06-19 00:39:48.609281
60	9	382	100.000	58.80	58.80	2025-06-19 00:55:13.31813
61	10	380	100.000	45.01	45.10	2025-06-19 05:30:31.161009
62	11	378	100.000	35.50	35.50	2025-06-19 11:35:44.640522
63	11	382	300.000	58.80	176.40	2025-06-19 11:35:44.640522
64	12	382	100.000	58.80	58.80	2025-06-19 12:00:43.867789
65	13	382	100.000	58.80	58.80	2025-06-19 12:04:49.649031
66	13	381	100.000	52.90	52.90	2025-06-19 12:04:49.649031
67	13	380	100.000	45.01	45.10	2025-06-19 12:04:49.649031
68	14	382	100.000	58.80	58.80	2025-06-19 12:10:31.229895
69	14	381	100.000	52.90	52.90	2025-06-19 12:10:31.229895
70	14	380	100.000	45.01	45.10	2025-06-19 12:10:31.229895
73	16	381	300.000	52.90	158.70	2025-06-19 16:06:08.614807
80	17	380	200.000	45.01	90.10	2025-06-23 22:36:17.324406
81	17	426	5.000	38.50	182.88	2025-06-23 22:36:17.324406
86	18	380	100.000	45.01	45.10	2025-07-05 23:05:19.051873
87	18	381	100.000	52.90	52.90	2025-07-05 23:05:19.051873
90	20	380	100.000	45.01	45.10	2025-07-06 13:43:41.592623
115	28	380	100.000	45.01	45.10	2025-07-06 17:21:08.120672
116	28	381	600.000	52.90	317.40	2025-07-06 17:21:08.120672
117	29	415	2.000	38.50	77.00	2025-07-09 07:09:35.190858
118	30	415	1.000	38.50	38.50	2025-07-09 07:30:14.905505
119	30	380	100.000	45.01	45.10	2025-07-09 07:30:14.905505
120	31	426	2.000	38.50	77.00	2025-09-03 14:53:19.198057
121	31	427	150.000	35.90	53.90	2025-09-03 14:53:19.198057
122	31	380	173.000	45.01	77.90	2025-09-03 14:53:19.198057
123	32	381	100.000	52.90	52.90	2025-09-03 16:36:32.086084
124	32	382	100.000	58.80	58.80	2025-09-03 16:36:32.086084
125	33	380	1.000	25.00	25.00	2025-09-05 11:32:47.557223
126	34	380	1.000	25.00	25.00	2025-09-05 11:35:49.08552
127	35	380	1.000	25.00	25.00	2025-09-05 11:46:25.689844
128	36	380	1.000	25.00	25.00	2025-09-05 11:56:44.751132
129	37	381	100.000	52.90	52.90	2025-09-05 12:12:50.458949
130	37	382	100.000	58.80	58.80	2025-09-05 12:12:50.458949
131	38	380	1.000	25.00	25.00	2025-09-05 12:18:02.716598
132	39	380	2.000	25.00	50.00	2025-09-05 12:18:24.353759
133	40	380	1.000	25.00	25.00	2025-09-05 12:19:03.389223
134	41	380	1.000	25.00	25.00	2025-09-05 12:20:08.943289
135	42	381	100.000	52.90	52.90	2025-09-05 12:34:54.474461
136	42	382	300.000	58.80	176.40	2025-09-05 12:34:54.474461
137	43	380	0.500	25.00	12.50	2025-09-05 12:36:18.689549
138	44	381	100.000	52.90	52.90	2025-09-12 09:35:27.441396
139	44	382	100.000	58.80	58.80	2025-09-12 09:35:27.441396
140	45	382	100.000	58.80	58.80	2025-09-12 09:38:36.132001
141	45	381	100.000	52.90	52.90	2025-09-12 09:38:36.132001
142	46	381	150.000	52.90	79.40	2025-09-12 09:49:36.282238
143	47	382	100.000	58.80	58.80	2025-09-12 09:55:56.940766
144	47	381	100.000	52.90	52.90	2025-09-12 09:55:56.940766
145	48	381	200.000	52.90	105.80	2025-09-12 10:29:52.649121
146	49	382	100.000	58.80	58.80	2025-09-12 14:07:54.229945
147	49	381	100.000	52.90	52.90	2025-09-12 14:07:54.229945
148	50	381	100.000	52.90	52.90	2025-09-12 14:09:06.683593
149	50	380	100.000	45.01	45.10	2025-09-12 14:09:06.683593
150	51	381	100.000	52.90	52.90	2025-09-12 14:11:38.37626
151	52	381	100.000	52.90	52.90	2025-09-12 14:14:56.023213
152	53	381	100.000	52.90	52.90	2025-09-12 19:32:54.818653
153	54	381	100.000	52.90	52.90	2025-09-12 19:39:23.301053
154	55	382	100.000	58.80	58.80	2025-09-12 19:44:23.835698
155	56	381	100.000	52.90	52.90	2025-09-14 10:41:44.588241
156	56	382	100.000	58.80	58.80	2025-09-14 10:41:44.588241
161	59	381	100.000	52.90	52.90	2025-09-14 11:49:43.938716
162	59	382	100.000	58.80	58.80	2025-09-14 11:49:43.938716
163	60	382	100.000	58.80	58.80	2025-09-14 11:56:37.439233
164	61	382	100.000	58.80	58.80	2025-09-14 11:57:24.520198
165	62	381	100.000	52.90	52.90	2025-09-21 19:35:13.558838
166	62	407	100.000	48.50	48.50	2025-09-21 19:35:13.558838
167	62	394	100.000	78.50	78.50	2025-09-21 19:35:13.558838
168	63	399	200.000	38.50	77.00	2025-09-21 20:19:56.782856
169	63	391	100.000	65.80	65.80	2025-09-21 20:19:56.782856
170	63	414	100.000	35.80	35.80	2025-09-21 20:19:56.782856
171	63	410	100.000	25.80	25.80	2025-09-21 20:19:56.782856
172	64	382	100.000	58.80	58.80	2025-09-24 13:36:48.463287
175	65	382	100.000	58.80	58.80	2025-10-16 07:30:22.049507
176	65	381	100.000	52.90	52.90	2025-10-16 07:30:22.049507
177	66	381	100.000	52.90	52.90	2025-10-16 07:31:13.828681
178	67	381	100.000	52.90	52.90	2025-10-16 07:45:02.305741
179	67	382	100.000	58.80	58.80	2025-10-16 07:45:02.305741
180	68	381	100.000	52.90	52.90	2025-10-16 07:54:08.756828
181	69	381	100.000	52.90	52.90	2025-10-16 08:06:53.931701
182	70	382	100.000	58.80	58.80	2025-10-16 08:13:59.201558
183	71	381	100.000	52.90	52.90	2025-10-30 13:56:36.659901
184	72	381	100.000	52.90	52.90	2026-02-09 11:14:01.961942
185	73	382	856.000	58.80	503.40	2026-02-09 11:18:25.418394
186	73	381	342.000	52.90	181.00	2026-02-09 11:18:25.418394
187	73	422	150.000	58.90	88.40	2026-02-09 11:18:25.418394
188	73	424	50.000	65.50	32.80	2026-02-09 11:18:25.418394
189	73	399	500.000	38.50	192.50	2026-02-09 11:18:25.418394
190	73	392	200.000	58.50	117.00	2026-02-09 11:18:25.418394
191	74	382	100.000	58.80	58.80	2026-02-25 11:21:01.679971
192	74	380	150.000	45.01	67.60	2026-02-25 11:21:01.679971
193	74	411	400.000	28.90	115.60	2026-02-25 11:21:01.679971
194	75	382	200.000	58.80	117.60	2026-04-14 06:47:42.798737
195	75	381	100.000	52.90	52.90	2026-04-14 06:47:42.798737
198	76	382	100.000	58.80	58.80	2026-05-09 20:42:55.012903
199	76	378	100.000	35.50	35.50	2026-05-09 20:42:55.012903
200	77	380	100.000	45.01	45.10	2026-05-11 15:01:47.393011
201	77	381	200.000	52.90	105.80	2026-05-11 15:01:47.393011
210	78	380	100.000	45.01	45.10	2026-05-11 15:46:16.298717
211	78	381	200.000	52.90	105.80	2026-05-11 15:46:16.298717
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, user_id, status, total_amount, customer_notes, delivery_address, payment_method, created_at, updated_at, customer_phone, requested_delivery_time, delivery_date, delivery_time, cancellation_reason, guest_name, guest_email, guest_phone, delivery_fee, guest_access_token, guest_access_token_expires, guest_claim_token, order_language, branch_id) FROM stdin;
11	\N	pending	211.90	\N	Dostavka 5	Картой по телефону или в магазине	2025-06-19 11:35:44.640522	2025-06-19 11:35:44.640522	\N	\N	2025-06-19	17:00 - 19:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
13	\N	pending	156.80	\N	Asdfghjjbg 56	Картой по телефону или в магазине	2025-06-19 12:04:49.649031	2025-06-19 12:04:49.649031	12345678887	\N	2025-06-19	17:00 - 19:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
16	admin	pending	173.70	\N	Stadia Gaon 6, Haifa	Картой по телефону или в магазине	2025-06-19 16:06:08.614807	2025-06-24 15:39:37.611	0528496528	\N	2025-06-24	19:00 - 21:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
9	43948959	preparing	58.80		Saadia Gaon 6/2, Haifa	Картой по телефону или в магазине	2025-06-19 00:54:00.374156	2025-06-20 11:26:00.399	+972528496528	\N	2025-06-25	11:00 - 13:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
12	\N	preparing	58.80	\N	Stadia Gaon 6, Haifa	Картой по телефону или в магазине	2025-06-19 12:00:43.867789	2025-07-01 23:00:18.548	0528496528	\N	2025-06-19	19:00 - 21:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
31	admin	pending	223.80	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-09-03 14:53:19.198057	2025-09-03 14:53:19.198057	0528496528	\N	2025-09-04		\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
32	admin	pending	126.70	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-09-03 16:36:32.086084	2025-09-03 16:36:32.086084	0528496528	\N	2025-09-05	13:00 - 15:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
33	\N	pending	40.00	\N	Тестовый адрес 123	cash	2025-09-05 11:32:47.557223	2025-09-05 11:32:47.557223	\N	\N	2024-01-15	10:00-12:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
1	43948959	ready	92.72	\n[DISCOUNTS:{"orderDiscount":{"type":"percentage","value":5,"reason":""},"itemDiscounts":null}]		cash	2025-06-17 19:00:50.571966	2025-07-06 15:00:13.023		\N			\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
2	43948959	preparing	136.76	\n[DISCOUNTS:{"orderDiscount":{"type":"percentage","value":10,"reason":""},"itemDiscounts":{"1":{"type":"percentage","value":5,"reason":""},"2":{"type":"amount","value":20,"reason":""}}}]	Haifa, Saadia Gaon 6	cash	2025-06-18 13:09:54.933499	2025-06-23 12:22:16.333	+972528496528	\N	2025-06-19	18:00-20:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
18	admin	pending	155.00	\n[ORDER_DATA:{"orderDiscount":{"type":"percentage","value":10,"reason":""},"itemDiscounts":null,"manualPriceOverride":{"enabled":true,"value":155}}]	Stadia Gaon 6, Haifa	Картой по телефону или в магазине	2025-06-30 08:24:30.370992	2025-07-05 23:05:19.231	0528496528	\N	2025-07-01	13:00 - 15:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
17	admin	confirmed	115.00	\n[ORDER_DATA:{"orderDiscount":{"type":"percentage","value":10,"reason":"так"},"itemDiscounts":{"1":{"type":"percentage","value":5,"reason":""}},"manualPriceOverride":{"enabled":true,"value":100}}]	Stadia Gaon 6, Haifa	Картой по телефону или в магазине	2025-06-20 13:31:40.324299	2025-07-05 23:05:26.64	0528496528	\N	2025-06-20	09:00 - 11:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
34	\N	pending	40.00	\N	Тестовый адрес 123	cash	2025-09-05 11:35:49.08552	2025-09-05 11:35:49.08552	\N	\N	2024-01-15	10:00-12:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
14	\N	preparing	156.80	\N	Adress 123	Картой по телефону или в магазине	2025-06-19 12:10:31.229895	2025-07-05 23:05:35.538	1234567896543	\N	2025-06-19	19:00 - 21:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
20	\N	pending	60.10	\N	dsfdg fgdfgh5	Банковская карта по телефону	2025-07-06 13:43:41.592623	2025-07-06 13:43:41.592623	\N	\N	2025-07-07		\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
3	43948959	pending	144.90	\N	Saadia Gaon 6/2, Haifa	cash	2025-06-18 15:46:57.762544	2025-06-18 15:46:57.762544	+972528496528	\N	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
4	43948959	pending	151.50	\N	Saadia Gaon 6/2, Haifa	cash	2025-06-18 16:03:52.340736	2025-06-18 16:03:52.340736	+972528496528	\N	2025-06-19	12:00-14:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
5	\N	pending	170.70		врврпарпа	cash	2025-06-18 20:20:38.960862	2025-06-18 22:55:36.968	543645645654	\N			\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
6	43948959	pending	58.80	\N	Saadia Gaon 6/2, Haifa	\N	2025-06-18 23:51:11.741996	2025-06-18 23:51:11.741996	\N	\N	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
7	43948959	pending	77.00	\N	Saadia Gaon 6/2, Haifa	\N	2025-06-19 00:16:26.722272	2025-06-19 00:16:26.722272	+972528496528	\N	2025-07-04	13:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
8	43948959	pending	52.90	\N	Saadia Gaon 6/2, Haifa	\N	2025-06-19 00:39:48.609281	2025-06-19 00:39:48.609281	+972528496528	\N	2025-06-25	17:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
10	\N	pending	45.10	\N	Haifa, S Gaon 6	Картой по телефону или в магазине	2025-06-19 05:30:31.161009	2025-06-19 05:30:31.161009	+9733396528	\N	2025-06-19	13:00 - 15:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
29	admin	pending	92.00	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-07-09 07:09:35.190858	2025-07-09 07:09:35.190858	0528496528	\N	2025-07-10	11:00 - 13:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
30	admin	cancelled	98.60	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-07-09 07:30:14.905505	2025-07-11 06:50:34.902	0528496528	\N	2025-07-10		Другое	\N	\N	\N	0.00	\N	\N	\N	ru	\N
28	admin	confirmed	377.50	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-07-06 17:21:08.120672	2025-07-17 13:47:59.499	0528496528	\N	2025-07-07	13:00 - 15:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
35	\N	pending	40.00	\N	Тестовый адрес 123	cash	2025-09-05 11:46:25.689844	2025-09-05 11:46:25.689844	\N	\N	2024-01-15	10:00-12:00	\N	Иван Петров	ivan@example.com	123456789	0.00	\N	\N	\N	ru	\N
36	\N	pending	40.00	\N	Новый тестовый адрес 456	card	2025-09-05 11:56:44.751132	2025-09-05 11:56:44.751132	\N	\N	2024-01-20	14:00-16:00	\N	Анна Смирнова	anna@example.com	987654321	0.00	\N	\N	\N	ru	\N
37	\N	pending	126.70	\N	Haifa, S Gaon 6	Банковская карта по телефону	2025-09-05 12:12:50.458949	2025-09-05 12:12:50.458949	\N	\N	2025-09-07	10:00 - 12:00	\N	Test Testovich	test@test.com	0500000000	0.00	\N	\N	\N	ru	\N
38	\N	pending	40.00	\N	Тестовый адрес 123	cash	2025-09-05 12:18:02.716598	2025-09-05 12:18:02.716598	\N	\N	2024-01-21	15:00-17:00	\N	Тест Пользователь	test@example.com	123456789	0.00	\N	\N	\N	ru	\N
39	\N	pending	65.00	\N	Улица Тестовая 456	card	2025-09-05 12:18:24.353759	2025-09-05 12:18:24.353759	\N	\N	2024-01-22	12:00-14:00	\N	Алексей Тестович	testuser@example.com	987654321	0.00	\N	\N	\N	ru	\N
40	\N	pending	40.00	\N	Debug Street 789	cash	2025-09-05 12:19:03.389223	2025-09-05 12:19:03.389223	\N	\N	2024-01-23	16:00-18:00	\N	Отладка Email	debug@example.com	111222333	0.00	\N	\N	\N	ru	\N
41	\N	pending	40.00	\N	Final Test St 999	card	2025-09-05 12:20:08.943289	2025-09-05 12:20:08.943289	\N	\N	2024-01-24	18:00-20:00	\N	Финальный Тест	final@test.com	999888777	0.00	\N	\N	\N	ru	\N
42	\N	pending	244.30	\N	Haifa, S Gaon 6	Банковская карта по телефону	2025-09-05 12:34:54.474461	2025-09-05 12:34:54.474461	\N	\N	2025-09-07	12:00 - 14:00	\N	Alex Суздальцева	alex@gmail.com	0521234567	0.00	\N	\N	\N	ru	\N
43	\N	pending	27.50	\N	Test Email Street 123	cash	2025-09-05 12:36:18.689549	2025-09-05 12:36:18.689549	\N	\N	2024-01-25	10:00-12:00	\N	EMAIL TEST	test.email@example.com	555444333	0.00	\N	\N	\N	ru	\N
44	\N	pending	126.70	\N	Test Address pMiyag	Наличными в магазине	2025-09-12 09:35:27.441396	2025-09-12 09:35:27.441396	\N	\N	2025-09-14	10:00 - 12:00	\N	TestGuestWoB3 UserIMVG	testguests4rlHZ@example.com	+9725YIb7A_0Q	0.00	9be6f962367c1dbc4070c58b540b2bb32a86fd6261de33bc8da74916eb8c2943	2025-10-12 09:35:27.275	47032ff7a338557f840930bd38057d13d14c9915707470347edb6c49283011b6	ru	\N
45	\N	pending	126.70	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-12 09:38:36.132001	2025-09-12 09:38:36.132001	\N	\N	2025-09-12	13:00 - 15:00	\N	Alex Ssss	alexjc55@yandex.ru	0521234567	0.00	b2421b5b603cc80a872c1c7ba143189ab3098c1cc49ef7e179cd5be1fec0a3e5	2025-10-12 09:38:36.114	c6e957c08da7ceec8ac3cb5743adf6612dcbf9c35d2d0393293646bcc1a3a1cb	ru	\N
46	\N	pending	94.40	\N	Test Address vn6nxL	Наличными в магазине	2025-09-12 09:49:36.282238	2025-09-12 09:49:36.282238	\N	\N	2025-09-15	09:00 - 11:00	\N	TestGueste6ox Usere6ox	testguestvn6nxL@example.com	+972dDpMru0S0	0.00	d225a2a942a6f741e546f573a39f5e510996602cb590d08db3e9b947fe7c0ebf	2025-10-12 09:49:36.263	b1b580c2374f81db6890e3fac9efd735bd16155bf801231655fe39f139866d7a	ru	\N
47	\N	pending	126.70	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-12 09:55:56.940766	2025-09-12 09:55:56.940766	\N	\N	2025-09-12	13:00 - 15:00	\N	Alex Test	alexjc55@yandex.ru	0521234567	0.00	d2399093968f4f8ded14cb26be0c687fb8910554b573a1d057c9b0ca94b98467	2025-10-12 09:55:56.923	4ff0590a96df8fbd6c834883d6d2cc85ebe11cd592ccd01fe6634c83a3a2e814	ru	\N
48	\N	pending	120.80	\N	123 Test Street		2025-09-12 10:29:52.649121	2025-09-12 10:29:52.649121	\N	\N			\N	Guest User	guest.user@example.com	+972555123456	0.00	990ce98de1158f7375e37d1223b64ba29638715078dca215071fba3bcd28b3cb	2025-10-12 10:29:52.136	e23c1a71d80e7c17a0f673d13769f1c6e2185485437407666cb02964ad582288	ru	\N
49	\N	pending	126.70	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-12 14:07:54.229945	2025-09-12 14:07:54.229945	\N	\N	2025-09-14	12:00 - 14:00	\N	Alex Ssss	alexjc55@yandex.ru	0521234567	0.00	eb8703dde16f12bd4e33a617cea308b111a738366d1083f2dd9e346f9e461830	2025-10-12 14:07:54.212	259420c70bbaabaf2bc70136343622d7423630696f5e3ac3331ac1a36eecf373	ru	\N
50	\N	pending	113.00	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-12 14:09:06.683593	2025-09-12 14:09:06.683593	\N	\N	2025-09-14	14:00 - 16:00	\N	Alex Ssss	alexjc55@yandex.ru	972533396528	0.00	099b41b2bea94c32085941bda554b09cc2bc9f214d0d5676128ac3049ed8585e	2025-10-12 14:09:06.666	3ec6f61c0c1004812338cf4318a6fe11e747b5def0b11e69c7416d291306a1a7	ru	\N
51	admin	pending	67.90	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-09-12 14:11:38.37626	2025-09-12 14:11:38.37626	0528496528	\N	2025-09-14	12:00 - 14:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
52	43948959	pending	67.90	\N	Saadia Gaon 6/2, Haifa	Банковская карта по телефону	2025-09-12 14:14:56.023213	2025-09-12 14:14:56.023213	+972528496528	\N	2025-09-14	16:00 - 18:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
53	\N	pending	67.90	\N	Тель Авив, Улица 11	Наличными в магазине	2025-09-12 19:32:54.818653	2025-09-12 19:32:54.818653	\N	\N	2025-09-14	10:00 - 12:00	\N	Тестовый Пользователь		0521234567	0.00	964d75498f118f9bbd1329661e6bef85cb6020b4a5007ad9b0ce667ac1d28743	2025-10-12 19:32:54.25	49bad0a38d453a216b6fb470aca0995d9dad958dd7cf7091c3442f78027d7b4b	ru	\N
54	\N	pending	67.90	\N	Хайфа, Центральная 5	Наличными в магазине	2025-09-12 19:39:23.301053	2025-09-12 19:39:23.301053	\N	\N	2025-09-14	10:00 - 12:00	\N	Тестовый2 Пользователь2	valid@example.com	0529876543	0.00	ec769f1b65256d416384622062ab50aa5c875a90a2130c2e38d769ff48214a72	2025-10-12 19:39:22.74	0f77c66116908df205c079bb72d23e90876fbc03f1db9164eb5bf0b293a39584	ru	\N
55	\N	pending	73.80	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-12 19:44:23.835698	2025-09-12 19:44:23.835698	\N	\N	2025-09-14	12:00 - 14:00	\N	Alex Ssss		0521234567	0.00	c31fc779991df0467df43daf339d7a12de28fba597cd10b50a165b9b40690416	2025-10-12 19:44:23.817	16898c1afe932be5bb6971fe39cac6f3efab52c4e37eccd2b2b227d98574be48	ru	\N
56	\N	pending	126.70	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-14 10:41:44.588241	2025-09-14 10:41:44.588241	\N	\N	2025-09-14	16:00 - 18:00	\N	Alex Ssss	alexjc55@yandex.ru	0521234567	0.00	1c87c0044dafcfb48b002d41c1e0873432966c66d71a56487d626c578fe4916f	2025-10-14 10:41:44.569	f5ee72099d8e9956b370e1ba1c7e28bd9d9ca29b93d68ec83363eae2b7cd80b7	ru	\N
59	\N	pending	126.70	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-14 11:49:43.938716	2025-09-14 11:49:43.938716	\N	\N	2025-09-18	11:00 - 13:00	\N	Alex Ssss	tetts@test.com	0521234567	0.00	88b305e0f3ae85cb42eca95a070b55276dfe9c4fea87277cebc4408f146926b5	2025-10-14 11:49:43.92	a63bcce1bb815c4495a63b94812c20443100bdafa130303d00ffc5687e35ee8e	ru	\N
60	\N	pending	73.80	\N	Тель Авив, Улица 11	Банковская карта по телефону	2025-09-14 11:56:37.439233	2025-09-14 11:56:37.439233	\N	\N	2025-09-25	11:00 - 13:00	\N	Alex Ssss	tetts@test.com	0521234567	0.00	4c2ff0a92cd65499e3c7f802991992824726c399de99d0ce35d91a9a28ad8b35	2025-10-14 11:56:37.42	ea9e71f6ffc99ee8db07065e55775cc59063708aee727293a27f22adedaccdbd	ru	\N
61	\N	pending	73.80	\N	kjsdhgskj dhgdjhs 4	Банковская карта по телефону	2025-09-14 11:57:24.520198	2025-09-14 11:57:24.520198	\N	\N	2025-09-25	11:00 - 13:00	\N	Кристина Суздальцева	tett1s@test.com	0521234567	0.00	76b4a40fa953213efc763ad651348f0533a7fecd8c66b6d5ce0a78831eb583f0	2025-10-14 11:57:24.502	0e7280564e5f82abbc7ba7a1be799eacdd00e1e3534a93be3ee42a2ac91f675c	ru	\N
62	admin	pending	194.90	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-09-21 19:35:13.558838	2025-09-21 19:35:13.558838	0528496528	\N	2025-09-28	14:00 - 16:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
63	\N	pending	219.50	\N	sadjhsak sadghjashd	Банковская карта по телефону	2025-09-21 20:19:56.782856	2025-09-21 20:19:56.782856	\N	\N	2025-09-26	11:00 - 13:00	\N	tetst testst	ttestst@gmail.com	87268635423578	0.00	689ea23f8eee32ef634f5406b9f115721105c4908f0175a016f5d02ee5570a62	2025-10-21 20:19:56.627	e8c95f5f6e4990af9dbd830f81301503de3b95bd8c3e4df33fdd1cabfc24f9cb	ru	\N
64	admin	pending	73.80	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-09-24 13:36:48.463287	2025-09-24 13:36:48.463287	0528496528	\N	2025-09-25	13:00 - 15:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
65	admin	pending	126.70		Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-10-16 07:29:22.672683	2025-10-16 07:30:22.21	0528496528	\N	2025-10-17		\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
66	admin	pending	67.90	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-10-16 07:31:13.828681	2025-10-16 07:31:13.828681	0528496528	\N	2025-10-16	half_day_second	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
67	admin	pending	126.70	\N	Stadia Gaon 6, Haifa		2025-10-16 07:45:02.305741	2025-10-16 07:45:02.305741	0528496528	\N	2025-10-16	half_day_second	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
68	admin	pending	67.90	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-10-16 07:54:08.756828	2025-10-16 07:54:08.756828	0528496528	\N	2025-10-16	half_day_second	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
69	admin	pending	67.90	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-10-16 08:06:53.931701	2025-10-16 08:06:53.931701	0528496528	\N	2025-10-17	half_day_second	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
70	admin	pending	73.80	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-10-16 08:13:59.201558	2025-10-16 08:13:59.201558	0528496528	\N	2025-10-17	half_day_first	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
71	admin	pending	67.90	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2025-10-30 13:56:36.659901	2025-10-30 13:56:36.659901	0528496528	\N	2025-10-30	half_day_second	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
72	admin	pending	67.90	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2026-02-09 11:14:01.961942	2026-02-09 11:14:01.961942	0528496528	\N	2026-02-19	half_day_second	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
73	admin	pending	1115.10	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2026-02-09 11:18:25.418394	2026-02-09 11:18:25.418394	0528496528	\N	2026-02-19	half_day_first	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
74	admin	pending	257.00	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2026-02-25 11:21:01.679971	2026-02-25 11:21:01.679971	0528496528	\N	2026-02-26	half_day_second	\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
75	admin	pending	185.50	\N	Stadia Gaon 6, Haifa	Банковская карта по телефону	2026-04-14 06:47:42.798737	2026-04-14 06:47:42.798737	0528496528	\N	2026-04-14	14:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	3
76	worker	pending	109.30		jkhsdkjhd 344	Банковская карта по телефону	2026-04-14 08:25:04.837362	2026-05-09 20:42:55.035	71653761548732	\N	2026-04-14	16:00	\N	\N	\N	\N	0.00	\N	\N	\N	ru	1
77	admin	pending	165.90	\N	Stadia Gaon 6, Haifa	Наличными в магазине	2026-05-11 15:01:47.393011	2026-05-11 15:01:47.393011	0528496528	\N	2026-05-13		\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
78	admin	pending	165.81		Stadia Gaon 6, Haifa	Наличными в магазине	2026-05-11 15:02:33.859317	2026-05-11 15:46:16.31	0528496528	\N	2026-05-13		\N	\N	\N	\N	0.00	\N	\N	\N	ru	\N
\.


--
-- Data for Name: product_branch_availability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_branch_availability (id, product_id, branch_id, is_available, stock_status, availability_status, created_at, updated_at) FROM stdin;
16	382	1	t	in_stock	available	2026-04-13 21:03:35.347217	2026-04-13 21:03:35.347217
17	382	2	t	in_stock	available	2026-04-13 21:03:35.347217	2026-04-13 21:03:35.347217
18	382	3	t	in_stock	available	2026-04-13 21:03:35.347217	2026-04-13 21:03:35.347217
38	381	2	t	in_stock	out_of_stock_today	2026-04-13 21:13:16.968387	2026-04-13 21:13:16.968387
39	381	3	t	in_stock	available	2026-04-13 21:13:16.968387	2026-04-13 21:13:16.968387
37	381	1	f	in_stock	completely_unavailable	2026-04-13 21:13:16.968387	2026-04-14 08:13:54.783478
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categories (id, product_id, category_id, created_at) FROM stdin;
1	377	47	2025-06-22 22:52:35.987281
2	378	47	2025-06-22 22:52:35.987281
3	379	47	2025-06-22 22:52:35.987281
4	384	47	2025-06-22 22:52:35.987281
5	385	47	2025-06-22 22:52:35.987281
6	386	47	2025-06-22 22:52:35.987281
7	387	47	2025-06-22 22:52:35.987281
11	382	47	2025-06-22 22:52:35.987281
12	388	47	2025-06-22 22:52:35.987281
13	389	48	2025-06-22 22:52:35.987281
14	390	48	2025-06-22 22:52:35.987281
16	392	48	2025-06-22 22:52:35.987281
17	393	48	2025-06-22 22:52:35.987281
18	394	48	2025-06-22 22:52:35.987281
19	395	48	2025-06-22 22:52:35.987281
20	396	48	2025-06-22 22:52:35.987281
21	397	48	2025-06-22 22:52:35.987281
22	398	48	2025-06-22 22:52:35.987281
23	399	48	2025-06-22 22:52:35.987281
24	407	48	2025-06-22 22:52:35.987281
25	400	48	2025-06-22 22:52:35.987281
26	401	48	2025-06-22 22:52:35.987281
27	402	48	2025-06-22 22:52:35.987281
28	403	48	2025-06-22 22:52:35.987281
29	404	48	2025-06-22 22:52:35.987281
30	405	48	2025-06-22 22:52:35.987281
31	406	48	2025-06-22 22:52:35.987281
32	408	48	2025-06-22 22:52:35.987281
33	409	49	2025-06-22 22:52:35.987281
34	410	49	2025-06-22 22:52:35.987281
35	411	49	2025-06-22 22:52:35.987281
36	412	49	2025-06-22 22:52:35.987281
37	413	49	2025-06-22 22:52:35.987281
38	414	49	2025-06-22 22:52:35.987281
39	416	50	2025-06-22 22:52:35.987281
40	417	50	2025-06-22 22:52:35.987281
41	418	50	2025-06-22 22:52:35.987281
42	419	50	2025-06-22 22:52:35.987281
43	420	50	2025-06-22 22:52:35.987281
44	423	51	2025-06-22 22:52:35.987281
45	424	51	2025-06-22 22:52:35.987281
46	425	52	2025-06-22 22:52:35.987281
47	427	52	2025-06-22 22:52:35.987281
48	428	52	2025-06-22 22:52:35.987281
50	426	52	2025-06-22 22:52:35.987281
52	422	51	2025-06-22 22:52:35.987281
90	415	50	2025-07-09 07:08:17.578924
117	381	47	2026-04-14 08:13:54.786922
125	421	51	2026-05-11 15:21:32.938112
126	380	47	2026-05-12 10:48:08.544561
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, price_per_kg, image_url, is_active, stock_status, sort_order, created_at, updated_at, is_available, price, unit, is_special_offer, discount_type, discount_value, availability_status, name_en, name_he, name_ar, description_en, description_he, description_ar, image_url_en, image_url_he, image_url_ar, barcode, ingredients, ingredients_en, ingredients_he, ingredients_ar) FROM stdin;
386	Салат из свеклы	Вареная свекла с чесноком и майонезом	28.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	28.90	100g	f	\N	\N	available		סלט סלק			סלק מבושל עם שום ומיונז					\N				
387	Салат из моркови	Корейская морковка с пряными специями	35.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	35.80	100g	f	\N	\N	available		סלט גזר			גזר קוריאני עם תבלינים חריפים					\N				
377	Оливье	Классический салат с мясом, картофелем, морковью, яйцами и горошком	42.00	/assets/1_1750184360776.jpg	t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	42.00	100g	f	\N	\N	available		אוליבייה			סלט קלאסי עם בשר, תפוחי אדמה, גזר, ביצים ואפונה					\N				
378	Винегрет	Традиционный русский салат со свеклой, морковью и квашеной капустой	35.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	35.50	100g	f	\N	\N	available		רוֹטֶב			סלט רוסי מסורתי עם סלק, גזר וכבוש					\N				
379	Мимоза	Нежный слоеный салат с рыбой, яйцами и сыром	48.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	48.90	100g	f	\N	\N	available		מימוזה			סלט שכבה עדין עם דגים, ביצים וגבינה					\N				
384	Салат из капусты	Свежая капуста с морковью и зеленью	25.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	25.90	100g	f	\N	\N	available		סלט כרוב			כרוב טרי עם גזר ועשבי תיבול					\N				
385	Салат свежий с редиской	Хрустящий салат из огурцов, редиски и зелени	32.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	32.50	100g	f	\N	\N	available		סלט טרי עם צנון			סלט פריך של מלפפונים, צנוניות ועשבי תיבול					\N				
388	Салат Цезарь	Классический салат с курицей, пармезаном и соусом цезарь	65.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	65.90	100g	f	\N	\N	available		סלט קיסר			סלט קלאסי עם עוף, פרמזן ורוטב קיסר					\N				
392	Окорочка	Запеченные куриные окорочка с травами и специями	58.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	58.50	100g	f	\N	\N	available		חֲרָדָה			עוף אפוי -חתכים עם עשבי תיבול ותבלינים					\N				
393	Тефтели	Нежные мясные шарики в томатном соусе	69.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	69.90	100g	f	\N	\N	available		בשר			כדורי בשר עדינים ברוטב עגבניות					\N				
394	Гуляш	Тушеное мясо с овощами в пряном соусе	78.50	/assets/3_1750184360777.jpg	t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	78.50	100g	f	\N	\N	available		גוּלָשׁ			תבשיל עם ירקות ברוטב חריף					\N				
395	Плов	Классический узбекский плов с мясом и морковью	52.90	/assets/3_1750184360777.jpg	t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	52.90	100g	f	\N	\N	available		פילאף			פילאף אוזבקי קלאסי עם בשר וגזר					\N				
396	Плов зеленый	Плов с зеленью, изюмом и специальными специями	56.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	56.80	100g	f	\N	\N	available		פילף ירוק			פילאף עם ירקות, צימוקים ותבלינים מיוחדים					\N				
397	Перцы фаршированные	Болгарский перец, фаршированный мясом и рисом	62.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	62.50	100g	f	\N	\N	available		נוצרו פלפלים			פלפל בולגרי ממולא בבשר ואורז					\N				
398	Голубцы	Капустные листья с мясной начинкой в томатном соусе	58.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	58.90	100g	f	\N	\N	available		גלילי כרוב			עלי כרוב עם בשר ממלאים רוטב עגבניות					\N				
399	Запеченные овощи	Ассорти из сезонных овощей, запеченных с травами	38.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	38.50	100g	f	\N	\N	available		ירקות אפויים			ירקות עונתיים שונים אפויים בעשבי תיבול					\N				
407	Душпара	Маленькие пельмени в ароматном бульоне	48.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	48.50	100g	f	\N	\N	available		דושפר			כופתאות קטנות במרק ארומטי					\N				
389	Котлеты	Домашние мясные котлеты из говядины и свинины	72.50	\N	t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	72.50	100g	f	\N	\N	available		קציצות			קציצות בשר בקר ובשר חזיר					\N				
390	Паргит	Куриное филе в панировке, жаренное до золотистой корочки	68.90	\N	t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	68.90	100g	f	\N	\N	available		פרגיט			פילה עוף בסנפינג, מטוגן עד קרום הזהב					\N				
391	Крылышки	Сочные куриные крылышки в медово-горчичном соусе	65.80	\N	t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	65.80	100g	f	\N	\N	available		כנפיים			כנפי עוף עסיסיות ברוטב דבש-גורכי					\N				
402	Фасоль тушеная	Белая фасоль тушеная с овощами и томатами	35.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	35.50	100g	f	\N	\N	available		השעועית מבושלת			שעועית לבנה מבושלת בירקות ועגבניות					\N				
415	Борщ	Традиционный украинский борщ со сметаной	38.50	/uploads/images/image-1750192273390-458955015.webp	t	in_stock	0	2025-06-17 18:46:47.892589	2025-07-09 07:08:17.465	t	38.50	portion	f	\N	\N	available		בורש			בורש אוקראיני מסורתי עם שמנת חמוצה					\N				
382	Баклажаны по-азиатски	Маринованные баклажаны с чесноком и кориандром	58.80		t	in_stock	0	2025-06-17 18:46:47.892589	2026-04-13 21:03:35.116	t	58.80	100g	t	percentage	20.00	available		חציל באסיה			חציל כבוש עם שום וכוסברה					\N				
403	Жаркое	Мясо тушеное с картофелем и овощами по-домашнему	68.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	68.90	100g	f	\N	\N	available		צָלִי			בשר מבושל עם תפוחי אדמה וירקות בבית					\N				
422	Блинчики с Мясом	Традиционное русское лакомство – тонкие и румяные блинчики. Блинчики с богатой мясной начинкой станут прекрасным перекусом или полноценным вторым блюдом на завтрак или обед.	58.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-22 22:49:35.391	t	58.90	100g	f	\N	\N	available		לביבות עם בשר			הפינוקים הרוסים המסורתיים הם פנקייקים דקים ואדומים.לביבות עם מילוי בשר עשיר יהיו חטיף נפלא או מנה שנייה מלאה לארוחת בוקר או ארוחת צהריים.					\N				
400	Отбивные	Свиные отбивные в золотистой панировке	82.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	82.90	100g	f	\N	\N	available		לִקצוֹץ			צלעות חזיר בפאנינג מוזהב					\N				
401	Шницель	Куриный шницель в хрустящей панировке	75.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	75.80	100g	f	\N	\N	available		שׁנִיצֶל			שניצל עוף בבהלה פריכה					\N				
404	Капуста тушеная	Белокочанная капуста тушеная с морковью и луком	28.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	28.50	100g	f	\N	\N	available		הכרוב מבושל			כרוב לבן מבושל בגזר ובצל					\N				
405	Курица по-китайски	Кусочки курицы в кисло-сладком соусе с овощами	72.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	72.80	100g	f	\N	\N	available		עוף סיני			החלקים של קוריטה ברוטב מתוק וחמוץ עם ירקות					\N				
406	Чебуреки	Хрустящие чебуреки с сочной мясной начинкой	58.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	58.90	100g	f	\N	\N	available		צ'בורקס			צ'בורקי פריכים במילוי בשר עסיסי					\N				
408	Равиоли	Итальянские равиоли с сырной начинкой	65.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	65.90	100g	f	\N	\N	available		רַביוֹלִי			רביולי איטלקי עם מילוי גבינה					\N				
409	Картошка жареная	Золотистая жареная картошка с луком и зеленью	32.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	32.50	100g	f	\N	\N	available		טיגון תפוחי אדמה			תפוחי אדמה מטוגנים זהובים עם בצל ועשבי תיבול					\N				
410	Рис отварной	Рассыпчатый белый рис с маслом	25.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	25.80	100g	f	\N	\N	available		האורז מבושל			אורז לבן בהיר עם חמאה					\N				
411	Гречка	Рассыпчатая гречневая каша с маслом	28.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	28.90	100g	f	\N	\N	available		כוסמת			דייסת כוסמת מתפוררת עם חמאה					\N				
412	Картофель отварной	Молодой картофель отварной с укропом	26.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	26.50	100g	f	\N	\N	available		תַפּוּחֵי אֲדָמָה מְבוּשָׁלים			תפוח אדמה צעיר מבושל עם שמיר					\N				
413	Макароны	Отварные макароны с маслом и сыром	22.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	22.90	100g	f	\N	\N	available		פַּסטָה			פסטה מבושלת עם חמאה וגבינה					\N				
414	Пюре картофельное	Нежное картофельное пюре на молоке с маслом	35.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	35.80	100g	f	\N	\N	available		פירה			מחית תפוח אדמה עדינה בחלב עם חמאה					\N				
417	Щи	Кислые щи из квашеной капусты с мясом	35.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	35.80	100g	f	\N	\N	available		מרק כרוב			מרק כרוב חמוץ עם בשר עם בשר					\N				
418	Суп гороховый	Наваристый гороховый суп с копченостями	32.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	32.50	100g	f	\N	\N	available		מרק אפונה			גידול מרק אפונה עם בשרים מעושנים					\N				
420	Лагман	Узбекский суп с лапшой и мясом	45.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	45.80	100g	f	\N	\N	available		לגמן			מרק אוזבקי עם אטריות ובשר					\N				
423	Сырники	Нежные творожные сырники со сметаной	52.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	52.90	100g	f	\N	\N	available		סירניקי			עוגות גבינה עדינות עם קרם עם שמנת חמוצה					\N				
425	Пирожок с Мясом	Сытный пирожок с ароматной мясной начинкой, выпеченный по домашнему рецепту	45.80		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	45.80	100g	f	\N	\N	available		פאי עם בשר			פשטידה לבבית עם בשר ארומטי שמילוי מאפה על ידי מתכון ביתי					\N				
428	Пирожок с Яблоком	Сладкий пирожок с ароматной яблочной начинкой и корицей	42.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	42.90	100g	f	\N	\N	available		פאי עם תפוח			פאי מתוק עם מילוי תפוחים ארומטי וקינמון					\N				
426	Пирожок с Зеленым Луком и Яйцом	Традиционный пирожок с начинкой из свежего зеленого лука и вареных яиц	38.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-18 14:43:39.892	t	38.50	piece	f	\N	\N	available		בצל ירוק וביצה			פשטידה מסורתית עם בצל ירוק טרי וביצים מבושלות					\N				
416	Солянка мясная	Сытная солянка с копченостями и оливками	48.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	48.90	100g	f	\N	\N	available		בשר Solyanka			סוליאנקה עשירה עם מעושנים וזיתים					\N				
419	Харчо	Острый грузинский суп с мясом и рисом	42.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	42.90	100g	f	\N	\N	available		כרצ'ו			מרק גרוזיני חד עם בשר ואורז					\N				
424	Чебуреки с Мясом Жареные	Хрустящие чебуреки с сочной мясной начинкой, обжаренные до золотистой корочки	65.50		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	65.50	100g	f	\N	\N	available		טיגון צ'ברקים עם בשר			צ'בורקי פריכים עם מילוי בשר עסיסי, מטוגנים עד שהם זהובים ופריכים					\N				
427	Пирожок с Картофелем	Домашний пирожок с нежной картофельной начинкой и зеленью	35.90		t	in_stock	0	2025-06-17 18:46:47.892589	2025-06-17 18:46:47.892589	t	35.90	100g	f	\N	\N	available		פירושוק עם תפוחי אדמה			פשטידה ביתית עם מילוי תפוח אדמה עדין ועשבי תיבול					\N				
381	Аджика	Острая закуска из помидоров, перца и специй	52.90		t	in_stock	0	2025-06-17 18:46:47.892589	2026-04-14 08:13:54.774	t	52.90	100g	t	percentage	20.00	available		אדזיקה			חטיף חריף מעגבניות, פלפל ותבלינים					290001				
421	Блинчики с Куриной Грудкой и Сыром	Сочная начинка из нежной куриной грудки, плавленого сыра, завернутая в тонкие и румяные блинчики. Прекрасный перекус и полноценное второе блюдо во время обеда.	62.90		t	in_stock	0	2025-06-17 18:46:47.892589	2026-05-11 15:21:32.924	t	62.90	100g	t	percentage	10.00	available		לביבות עם חזה עוף וגבינה			מילוי עסיסי של חזה עוף עדין, גבינה מומסת, עטוף בפנקייקים דקים ואדומים.חטיף נפלא ומנה שנייה מלאה במהלך ארוחת הצהריים.					\N				
380	Абжерка	Острый грузинский салат с овощами и зеленью	45.01	/uploads/optimized/image-1752438250252-66041097.jpg	t	in_stock	0	2025-06-17 18:46:47.892589	2026-05-12 10:48:08.472	t	45.01	100g	t	percentage	20.00	out_of_stock_today		אסירקה			סלט גרוזיני חד עם ירקות ועשבי תיבול					025874	**Что-то вкусное** 100г\r\nЧто-то не очень вкусное 20г\r\nМясо белого медведя 300г		** משהו טעים ** 100 גרם\r\nמשהו לא טעים במיוחד 20 גרם\r\nבשר דוב לבן 300 גרם	
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (sid, sess, expire) FROM stdin;
MyEgoCWdKNDhJ-P7VvJwim06x-P-pBWQ	{"cookie":{"originalMaxAge":86400000,"expires":"2026-05-12T14:54:42.488Z","secure":false,"httpOnly":true,"path":"/"},"passport":{"user":"__superadmin__"}}	2026-05-12 14:54:43
TKmz4rNy684Vb7G5CgyNMRvy7Gxb2uLA	{"cookie":{"originalMaxAge":86400000,"expires":"2026-05-12T14:54:50.426Z","secure":false,"httpOnly":true,"path":"/"},"passport":{"user":"__superadmin__"}}	2026-05-12 14:54:51
005xiXSkjQY2m9rAj8CN589i1gkxspva	{"cookie":{"originalMaxAge":86400000,"expires":"2026-05-12T14:54:52.634Z","secure":false,"httpOnly":true,"path":"/"},"passport":{"user":"__superadmin__"}}	2026-05-12 14:54:53
ZJfIqbZWQ2jSiex9yn5bhQ91xkBSKH0V	{"cookie":{"originalMaxAge":86400000,"expires":"2026-05-12T14:34:32.321Z","secure":false,"httpOnly":true,"path":"/"},"passport":{"user":"admin"}}	2026-05-13 12:32:50
6XO7t_AoFaXdS5wuiOuhvWTR8hPuZno7	{"cookie":{"originalMaxAge":86399999,"expires":"2026-05-12T15:38:00.235Z","secure":false,"httpOnly":true,"path":"/"},"passport":{"user":"admin"}}	2026-05-12 17:28:44
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (sid, sess, expire) FROM stdin;
4-siSvCtmp8AU5P-jRRt96KCTvFXQPff	{"cookie": {"path": "/", "secure": true, "expires": "2025-06-26T05:17:50.281Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "491046aa-9b11-42b7-94fd-d84f70bd4f20", "exp": 1750313869, "iat": 1750310269, "iss": "https://replit.com/oidc", "sub": "43948959", "email": "alexjc55@gmail.com", "at_hash": "_i_nTXmq5nQ__8aFbUUhuA", "username": "alexjc55", "auth_time": 1750310269, "last_name": "Suzdaltsev", "first_name": "Alexey"}, "expires_at": 1750313869, "access_token": "4PQ__7O-4mNFlOYDCzDVSQJ6qwSzNjOvram66vouTbE", "refresh_token": "cpS_jF7Ze8dd6PGNOHvTWyJZ78iIkfBGKfsdcr1NEIs"}}}	2025-06-26 05:51:07
VY7KN86OYX_PEP7ro_qQOZbB8WRChQWl	{"cookie": {"path": "/", "secure": true, "expires": "2025-06-26T06:24:24.957Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "491046aa-9b11-42b7-94fd-d84f70bd4f20", "exp": 1750317864, "iat": 1750314264, "iss": "https://replit.com/oidc", "sub": "43948959", "email": "alexjc55@gmail.com", "at_hash": "qmn8c3mjy1MA2UcGOa2voQ", "username": "alexjc55", "auth_time": 1750289942, "last_name": "Suzdaltsev", "first_name": "Alexey"}, "expires_at": 1750317864, "access_token": "P2bI1irg1Wb-lwrA_lk5EKASWrhHHIGyqqF_ranPcTO", "refresh_token": "5-FOy5QbJg06Dx_Rlsdy87tCwvQXyi02Vv_CfXWDK7g"}}}	2025-06-26 06:30:12
nsbTrhb7JHzFJPYPFE7Y3QPb4ciXGqzd	{"cookie": {"path": "/", "secure": true, "expires": "2025-06-25T20:28:03.790Z", "httpOnly": true, "originalMaxAge": 604800000}}	2025-06-25 20:43:33
3yWS7K4eKtnyc2UzDoEZNvOmddd8fupE	{"cookie": {"path": "/", "secure": true, "expires": "2025-06-25T20:17:09.575Z", "httpOnly": true, "originalMaxAge": 604800000}, "replit.com": {"code_verifier": "itXE_jVaaleNw0ij0zgvDdYhkscPD53BdS7yvDP2lLk"}}	2025-06-25 20:17:10
So7IMzBJAHL8kLB_8yIc3fp5AsKVC57u	{"cookie": {"path": "/", "secure": true, "expires": "2025-06-25T20:17:23.034Z", "httpOnly": true, "originalMaxAge": 604800000}, "replit.com": {"code_verifier": "_h8Vqy-jfsFEXN85F7xwhgPfAJwWoPkreG3cF3UiYis"}}	2025-06-25 20:17:24
Tl8X2JHr0npnf81FmjjNTGxANuQFAJY2	{"cookie": {"path": "/", "secure": true, "expires": "2025-06-26T05:31:17.303Z", "httpOnly": true, "originalMaxAge": 604800000}, "replit.com": {"code_verifier": "R8xwrlvEdOWfFEkQF2bQ2HqXHe8FQCHmSoh9NeBtldU"}}	2025-06-26 05:31:18
\.


--
-- Data for Name: store_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_settings (id, store_name, store_description, contact_phone, contact_email, address, working_hours, delivery_fee, free_delivery_from, payment_methods, is_delivery_enabled, is_pickup_enabled, updated_at, min_delivery_time_hours, max_delivery_time_days, logo_url, delivery_info, payment_info, about_us_photos, welcome_title, banner_image, discount_badge_text, show_banner_image, show_title_description, show_info_blocks, show_special_offers, show_category_menu, week_start_day, bottom_banner1_url, bottom_banner1_link, bottom_banner2_url, bottom_banner2_link, show_bottom_banners, default_items_per_page, cancellation_reasons, header_html, footer_html, show_whatsapp_chat, whatsapp_phone_number, whatsapp_default_message, show_cart_banner, cart_banner_type, cart_banner_image, cart_banner_text, cart_banner_bg_color, cart_banner_text_color, auth_page_title, auth_page_subtitle, auth_page_feature1, auth_page_feature2, auth_page_feature3, worker_permissions, default_language, enabled_languages, info_blocks_position, header_style, banner_button_text, banner_button_link, modern_block1_icon, modern_block1_text, modern_block2_icon, modern_block2_text, modern_block3_icon, modern_block3_text, banner_image_url, store_name_ar, store_description_ar, welcome_title_ar, welcome_subtitle_ar, delivery_info_ar, store_name_he, welcome_title_he, store_description_he, delivery_info_he, store_name_en, welcome_title_en, store_description_en, delivery_info_en, about_text_ru, about_text_en, about_text_he, about_text_ar, banner_button_text_ru, banner_button_text_en, banner_button_text_he, banner_button_text_ar, discount_badge_text_en, discount_badge_text_he, discount_badge_text_ar, whatsapp_default_message_en, whatsapp_default_message_he, whatsapp_default_message_ar, cart_banner_text_en, cart_banner_text_he, cart_banner_text_ar, payment_info_en, payment_info_he, payment_info_ar, contact_phone_en, contact_phone_he, contact_phone_ar, contact_email_en, contact_email_he, contact_email_ar, address_en, address_he, address_ar, pwa_icon, pwa_name, pwa_description, pwa_name_en, pwa_description_en, pwa_name_he, pwa_description_he, pwa_name_ar, pwa_description_ar, logo_url_en, logo_url_he, logo_url_ar, banner_image_url_en, banner_image_url_he, banner_image_url_ar, cart_banner_image_en, cart_banner_image_he, cart_banner_image_ar, pwa_icon_en, pwa_icon_he, pwa_icon_ar, barcode_system_enabled, barcode_product_code_start, barcode_product_code_end, barcode_weight_start, barcode_weight_end, barcode_weight_unit, enable_admin_order_creation, slider_autoplay, slider_speed, slider_effect, slide1_image, slide1_title, slide1_subtitle, slide1_button_text, slide1_button_link, slide1_text_position, slide2_image, slide2_title, slide2_subtitle, slide2_button_text, slide2_button_link, slide2_text_position, slide3_image, slide3_title, slide3_subtitle, slide3_button_text, slide3_button_link, slide3_text_position, slide4_image, slide4_title, slide4_subtitle, slide4_button_text, slide4_button_link, slide4_text_position, slide5_image, slide5_title, slide5_subtitle, slide5_button_text, slide5_button_link, slide5_text_position, slide1_title_en, slide1_subtitle_en, slide1_button_text_en, slide1_title_he, slide1_subtitle_he, slide1_button_text_he, slide1_title_ar, slide1_subtitle_ar, slide1_button_text_ar, slide2_title_en, slide2_subtitle_en, slide2_button_text_en, slide2_title_he, slide2_subtitle_he, slide2_button_text_he, slide2_title_ar, slide2_subtitle_ar, slide2_button_text_ar, slide3_title_en, slide3_subtitle_en, slide3_button_text_en, slide3_title_he, slide3_subtitle_he, slide3_button_text_he, slide3_title_ar, slide3_subtitle_ar, slide3_button_text_ar, slide4_title_en, slide4_subtitle_en, slide4_button_text_en, slide4_title_he, slide4_subtitle_he, slide4_button_text_he, slide4_title_ar, slide4_subtitle_ar, slide4_button_text_ar, slide5_title_en, slide5_subtitle_en, slide5_button_text_en, slide5_title_he, slide5_subtitle_he, slide5_button_text_he, slide5_title_ar, slide5_subtitle_ar, slide5_button_text_ar, modern_block1_text_en, modern_block2_text_en, modern_block3_text_en, modern_block1_text_he, modern_block2_text_he, modern_block3_text_he, modern_block1_text_ar, modern_block2_text_ar, modern_block3_text_ar, email_notifications_enabled, order_notification_email, order_notification_from_name, order_notification_from_email, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_password, sendgrid_api_key, use_sendgrid, delivery_time_mode, facebook_pixel_id, facebook_conversions_api_enabled, facebook_access_token, delivery_hours, category_display_style, mobile_quick_buttons) FROM stdin;
1	eDAHouse	Описание магазина	0501234567		Это адрес магазина	{"friday": "09:00-15:00", "monday": "09:00-21:00", "sunday": "10:00-20:00", "tuesday": "09:00-21:00", "saturday": "", "thursday": "09:00-21:00", "wednesday": "09:00-21:00"}	15.00	300.00	[{"fee": 0, "name": "Наличными в магазине", "enabled": true, "name_ar": "", "name_en": "Cash in Shop", "name_he": ""}, {"fee": 0, "name": "Банковская карта по телефону", "enabled": true, "name_ar": "", "name_en": "Cash in Shop", "name_he": ""}]	t	t	2026-05-12 10:51:59.738	2	4	/uploads/images/image-1751756174833-500216572.png	Информация о доставке	Информация об оплате	[]		/uploads/images/image-1750201280286-954389557.jpg		t	t	t	t	f	sunday					t	25	\N	<!-- Meta Pixel Code -->\n<script>\n!function(f,b,e,v,n,t,s)\n{if(f.fbq)return;n=f.fbq=function(){n.callMethod?\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};\nif(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';\nn.queue=[];t=b.createElement(e);t.async=!0;\nt.src=v;s=b.getElementsByTagName(e)[0];\ns.parentNode.insertBefore(t,s)}(window, document,'script',\n'https://connect.facebook.net/en_US/fbevents.js');\nfbq('init', '1211785016960429');\nfbq('track', 'PageView');\n</script>\n<noscript><img height="1" width="1" style="display:none"\nsrc="https://www.facebook.com/tr?id=1211785016960429&ev=PageView&noscript=1"\n/></noscript>\n<!-- End Meta Pixel Code -->		t	+972501234567	Здравствуйте! Интересует ваша продукция.	t	text	/uploads/images/image-1751759635078-236489314.jpg	Доставка от 300 шек. бесплатно	#f97316	#ffffff	Добро пожаловать в eDAHouse	Готовые блюда высокого качества с доставкой на дом	Свежие готовые блюда каждый день	Быстрая доставка в удобное время	Широкий выбор блюд на любой вкус	{"canViewUsers": false, "canManageUsers": false, "canCreateOrders": false, "canManageOrders": true, "canManageThemes": false, "canViewSettings": false, "canManageProducts": true, "canManageSettings": false, "canManageCategories": true}	ru	["ru", "he", "en", "ar"]	bottom	slider	Заказать сейчас	#categories	Phone	050-123-4567	Truck	Бесплатная достака от 200₪	ChefHat	Собственное производство	/uploads/optimized/image-1754487499462-271539671.jpg				\N																																							/uploads/images/image-1751405575061-196959045.png	eDAHouse	Готовая еда с доставкой				אוכל מוכן עם משלוח															t	2	7	8	12	g	t	t	5000	slideScale	/uploads/optimized/image-1756152795524-30606472.jpg	Суп дня	Вкусный борщ как у мамы			left-bottom	/uploads/optimized/image-1756152801256-797211994.jpg	Любимый плов	Всегда актуально, всегда вкусно!			right-top	/uploads/optimized/image-1756152806907-983908199.jpg	Куринные котлеты	Дополнят любое блюдо			left-top	/uploads/optimized/image-1756152813573-562765915.jpg	Оливье	Праздник каждый день!			center-top	/uploads/optimized/image-1756152820226-667413801.jpg	Сырники	Выбор для идеального завтрака			right-top				יום מרק	בורש טעים כמו אמא								פילף אהוב	תמיד רלוונטי, תמיד טעים!								קציצות עוף	הם ישלימו כל מנה								אוליבייה	חג כל יום!								סירניקי	בחירה לארוחת הבוקר המושלמת									משלוח חינם מ- 200 ₪	ייצור משלו				t	alexjc55@gmail.com	eDAHouse	noreply@ordis.co.il	demo.ordis.co.il	587	t	noreply@ordis.co.il	i&,>YGY#9S&^k{Oa		f	disabled		f		{"friday": "10:00-14:00", "monday": "10:00-18:00", "sunday": "10:00-18:00", "tuesday": "10:00-18:00", "saturday": null, "thursday": "10:00-18:00", "wednesday": "10:00-18:00"}	default	["orders", "products"]
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, subdomain, custom_domain, db_cluster, store_name, is_active, plan_type, created_at, updated_at, contact_email, contact_phone, subscription_status, subscription_start_date, subscription_end_date, last_payment_date, payment_method, notes) FROM stdin;
1	edahouse	edahouse.ordis.co.il	cluster_1	eDAHouse - Готовая еда с доставкой	t	basic	2025-10-27 12:05:56.2484	2025-10-27 12:05:56.2484	\N	\N	trial	2025-10-27 15:35:16.863575	\N	\N	\N	\N
2	testshop1	\N	cluster_1	Test Shop 1	t	basic	2025-10-27 13:37:58.20931	2025-10-27 13:37:58.20931	\N	\N	trial	2025-10-27 15:35:16.863575	\N	\N	\N	\N
3	shop2	\N	cluster_1	Shop 2 - Second Store	t	basic	2025-10-27 13:38:42.580563	2025-10-27 16:44:32.236	\N	\N	trial	2025-10-27 15:35:16.863575	\N	\N	\N	\N
\.


--
-- Data for Name: themes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.themes (id, name, description, is_active, primary_color, primary_dark_color, primary_light_color, secondary_color, accent_color, success_color, success_light_color, warning_color, warning_light_color, error_color, error_light_color, info_color, info_light_color, white_color, gray50_color, gray100_color, gray200_color, gray300_color, gray400_color, gray500_color, gray600_color, gray700_color, gray800_color, gray900_color, font_family_primary, font_family_secondary, primary_shadow, success_shadow, warning_shadow, error_shadow, info_shadow, gray_shadow, created_at, updated_at, primary_text_color, tomorrow_shadow, tomorrow_color, tomorrow_light_color, out_of_stock_color, tomorrow_dark_color, working_hours_icon_color, contacts_icon_color, payment_delivery_icon_color, header_style, banner_button_text, banner_button_link, modern_block1_icon, modern_block1_text, modern_block2_icon, modern_block2_text, modern_block3_icon, modern_block3_text, show_banner_image, show_title_description, show_info_blocks, info_blocks_position, show_prices, show_product_images, show_cart, show_special_offers, show_category_menu, show_whatsapp_chat, whatsapp_phone, whatsapp_message, logo_url, banner_image_url, show_cart_banner, cart_banner_type, cart_banner_image, cart_banner_text, cart_banner_bg_color, cart_banner_text_color, show_bottom_banners, bottom_banner1_url, bottom_banner1_link, bottom_banner2_url, bottom_banner2_link, name_en, name_he, name_ar, description_en, description_he, description_ar, banner_button_text_en, banner_button_text_he, banner_button_text_ar, logourl_en, logourl_he, logourl_ar, bannerimageurl_en, bannerimageurl_he, bannerimageurl_ar, cartbannerimage_en, cartbannerimage_he, cartbannerimage_ar, bottombanner1url_en, bottombanner1url_he, bottombanner1url_ar, bottombanner2url_en, bottombanner2url_he, bottombanner2url_ar, logo_url_en, logo_url_he, logo_url_ar, banner_image_url_en, banner_image_url_he, banner_image_url_ar, cart_banner_image_en, cart_banner_image_he, cart_banner_image_ar, bottom_banner1_url_en, bottom_banner1_url_he, bottom_banner1_url_ar, bottom_banner2_url_en, bottom_banner2_url_he, bottom_banner2_url_ar, slider_autoplay, slider_speed, slider_effect, slide1_image, slide1_title, slide1_subtitle, slide1_button_text, slide1_button_link, slide1_text_position, slide2_image, slide2_title, slide2_subtitle, slide2_button_text, slide2_button_link, slide2_text_position, slide3_image, slide3_title, slide3_subtitle, slide3_button_text, slide3_button_link, slide3_text_position, slide4_image, slide4_title, slide4_subtitle, slide4_button_text, slide4_button_link, slide4_text_position, slide5_image, slide5_title, slide5_subtitle, slide5_button_text, slide5_button_link, slide5_text_position, whatsapp_message_en, whatsapp_message_he, whatsapp_message_ar, cart_banner_text_en, cart_banner_text_he, cart_banner_text_ar, splash_bg_color, category_display_style) FROM stdin;
default_theme_1750432574.178085	Стандартная тема 	Базовая оранжевая тема сайта	t	hsl(25, 95%, 53%)	hsl(21, 90%, 48%)	hsl(23, 90%, 96%)	hsl(210, 40%, 98%)	hsl(210, 40%, 85%)	hsl(142, 76%, 36%)	hsl(142, 76%, 96%)	hsl(38, 92%, 50%)	hsl(38, 92%, 96%)	hsl(0, 84%, 60%)	hsl(0, 84%, 96%)	hsl(221, 83%, 53%)	hsl(221, 83%, 96%)	hsl(0, 0%, 100%)	hsl(210, 40%, 98%)	hsl(210, 40%, 96%)	hsl(214, 32%, 91%)	hsl(213, 27%, 84%)	hsl(215, 20%, 65%)	hsl(215, 16%, 47%)	hsl(215, 19%, 35%)	hsl(215, 25%, 27%)	hsl(217, 33%, 17%)	hsl(223, 84%, 5%)	Poppins, sans-serif	Inter, sans-serif	0 4px 14px 0 rgba(255, 102, 0, 0.3)	0 4px 14px 0 rgba(34, 197, 94, 0.3)	0 4px 14px 0 rgba(245, 158, 11, 0.3)	0 4px 14px 0 rgba(239, 68, 68, 0.3)	0 4px 14px 0 rgba(59, 130, 246, 0.3)	0 4px 14px 0 rgba(107, 114, 128, 0.3)	2025-06-20 15:16:14.178085	2026-05-12 11:15:52.533	hsl(0, 0%, 100%)	0 4px 14px 0 rgba(147, 51, 234, 0.3)	hsl(262, 83%, 58%)	hsl(262, 83%, 96%)	hsl(0, 84%, 60%)	hsl(262, 83%, 48%)	hsl(220, 91%, 54%)	hsl(142, 76%, 36%)	hsl(262, 83%, 58%)	slider	Заказать сейчас	#categories	Phone	050-123-4567	Truck	Бесплатная достака от 200₪	ChefHat	Собственное производство	t	t	t	bottom	t	t	t	t	f	t	+972501234567	Здравствуйте! Интересует ваша продукция.	/uploads/images/image-1751756174833-500216572.png	/uploads/optimized/image-1754487499462-271539671.jpg	t	text	/uploads/images/image-1751759635078-236489314.jpg	Доставка от 300 шек. бесплатно	#f97316	#ffffff	t					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N																t	5000	fade	/uploads/optimized/image-1754520520920-273671436.jpg	Суп дня	Вкусный борщ как у мамы	\N	\N	left	/uploads/optimized/image-1754520525923-476233927.jpg	Любимый плов	Всегда актуально, всегда вкусно!	\N	\N	right	/uploads/optimized/image-1754520530610-58990296.jpg	Куринные котлеты	Дополнят любое блюдо	\N	\N	left	/uploads/optimized/image-1754520534929-963180362.jpg	Оливье	Праздник каждый день!	\N	\N	center	/uploads/optimized/image-1754520538852-281866455.jpg	Сырники	Выбор для идеального завтрака	\N	\N	right		שלום! מעוניין במוצרים שלכם.			סכום הזמנה מינימלי למשלוח חינם - 200 ש"ח		hsl(0, 0%, 100%)	default
\.


--
-- Data for Name: translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.translations (id, entity_type, entity_id, field, language, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_addresses (id, user_id, label, address, is_default, created_at, updated_at) FROM stdin;
1	43948959	Дом 	Saadia Gaon 6/2, Haifa	t	2025-06-18 15:16:48.202661	2025-06-18 15:16:48.202661
3	admin	Dom	Stadia Gaon 6, Haifa	t	2025-06-19 11:57:15.993345	2025-06-19 11:57:15.993345
4	manual_1750335030269_29c6n9pl8	Дом	Adress 123	f	2025-06-19 12:10:30.85375	2025-06-19 12:10:30.85375
\.


--
-- Data for Name: user_branches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_branches (id, user_id, branch_id) FROM stdin;
2	worker	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, first_name, last_name, profile_image_url, role, created_at, updated_at, phone, default_address, password, password_reset_token, password_reset_expires, username) FROM stdin;
customer	customer@example.com	Клиент	Тестовый	https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face	customer	2025-06-17 18:18:43.509353	2025-06-19 08:43:46.915		\N	ef99c17ddf145b2e72dd8fdfba9868ab20dff1fc3208c53b6b0098185f41418ffeb6aa51f74fac827f7a3b738f3302d781b140be09028659ee2699db095d32c2.bd8a4b36aa1ceac142e03240e75f7da8	\N	\N	customer
43948959	alexjc55@gmail.com	Alexey	Suzdaltsev	\N	admin	2025-06-17 17:26:49.237417	2025-09-12 14:14:16.968	+972528496528	\N	122c25d0c0aaeae4d00795849f4c17fa9bd24697a6f749c963ec7ec0e9c9b852b6de1e27145855993ad2fc2c8394258e5140871efe59782d86564546ca43a6cb.38de810392475a56ecdd9d81648cbd0c	\N	\N	mainadmin
manual_1750334689091_z1ix5ku2j	aaasssddd@gggfff.com	Asdfgh	Bhhfffgh	\N	customer	2025-06-19 12:04:49.091	2025-06-19 12:04:49.091	12345678887	\N	fd4b5bf667e21d7c82ecc4bbc9a5c7c649ae5e80d6bfd9dafa92fd8db1008fca1fa77e014094465afbfabac9b6a0b8df505ff26a7246a4c19e786b7a8efa3649.b7944b23a417b4321a3de8b49925c635	\N	\N	aaasssddd@gggfff.com
manual_1750335030269_29c6n9pl8	aaawwww@gmail.com	Asfhjkhgh	Tyhkjgf	\N	customer	2025-06-19 12:10:30.269	2025-06-19 12:10:30.269	1234567896543	\N	4f04855f71500dab60309b85941272696bdc7801058df84a08252e16f14c2b52cb7faa147d52df4a1abafd09a10b393146ecd21fcda9433b44a41eaf2eb8031d.d9df7a2d12d49e606690cf9d627dadc9	\N	\N	aaawwww@gmail.com
worker	worker@restaurant.com	Работник	Кухни	https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face	worker	2025-06-17 18:18:43.509353	2026-04-14 08:03:53.93		\N	e87eeb2e2ac8324488ec38dc38bd5126aa573502c3122807877adac947d796722fc11ee276f82bd97ba26954220679b17123a2bbd289242bd2351e5f67575a17.34c7f64554171a937feee163e194bac9	\N	\N	worker
admin	admin@restaurant.com	Администратор	Системы	/uploads/optimized/image-1778529137216-764144112.jpg	admin	2025-06-17 18:18:43.509353	2026-05-11 19:52:21.962	0528496528	\N	57dc1906d8c538edb1bae5f69089c88a2b1ecb4f980fbbe0ef7727a425abca9ff0addbddd31302f386dc53c757c08e1eabee3de795583cdb6743c4215ca35370.6971e6939d9f818b2b502dbd5979bb11	\N	\N	admin
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, false);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.__drizzle_migrations_id_seq', 1, true);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.branches_id_seq', 5, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 61, true);


--
-- Name: closed_dates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.closed_dates_id_seq', 15, true);


--
-- Name: db_clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.db_clusters_id_seq', 2, true);


--
-- Name: marketing_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_notifications_id_seq', 37, true);


--
-- Name: master_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.master_users_id_seq', 1, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 211, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 78, true);


--
-- Name: product_branch_availability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_branch_availability_id_seq', 42, true);


--
-- Name: product_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_categories_id_seq', 126, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 431, true);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 8, true);


--
-- Name: store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_settings_id_seq', 1, true);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tenants_id_seq', 3, true);


--
-- Name: translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.translations_id_seq', 1, false);


--
-- Name: user_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_addresses_id_seq', 10, true);


--
-- Name: user_branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_branches_id_seq', 2, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: closed_dates closed_dates_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.closed_dates
    ADD CONSTRAINT closed_dates_date_key UNIQUE (date);


--
-- Name: closed_dates closed_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.closed_dates
    ADD CONSTRAINT closed_dates_pkey PRIMARY KEY (id);


--
-- Name: db_clusters db_clusters_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_clusters
    ADD CONSTRAINT db_clusters_name_key UNIQUE (name);


--
-- Name: db_clusters db_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_clusters
    ADD CONSTRAINT db_clusters_pkey PRIMARY KEY (id);


--
-- Name: marketing_notifications marketing_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_notifications
    ADD CONSTRAINT marketing_notifications_pkey PRIMARY KEY (id);


--
-- Name: master_users master_users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_users
    ADD CONSTRAINT master_users_email_key UNIQUE (email);


--
-- Name: master_users master_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_users
    ADD CONSTRAINT master_users_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: product_branch_availability product_branch_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_branch_availability
    ADD CONSTRAINT product_branch_availability_pkey PRIMARY KEY (id);


--
-- Name: product_branch_availability product_branch_availability_product_id_branch_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_branch_availability
    ADD CONSTRAINT product_branch_availability_product_id_branch_id_key UNIQUE (product_id, branch_id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_product_id_category_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_product_id_category_id_key UNIQUE (product_id, category_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: store_settings store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_settings
    ADD CONSTRAINT store_settings_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_custom_domain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_custom_domain_key UNIQUE (custom_domain);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_subdomain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_subdomain_key UNIQUE (subdomain);


--
-- Name: themes themes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.themes
    ADD CONSTRAINT themes_pkey PRIMARY KEY (id);


--
-- Name: translations translations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.translations
    ADD CONSTRAINT translations_pkey PRIMARY KEY (id);


--
-- Name: user_addresses user_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_addresses
    ADD CONSTRAINT user_addresses_pkey PRIMARY KEY (id);


--
-- Name: user_branches user_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_pkey PRIMARY KEY (id);


--
-- Name: user_branches user_branches_user_id_branch_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_user_id_branch_id_key UNIQUE (user_id, branch_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: orders_guest_access_token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX orders_guest_access_token_unique ON public.orders USING btree (guest_access_token) WHERE (guest_access_token IS NOT NULL);


--
-- Name: orders_guest_claim_token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX orders_guest_claim_token_unique ON public.orders USING btree (guest_claim_token) WHERE (guest_claim_token IS NOT NULL);


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_items order_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders orders_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: orders orders_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: product_branch_availability product_branch_availability_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_branch_availability
    ADD CONSTRAINT product_branch_availability_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: product_branch_availability product_branch_availability_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_branch_availability
    ADD CONSTRAINT product_branch_availability_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_categories product_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: product_categories product_categories_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: user_addresses user_addresses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_addresses
    ADD CONSTRAINT user_addresses_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_branches user_branches_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: user_branches user_branches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict RjeUBRLuaKpoeGtdvFjjdS6p04vxoFzvSUChgNJlpLpNGoOkhwd3pKOnBsn7UBu

