var $ = jQuery.noConflict();
var notyf = new Notyf({
	duration: 200000,
	ripple: false,
	position: { x: 'right', y: 'top' },
	dismissible: true,
});

$(document).ready(function () {
	$(document).on('click', '#automation .toggle_link li a', function(e){
		var _this = $(this);
		$('#automation .toggle_link li a').removeClass('active');
		_this.addClass('active');
	});

	$(document).on('click', '#automation .create_webhook', function(e){
		e.preventDefault();
		$('.popup_webhook_added').addClass('open');
	});
	$(document).on('click', '.popup_webhook_added .bg,.popup_webhook_added .close_book_pop', function(e){
		e.preventDefault();
		$('.popup_webhook_added').removeClass('open');
		$('.popup_webhook_added form').trigger('reset');
		$('.popup_webhook_added form .events_containts').css('display', 'none');
		$('.popup_webhook_added form').find('.edit_item_id').empty();
	});

	function events_radio(){
		if ($('#eventselection').is(':checked')) {
			$('.popup_webhook_added .webhook_containt .events_containts').css('display', 'flex');
		} else {
			$('.popup_webhook_added .webhook_containt .events_containts').css('display', 'none');
		}
	};

	events_radio();

	$('.events_radio input[type="radio"]').on('change', function () {
		events_radio();
	});


	if($('.daterangepicker_col').length > 0){
		$(function() {
			$('#daterange').daterangepicker({
			  locale: {
				format: 'DD/MM/YYYY'
			  },
			  opens: 'right'
			}, function(start, end, label) {
			  console.log("Selected range: " + start.format('DD/MM/YYYY') + ' to ' + end.format('DD/MM/YYYY'));
			});
		  });
	}

	let curr_url = window.location.href;
	$(document).on('click', '.tabbing .tab-list .tab-title', function(e){
		e.preventDefault();
		let target = $(this).attr('data-tab');
		$('.tabbing .tab-list .tab-title').removeClass('active');
		$(this).addClass('active');
		$('.tabbing .tab-content').removeClass('active');
		$('.tabbing .tab-content#'+target).addClass('active');

		let url = new URL(curr_url);
		url.searchParams.set('tab', target);
		window.history.replaceState({}, '', url);
	});

	$(document).on('submit', 'form.add_webhook', function (e) {
		e.preventDefault();
		var formData = $(this).serializeArray();
		let button = $(this).find('[type="submit"]');
		let $this = $(this);

		$.ajax({
			type: 'POST',
			url: grow_params.ajax_url,
			dataType: 'json',
			data: formData,
			beforeSend: function () {
				button.addClass('loading');
				notyf.dismissAll();
				$this.find(".error").removeClass("error");
			},
			success: function (response) {
				button.removeClass('loading');
				if (response.success) {
					notyf.success(response.data.message);
					$('.popup_webhook_added').removeClass('open');
					$('.popup_webhook_added form').trigger('reset');
					$('.popup_webhook_added form .events_containts').css('display', 'none');

					setTimeout(() => {
						location.reload();
					}, 1500);

				} else {
					notyf.error({
						message: response.data.message,
					});
					if (typeof response.data.error_fields !== 'undefined') {
						$.each(response.data.error_fields, function (index, item) {
							$this.find('input[name="' + index + '"]').addClass("error");
						});
					}
				}

			},
			error: function (error) {
				console.log(error);
			}
		});

	});

	$(document).on('click', '.table_contain .edit-webhook', function (e) {
		e.preventDefault();
		let id = $(this).attr('data-id');
		let button = $(this);

		$.ajax({
			type: 'POST',
			url: grow_params.ajax_url,
			dataType: 'json',
			data: {
				action: 'meshulam_get_webhook_ajax',
				id: id,
			},
			beforeSend: function () {
				button.addClass('loading');
				notyf.dismissAll();

			},
			success: function (response) {
				button.removeClass('loading');
				if (response.success){
					$('form.add_webhook').find('[name="webhook_name"]').val(response.data.webhook.name);
					$('form.add_webhook').find('[name="webhook_url"]').val(response.data.webhook.url);
					$('form.add_webhook').find('[name="webhook_secret_code"]').val(response.data.webhook.secret_code);
					$('form.add_webhook').find('[name="webhook_platform"]').val(response.data.webhook.platform);
					$('form.add_webhook').find('.edit_item_id').html('<input type="hidden" name="edit_id" value="'+id+'">');

					if (response.data.webhook.field_type == 'specific_fields'){
						$('form.add_webhook').find('[name="field_type"][value="specific_fields"]').trigger('click');
						if (response.data.webhook.specific_field){
							$.each(response.data.webhook.specific_field, function (index, item) {
								$('.events_containts input[name="specific_selected_field[]"][value="'+item+'"]').trigger('click');
							});
						}
					}else{
						$('form.add_webhook').find('[name="field_type"][value="all_fields"]').trigger('click');
					}

					$('.popup_webhook_added').addClass('open');
				}
			},
			error: function (error) {
				console.log(error);
			}
		});


	});

	$(document).on('submit', '#activation form', function(e){
		e.preventDefault();

		let email = $(this).find('#meshulam_payment_user_email').val();
		let access_key = $(this).find('#meshulam_payment_user_access_key').val();
		let button = $(this).find('[type="submit"]');

		$.ajax({
			type: 'POST',
			url: grow_params.ajax_url,
			dataType: 'json',
			data: {
				action: 'meshulam_activation_ajax',
				email: email,
				access_key: access_key
			},
			beforeSend: function () {
				button.addClass('loading');
				notyf.dismissAll();
			},
			success: function (response) {
				button.removeClass('loading');
				console.log(response);

				if (response.success) {
					notyf.success(response.data.message);
				} else {
					notyf.error({
						message: response.data.message,
					});
				}

			},
			error: function (error) {
				console.log(error);
			}
		});

	});

	$(document).on('submit', '#checkout-settings form', function (e) {
		e.preventDefault();

		let formData = new FormData(this);
		let button = $(this).find('[type="submit"]');

		$.ajax({
			type: 'POST',
			url: grow_params.ajax_url,
			data: formData,
			contentType: false,
			processData: false,
			beforeSend: function () {
				button.addClass('loading');
				notyf.dismissAll();
			},
			success: function (response) {
				button.removeClass('loading');
				console.log(response);

				if (response.success) {
					notyf.success(response.data.message);
				} else {
					notyf.error({
						message: response.data.message,
					});
				}

			},
			error: function (error) {
				console.log(error);
			}
		});

	});

	$(document).on("click", ".meshulam_j5_release", function(e){
		e.preventDefault();
		let $this = $(this);
		let order_id = $this.attr("data-id");
		$.ajax({
			type: 'POST',
			url: grow_params.ajax_url,
			dataType: 'json',
			data: {
				order_id: order_id,
				action: "meshulam_j5_release_ajax",
			},
			beforeSend: function () {
				$this.addClass('loading');
			},
			success: function (response) {
				$this.removeClass('loading');
				if (response.status){
					notyf.success(response.message);

					setTimeout(() => {
						location.reload();
					}, 2000);
				}else{
					notyf.error({
						message: '<p dir="rtl">' + response.message +'</p>',
						icon: false,
					});
				}

			},
			error: function (error) {
				console.log(error);
			}
		});
	});

	var getUrlParameter = function getUrlParameter(sParam) {
		var sPageURL = window.location.search.substring(1),
			sURLVariables = sPageURL.split('&'),
			sParameterName,
			i;
		for (i = 0; i < sURLVariables.length; i++) {
			sParameterName = sURLVariables[i].split('=');
			if (sParameterName[0] === sParam) {
				return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
			}
		}
	};

	if (getUrlParameter('section') == 'meshulam-payment' || getUrlParameter('section') == 'bitpay-payment' || getUrlParameter('section') == 'apple-payment' || getUrlParameter('section') == 'cal-payment' || getUrlParameter('section') == 'googlepay-payment' || getUrlParameter('section') == 'grow-wallet-payment') {
		if ($("#woocommerce_meshulam-payment_j5_mode").hasClass('hide-input')) {
			$('#woocommerce_meshulam-payment_j5_mode').parents('tr').hide();
		}
		if ($("#woocommerce_bitpay-payment_j5_mode").hasClass('hide-input')) {
			$('#woocommerce_bitpay-payment_j5_mode').parents('tr').hide();
		}
		if ($("#woocommerce_apple-payment_j5_mode").hasClass('hide-input')) {
			$('#woocommerce_apple-payment_j5_mode').parents('tr').hide();
		}
		if ($("#woocommerce_grow-wallet-payment_j5_mode").hasClass('hide-input')) {
			$('#woocommerce_grow-wallet-payment_j5_mode').parents('tr').hide();
		}
		if ($("#woocommerce_grow-wallet-payment_refund_mode").hasClass('hide-input')) {
			$('#woocommerce_grow-wallet-payment_refund_mode').parents('tr').hide();
		}
		if ($("#woocommerce_cal-payment_j5_mode").hasClass('hide-input')) {
			$('#woocommerce_cal-payment_j5_mode').parents('tr').hide();
		}
		if ($("#woocommerce_googlepay-payment_refund_mode").hasClass('hide-input')) {
			$('#woocommerce_googlepay-payment_refund_mode').parents('tr').hide();
		}


		if ($("#woocommerce_meshulam-payment_refund_mode").hasClass('hide-input')) {
			$('#woocommerce_meshulam-payment_refund_mode').parents('tr').hide();
		}
		if ($("#woocommerce_bitpay-payment_refund_mode").hasClass('hide-input')) {
			$('#woocommerce_bitpay-payment_refund_mode').parents('tr').hide();
		}
		if ($("#woocommerce_apple-payment_refund_mode").hasClass('hide-input')) {
			$('#woocommerce_apple-payment_refund_mode').parents('tr').hide();
		}
		if ($("#woocommerce_cal-payment_refund_mode").hasClass('hide-input')) {
			$('#woocommerce_cal-payment_refund_mode').parents('tr').hide();
		}
		if ($("#woocommerce_googlepay-payment_refund_mode").hasClass('hide-input')) {
			$('#woocommerce_googlepay-payment_refund_mode').parents('tr').hide();
		}
		$('#woocommerce_meshulam-payment_wrap_detail,#woocommerce_meshulam-payment_wrap_detail+.form-table,#woocommerce_meshulam-payment_thank_you_page_details,#woocommerce_meshulam-payment_thank_you_page_details+.form-table').wrapAll("<div class='meshulam_left_col'></div>");
		$('#woocommerce_apple-payment_wrap_detail,#woocommerce_apple-payment_wrap_detail+.form-table,#woocommerce_apple-payment_thank_you_page_details,#woocommerce_apple-payment_thank_you_page_details+.form-table').wrapAll("<div class='meshulam_left_col'></div>");
		$('#woocommerce_cal-payment_wrap_detail,#woocommerce_cal-payment_wrap_detail+.form-table,#woocommerce_cal-payment_thank_you_page_details,#woocommerce_cal-payment_thank_you_page_details+.form-table').wrapAll("<div class='meshulam_left_col'></div>");
		$('#woocommerce_googlepay-payment_wrap_detail,#woocommerce_googlepay-payment_wrap_detail+.form-table,#woocommerce_googlepay-payment_thank_you_page_details,#woocommerce_googlepay-payment_thank_you_page_details+.form-table').wrapAll("<div class='meshulam_left_col'></div>");
		$('#woocommerce_meshulam-bit-payment_wrap_detail,#woocommerce_meshulam-bit-payment_wrap_detail+.form-table,#woocommerce_bitpay-payment_thank_you_page_details,#woocommerce_bitpay-payment_thank_you_page_details+.form-table').wrapAll("<div class='meshulam_left_col'></div>");
		$('#woocommerce_grow-wallet-payment_wrap_detail,#woocommerce_grow-wallet-payment_wrap_detail+.form-table,#woocommerce_grow-wallet-payment_thank_you_page_details,#woocommerce_grow-wallet-payment_thank_you_page_details+.form-table').wrapAll("<div class='meshulam_left_col'></div>");
		$('.meshulam_left_col').children().wrapAll("<div class='wrapper'></div>");
		$('.woocommerce table.form-table:first,#woocommerce_meshulam-payment_paymentsettings,#woocommerce_meshulam-payment_paymentsettings+.form-table').wrapAll("<div class='meshulam_right_col'></div>");
		$('.woocommerce table.form-table:first,#woocommercemeshulam-bit-payment_meshulam-bit-payment_paymentsettings,#woocommerce_meshulam-bit-payment_paymentsettings+.form-table').wrapAll("<div class='meshulam_right_col'></div>");
		$('.woocommerce table.form-table:first,#woocommerce_grow-wallet-payment_paymentsettings,#woocommerce_grow-wallet-payment_paymentsettings+.form-table').wrapAll("<div class='meshulam_right_col'></div>");
	}

	$('#woocommerce_meshulam-payment_maxpayment').parents('tr').hide();
	$('#woocommerce_grow-wallet-payment_maxpayment').parents('tr').hide();
	$('#woocommerce_apple-payment_maxpayment').parents('tr').hide();
	$('#woocommerce_cal-payment_maxpayment').parents('tr').hide();
	$('#woocommerce_googlepay-payment_maxpayment').parents('tr').hide();
	/* check payment type */
	if ($('#woocommerce_meshulam-payment_payment_type').val() == 'regular_1') {
		$('.meshulam_acc').hide();
		$('#woocommerce_meshulam-payment_maxpayment').prop('readonly', true);
	} else {

	}
	//check payment type on page load and hide next div
	$('#woocommerce_grow-wallet-payment_payment_type :selected').each(function (i) {
		if ($(this).val() == 'payments_4') {
			$('#woocommerce_grow-wallet-payment_maxpayment').parents('tr').show();
		}
	});
	$('#woocommerce_meshulam-payment_payment_type :selected').each(function (i) {
		if ($(this).val() == 'payments_4') {
			$('#woocommerce_meshulam-payment_maxpayment').parents('tr').show();
		}
	});
	$('#woocommerce_apple-payment_payment_type :selected').each(function (i) {
		if ($(this).val() == 'payments_4') {
			$('#woocommerce_apple-payment_maxpayment').parents('tr').show();
		}
	});
	$('#woocommerce_cal-payment_payment_type :selected').each(function (i) {
		if ($(this).val() == 'payments_4') {
			$('#woocommerce_cal-payment_maxpayment').parents('tr').show();
		}
	});
	$('#woocommerce_googlepay-payment_payment_type :selected').each(function (i) {
		if ($(this).val() == 'payments_4') {
			$('#woocommerce_googlepay-payment_maxpayment').parents('tr').show();
		}
	});
	$('.meshulam_left_col input,.meshulam_right_col input').each(function () {
		$(this).attr('autocomplete', 'false');
	})
	if ($("#woocommerce_meshulam-payment_j5_mode").length != 0) {
		var j5check = document.getElementById("woocommerce_meshulam-payment_j5_mode");
		if (j5check.checked == true) {
			$('#woocommerce_meshulam-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_meshulam-payment_order_status').parents('tr').show();
		}
	}
	/* on change */
	$('#woocommerce_meshulam-payment_j5_mode').change(function () {
		if (this.checked == true) {
			$('#woocommerce_meshulam-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_meshulam-payment_order_status').parents('tr').show();
		}
	});
	if ($("#woocommerce_bitpay-payment_j5_mode").length != 0) {
		var j5check = document.getElementById("woocommerce_bitpay-payment_j5_mode");
		if (j5check.checked == true) {
			$('#woocommerce_meshulam-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_meshulam-payment_order_status').parents('tr').show();
		}
	}
	/* on change */
	$('#woocommerce_bitpay-payment_j5_mode').change(function () {
		if (this.checked == true) {
			$('#woocommerce_bitpay-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_bitpay-payment_order_status').parents('tr').show();
		}
	});
	if ($("#woocommerce_apple-payment_j5_mode").length != 0) {
		var j5check = document.getElementById("woocommerce_apple-payment_j5_mode");
		if (j5check.checked == true) {
			$('#woocommerce_apple-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_apple-payment_order_status').parents('tr').show();
		}
	}
	/* on change */
	$('#woocommerce_apple-payment_j5_mode').change(function () {
		if (this.checked == true) {
			$('#woocommerce_apple-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_apple-payment_order_status').parents('tr').show();
		}
	});

	if ($("#woocommerce_cal-payment_j5_mode").length != 0) {
		var j5check = document.getElementById("woocommerce_cal-payment_j5_mode");
		if (j5check.checked == true) {
			$('#woocommerce_cal-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_cal-payment_order_status').parents('tr').show();
		}
	}
	/* on change */
	$('#woocommerce_cal-payment_j5_mode').change(function () {
		if (this.checked == true) {
			$('#woocommerce_cal-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_cal-payment_order_status').parents('tr').show();
		}
	});
	if ($("#woocommerce_googlepay-payment_j5_mode").length != 0) {
		var j5check = document.getElementById("woocommerce_googlepay-payment_j5_mode");
		if (j5check.checked == true) {
			$('#woocommerce_googlepay-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_googlepay-payment_order_status').parents('tr').show();
		}
	}
	/* on change */
	$('#woocommerce_googlepay-payment_j5_mode').change(function () {
		if (this.checked == true) {
			$('#woocommerce_googlepay-payment_order_status').parents('tr').hide();
		} else {
			$('#woocommerce_googlepay-payment_order_status').parents('tr').show();
		}
	});

	$('#woocommerce_grow-wallet-payment_payment_type').change(function () {
		$('#woocommerce_grow-wallet-payment_maxpayment').parents('tr').hide();
		$('#woocommerce_grow-wallet-payment_maxpayment').val('0').change();
		if ($(this).val() == 'regular_1') {
			$('.meshulam_acc').hide();
		} else {
			if ($(this).val() == 'direct_debit_2') {
			} else {
				$('#woocommerce_grow-wallet-payment_maxpayment').attr('max', 12);
			}
		}

		$('#woocommerce_grow-wallet-payment_payment_type :selected').each(function (i) {
			if ($(this).val() == 'payments_4') {
				$('#woocommerce_grow-wallet-payment_maxpayment').parents('tr').show();
			}
		});

	})
	$('#woocommerce_meshulam-payment_payment_type').change(function () {
		$('#woocommerce_meshulam-payment_maxpayment').parents('tr').hide();
		if ($(this).val() == 'regular_1') {
			$('.meshulam_acc').hide();
		} else {
			if ($(this).val() == 'direct_debit_2') {
			} else {
				$('#woocommerce_meshulam-payment_maxpayment').attr('max', 12);
			}
		}
		$('#woocommerce_meshulam-payment_payment_type :selected').each(function (i) {
			if ($(this).val() == 'payments_4') {
				$('#woocommerce_meshulam-payment_maxpayment').parents('tr').show();
			}
		});
	})
	$('#woocommerce_apple-payment_payment_type').change(function () {
		$('#woocommerce_apple-payment_maxpayment').parents('tr').hide();
		$('#woocommerce_apple-payment_payment_type :selected').each(function (i) {
			if ($(this).val() == 'payments_4') {
				$('#woocommerce_apple-payment_maxpayment').parents('tr').show();
			}
		});
	})
	$('#woocommerce_cal-payment_payment_type').change(function () {
		$('#woocommerce_cal-payment_maxpayment').parents('tr').hide();
		$('#woocommerce_cal-payment_payment_type :selected').each(function (i) {
			if ($(this).val() == 'payments_4') {
				$('#woocommerce_cal-payment_maxpayment').parents('tr').show();
			}
		});
	})
	$('#woocommerce_googlepay-payment_payment_type').change(function () {
		$('#woocommerce_googlepay-payment_maxpayment').parents('tr').hide();
		$('#woocommerce_googlepay-payment_payment_type :selected').each(function (i) {
			if ($(this).val() == 'payments_4') {
				$('#woocommerce_googlepay-payment_maxpayment').parents('tr').show();
			}
		});
	})
	$('input[value="meshulam_pay_card_token_detail"]').parents('tr').hide();
	$('input[value="meshulam_pay_payment-type"]').parents('tr').hide();
	$('input[value="meshulam_pay_save_card"]').parents('tr').hide();
	$('input[value="meshulam_pay_transaction-id"]').parents('tr').hide();
	$('input[value="meshulam_pay_payment-number"]').parents('tr').hide();
	$('input[value="meshulam-pay-description"]').parents('tr').hide();
	$('input[value="transactionid"]').parents('tr').hide();
	$('input[value="payment_transaction_id"]').parents('tr').hide();

	$('.woocommerce .meshulam_right_col table.form-table select[multiple]').multiselect({
		buttonWidth: '160px',
		includeSelectAllOption: true,
		nonSelectedText: 'Select an Option'
	});

	if ($('#woocommerce_meshulam-payment_business_owner_code').val() != '' && $('#woocommerce_meshulam-payment_payment_type').val() != '' && $('#woocommerce_meshulam-payment_fail_url').val() != '' && $('#woocommerce_meshulam-payment_thank_you_page').val() != '') {
	} else {
	}

	if ($('input#woocommerce_bitpay-payment_show_thank_you_detail').is(':checked')) {
		$('#woocommerce_bitpay-payment_thank_you_page').parents('tr').show();
		$('#woocommerce_bitpay-payment_fail_url').parents('tr').show();
	}
	else {
		$('#woocommerce_bitpay-payment_thank_you_page').parents('tr').hide();
		$('#woocommerce_bitpay-payment_fail_url').parents('tr').hide();
	}

	if ($('input#woocommerce_meshulam-payment_show_thank_you_detail').is(':checked')) {
		$('#woocommerce_meshulam-payment_thank_you_page').parents('tr').show();
		$('#woocommerce_meshulam-payment_fail_url').parents('tr').show();
	} else {
		$('#woocommerce_meshulam-payment_thank_you_page').parents('tr').hide();
		$('#woocommerce_meshulam-payment_fail_url').parents('tr').hide();
	}

	$('input#woocommerce_bitpay-payment_show_thank_you_detail').change(function () {
		if ($(this).is(':checked')) {
			$('#woocommerce_bitpay-payment_thank_you_page').parents('tr').show();
			$('#woocommerce_bitpay-payment_fail_url').parents('tr').show();
		} else {
			$('#woocommerce_bitpay-payment_thank_you_page').parents('tr').hide();
			$('#woocommerce_bitpay-payment_fail_url').parents('tr').hide();
		}
	});

	$('input#woocommerce_meshulam-payment_show_thank_you_detail').change(function () {
		if ($(this).is(':checked')) {
			$('#woocommerce_meshulam-payment_thank_you_page').parents('tr').show();
			$('#woocommerce_meshulam-payment_fail_url').parents('tr').show();
		} else {
			$('#woocommerce_meshulam-payment_thank_you_page').parents('tr').hide();
			$('#woocommerce_meshulam-payment_fail_url').parents('tr').hide();
		}
	});

});

function getSelectedValues() {
	var selectedVal = $(".woocommerce .meshulam_right_col table.form-table select[multiple]").val();
	for (var i = 0; i < selectedVal.length; i++) {
		function innerFunc(i) {
			setTimeout(function () {
				location.href = selectedVal[i];
			}, i * 2000);
		}
		innerFunc(i);
	}
}