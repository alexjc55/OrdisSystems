var $ = jQuery.noConflict();

$(document).ready(function(){
    if($('p.woocommerce-notice.woocommerce-notice--error.woocommerce-thankyou-order-failed').length > 0){
        $('.entry-title').css('display','none');
    }
});

$(document).ready(function(){
	if($('#meshulam_recurring').is(':checked')){
		$('.meshulam-installment-tab_options').show();
	}
	else{
		$('.meshulam-installment-tab_options').hide();
	}
    $('#meshulam_recurring').change(function(){
		if($(this).is(':checked')){
			$('.meshulam-installment-tab_options').show();
		}else{
            $('#_meshulam_checkbox_field').prop('checked', false);
            $('#_meshulam_pay_field').val('');
			$('.meshulam-installment-tab_options').hide();
		}
	})
});