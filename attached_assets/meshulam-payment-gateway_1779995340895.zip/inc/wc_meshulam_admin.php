<?php

add_action('admin_menu', 'meshulam_options_page');
function meshulam_options_page() {

    $icon = 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 12.995 15.67"> <path d="M127.367,1.046a5.351,5.351,0,0,0-6.978,5.061,5.417,5.417,0,0,0,.04.655,5.344,5.344,0,0,0,3.556,4.393c.063.022.126.043.19.061a5.388,5.388,0,0,0,3.121,0c.068-.02.136-.042.2-.065a5.321,5.321,0,0,0-.13-10.111M128.9,6.7a3.214,3.214,0,1,1,.054-.592,3.209,3.209,0,0,1-.054.592" transform="translate(-119.165 -0.798)" fill="#fff"/> <path d="M126.741,52.808a7.059,7.059,0,0,0-10.677,0,6.885,6.885,0,0,0-1.141,1.852.226.226,0,0,0,.21.311h2.128a.228.228,0,0,0,.193-.109,4.653,4.653,0,0,1,7.9,0,.228.228,0,0,0,.193.109h2.128a.226.226,0,0,0,.21-.311,6.886,6.886,0,0,0-1.141-1.852" transform="translate(-114.905 -39.302)" fill="#fff"/> </svg>');
    add_menu_page( 'Grow Pay', 'Grow Pay', 'manage_options', 'meshulam-payment-setting', 'meshulam_options_page_html', $icon, 20 );
}

function meshulam_options_page_html() {
    ?>

    <div class="wrap meshulam_">
        <h2></h2>
        <div class="title_logo">
            <h3><?php _e('GROW Payment Gateway', 'meshulam-payment-gateway'); ?></h3>
            <div class="logo">
                <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/main_logo.svg'; ?>" alt="Main Logo">
                <span><?php esc_html_e('New banking, for people with businesses.', 'meshulam-payment-gateway'); ?></span>
            </div>
        </div>

        <div class="tabbing">

            <div class="btn-section">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ); ?>">
                    <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/setting-icon.svg'; ?>" alt="Setting Icon">
                    <?php esc_html_e('Plugin Settings', 'meshulam-payment-gateway'); ?>
                </a>
                <a href="<?php echo esc_url( MESHULAM_GUIDE_URL ); ?>" target="_blank"><?php esc_html_e('Plugin Guides', 'meshulam-payment-gateway'); ?></a>
            </div>


            <div class="tab-list">

                <?php /* ?>
                <span data-tab="dashboard" class="tab-title<?php if( isset($_GET['tab']) && $_GET['tab']=='dashboard'){ echo ' active'; }elseif( !isset($_GET['tab']) ){ echo ' active'; } ?>"><?php esc_html_e('Dashboard', 'meshulam-payment-gateway'); ?></span>
                <?php */ ?>

                <span data-tab="activation" class="tab-title<?php if( isset($_GET['tab']) && $_GET['tab']=='activation'){ echo ' active'; }elseif( !isset($_GET['tab']) ){ echo ' active'; } ?>"><?php esc_html_e('Activation', 'meshulam-payment-gateway'); ?></span>

                <span data-tab="checkout-settings" class="tab-title<?php if( isset($_GET['tab']) && $_GET['tab']=='checkout-settings'){ echo ' active'; } ?>"><?php esc_html_e('Checkout Settings', 'meshulam-payment-gateway'); ?></span>

                <?php /* ?>
                <span data-tab="automation" class="tab-title<?php if( isset($_GET['tab']) && $_GET['tab']=='automation'){ echo ' active'; } ?>"><?php esc_html_e('Automation', 'meshulam-payment-gateway'); ?></span>
                <?php */ ?>

            </div>

            <div class="tab-content-wrap">

                <?php /* ?>
                <div class="tab-content<?php if( isset($_GET['tab']) && $_GET['tab']=='dashboard'){ echo ' active'; }elseif( !isset($_GET['tab']) ){ echo ' active'; } ?>" id="dashboard">
                    <div class="inner">
                        <div class="colin">
                            <h3><?php esc_html_e('Payment Methods', 'meshulam-payment-gateway'); ?></h3>
                            <?php
                            $args = array(
                                'limit'     => -1,
                                'status'    => ['wc-completed', 'wc-processing']
                            );
                            $orders = wc_get_orders( $args );
                            $payment_counts = [];
                            $total_sales = 0;
                            $total_orders = 0;
                            $total_time = 0;
                            $count = 0;

                            if( !empty($orders) ){
                                foreach( $orders as $key => $order ){
                                    $total_sales += $order->get_total();
                                    $total_orders++;

                                    $duration = $order->get_meta( '_checkout_duration' );
                                    if ( $duration !== '' && is_numeric($duration) ) {
                                        $total_time += floatval( $duration );
                                        $count++;
                                    }

                                    $payment_method = $order->get_payment_method();
                                    if ( !isset( $payment_counts[ $payment_method ] ) ) {
                                        $payment_counts[ $payment_method ] = 0;
                                    }

                                    if ( !isset( $payment_counts[ 'banktransfer-payment' ] ) ) {
                                        $payment_counts[ 'banktransfer-payment' ] = 0;
                                    }

                                    if( $payment_method == 'grow-wallet-payment' ){
                                        $wallet_payment_title = $order->get_meta('wallet_payment_title');

                                        if( $wallet_payment_title == 'Grow Wallet Credit Card'){
                                            $payment_counts['meshulam-payment']++;
                                        }
                                        elseif( $wallet_payment_title == 'Grow Wallet Bit'){
                                            $payment_counts['bitpay-payment']++;
                                        }
                                        elseif( $wallet_payment_title == 'Grow Wallet Apple Pay'){
                                            $payment_counts['apple-payment']++;
                                        }
                                        elseif( $wallet_payment_title == 'Grow Wallet Google Pay'){
                                            $payment_counts['googlepay-payment']++;
                                        }
                                        elseif( $wallet_payment_title == 'Grow Wallet Bank Transfer'){
                                            $payment_counts['banktransfer-payment']++;
                                        }
                                    }

                                    $payment_counts[ $payment_method ]++;

                                }
                            }
                            ?>
                            <div class="mid_col">
                                <ul>

                                    <?php if( !empty($payment_counts['meshulam-payment']) ) : ?>
                                    <li>
                                        <span><img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/visa.svg'; ?>" alt="Meshulam CC Logo"></span>
                                        <h4><?php echo number_format($payment_counts['meshulam-payment']); ?></h4>
                                    </li>
                                    <?php endif; ?>

                                    <?php if( !empty($payment_counts['apple-payment']) ) : ?>
                                    <li>
                                        <span><img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/pay.svg'; ?>" alt="ApplePay Logo"></span>
                                        <h4><?php echo number_format($payment_counts['apple-payment']); ?></h4>
                                    </li>
                                    <?php endif; ?>

                                    <?php if( !empty($payment_counts['googlepay-payment']) ) : ?>
                                    <li>
                                        <span><img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/g-pay1.svg'; ?>" alt="GPay Logo"></span>
                                        <h4><?php echo number_format($payment_counts['googlepay-payment']); ?></h4>
                                    </li>
                                    <?php endif; ?>

                                    <?php if( !empty($payment_counts['bitpay-payment']) ) : ?>
                                    <li>
                                        <span><img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/bitz.svg'; ?>" alt="Bit Logo"></span>
                                        <h4><?php echo number_format($payment_counts['bitpay-payment']); ?></h4>
                                    </li>
                                    <?php endif; ?>

                                    <?php if( !empty($payment_counts['banktransfer-payment']) ) : ?>
                                    <li>
                                        <span><img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/he_pay.svg'; ?>" alt="BankTransfer Logo"></span>
                                        <h4><?php echo number_format($payment_counts['banktransfer-payment']); ?></h4>
                                    </li>
                                    <?php endif; ?>

                                </ul>
                            </div>
                            <div class="bottom_col">
                                <h6><?php esc_html_e('Data showing number of purchases', 'meshulam-payment-gateway'); ?></h6>
                                <span><?php esc_html_e('Automatically updated', 'meshulam-payment-gateway'); ?></span>
                            </div>
                        </div>
                        <div class="colin">
                            <h3><?php esc_html_e('Average Checkout Time', 'meshulam-payment-gateway'); ?></h3>
                            <div class="mid_col">
                                <div class="svg_col">
                                    <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/graph_svg1.svg'; ?>" alt="graph_svg1">
                                    <div class="datak">
                                        <h4><?php esc_html_e('From Date', 'meshulam-payment-gateway'); ?>: <?php echo get_first_order_date_all_orders(); ?></h4>

                                        <?php if ( $count > 0 ) { ?>
                                        <h5><?php $average_min = $total_time / $count; echo gmdate( 'i.s', (int) round($average_min) ); ?>
                                            <sub><?php esc_html_e('minutes', 'meshulam-payment-gateway'); ?></sub>
                                        </h5>
                                        <?php } ?>

                                    </div>
                                </div>
                            </div>
                            <div class="bottom_col">
                                <h6><?php esc_html_e( 'The graph shows current data for', 'meshulam-payment-gateway' ); ?> <?php echo wp_date('d.m.Y'); ?></h6>
                                <span><?php esc_html_e( 'The graph is updated automatically every day', 'meshulam-payment-gateway' ); ?></span>
                            </div>
                        </div>
                        <div class="colin">
                            <h3><?php esc_html_e('Total Entries', 'meshulam-payment-gateway'); ?></h3>
                            <div class="mid_col">
                                <div class="svg_col">
                                    <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/graph_svg2.svg'; ?>" alt="graph_svg2">
                                    <div class="datak">
                                        <h4><?php esc_html_e('From Date', 'meshulam-payment-gateway'); ?>: <?php echo get_first_order_date_all_orders(); ?></h4>
                                        <h5><?php echo number_format($total_orders); ?></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="bottom_col">
                                <h6><?php esc_html_e('The graph shows current data for', 'meshulam-payment-gateway'); ?> <?php echo wp_date('d.m.Y'); ?></h6>
                                <span><?php esc_html_e('The graph is updated automatically every day', 'meshulam-payment-gateway'); ?></span>
                            </div>
                        </div>
                        <div class="colin">
                            <h3><?php esc_html_e('Total Sales', 'meshulam-payment-gateway'); ?></h3>
                            <div class="mid_col">
                                <div class="svg_col">
                                    <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/graph_svg3.svg'; ?>" alt="graph_svg3">
                                    <div class="datak">
                                        <h4><?php esc_html_e('From Date', 'meshulam-payment-gateway'); ?>: <?php echo get_first_order_date_all_orders(); ?></h4>
                                        <h5><?php echo wc_price( $total_sales ); ?></h5>
                                    </div>
                                </div>
                            </div>
                            <div class="bottom_col">
                                <h6><?php esc_html_e('The graph shows current data for', 'meshulam-payment-gateway'); ?> <?php echo wp_date('d.m.Y'); ?></h6>
                                <span><?php esc_html_e('The graph is updated automatically every day', 'meshulam-payment-gateway'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php */ ?>

                <div class="tab-content<?php if( isset($_GET['tab']) && $_GET['tab']=='activation'){ echo ' active'; }elseif( !isset($_GET['tab']) ){ echo ' active'; } ?>" id="activation">
                    <form method="post" id="mainform" action="" enctype="multipart/form-data">
                        <div class="meshulam_wrapper">
                            <table class="form-table">
                                <tbody>

                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="meshulam_payment_user_email"><?php _e('Email', 'meshulam-payment-gateway');?></label>
                                        </th>
                                        <td>
                                            <input type="email" name="meshulam_payment_user_email" id="meshulam_payment_user_email" value="<?php echo esc_attr(get_option('meshulam_payment_user_email')); ?>">
                                            <span class="description">
                                                <?php _e('The email address you used to register for grow', 'meshulam-payment-gateway');?>
                                            </span>
                                        </td>
                                    </tr>

                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="meshulam_payment_user_access_key"><?php _e('Licence Key', 'meshulam-payment-gateway');?></label>
                                        </th>
                                        <td>
                                            <input type="hidden" name="meshulam_payment_user_response" value="<?php echo esc_attr(get_option('meshulam_payment_user_response')); ?>">
                                            <input type="text" name="meshulam_payment_user_access_key" id="meshulam_payment_user_access_key" value="<?php echo esc_attr(get_option('meshulam_payment_user_access_key')); ?>" required>
                                            <span class="description">Licence Key</span>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                            <p class="submit">
                                <button type="submit" name="submit" class="button button-primary">
                                    <?php esc_html_e('Save Changes', 'meshulam-payment-gateway'); ?>
                                </button>
                            </p>
                        </div>
                    </form>
                </div>

                <div class="tab-content<?php if( isset($_GET['tab']) && $_GET['tab']=='checkout-settings'){ echo ' active'; } ?>" id="checkout-settings">
                    <form method="post" id="mainform" action="" enctype="multipart/form-data">
                        <div class="meshulam_wrapper">
                            <table class="form-table">
                                <tbody>

                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="id_or_company_number"><?php esc_html_e('ID/Company Number', 'meshulam-payment-gateway');?></label>
                                        </th>
                                        <td>
                                            <label for="id_or_company_number">
                                                <input type="checkbox" name="id_or_company_number" id="id_or_company_number" value="1" <?php checked( !empty(get_option('checkout_id_or_company_number')), 1 ); ?>>
                                                <span>
                                                    <?php esc_html_e('Enable/Disable ID/Company Number field.', 'meshulam-payment-gateway');?>
                                                </span>
                                            </label>
                                        </td>
                                    </tr>

                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="company_name"><?php esc_html_e('Company Name', 'meshulam-payment-gateway');?></label>
                                        </th>
                                        <td>
                                            <label for="company_name">
                                                <input type="checkbox" name="company_name" id="company_name" value="1" <?php checked( !empty(get_option('checkout_company_name')), 1 ); ?>>
                                                <span><?php esc_html_e('Enable/Disable Company Name.', 'meshulam-payment-gateway');?></span>
                                            </label>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                            <p class="submit">
                                <input type="hidden" name="action" value="meshulam_checkout_settings_ajax">
                                <button type="submit" name="submit" class="button button-primary">
                                    <?php esc_html_e('Save Changes', 'meshulam-payment-gateway'); ?>
                                </button>
                            </p>
                        </div>
                    </form>
                </div>

                <?php /* ?>
                <div class="tab-content<?php if( isset($_GET['tab']) && $_GET['tab']=='automation'){ echo ' active'; } ?>" id="automation">
                    <!-- Moment.js -->
                    <script src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
                    <!-- Daterangepicker -->
                    <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
                    <div class="automation_title">
                        <div class="right_col">
                            <ul class="toggle_link">
                                <li><a href="#"><?php esc_html_e('All', 'meshulam-payment-gateway'); ?></a></li>
                                <li><a href="#" class="active"><?php esc_html_e('Success', 'meshulam-payment-gateway'); ?></a></li>
                                <li><a href="#"><?php esc_html_e('Failed', 'meshulam-payment-gateway'); ?></a></li>
                            </ul>
                            <div class="daterangepicker_col"><input type="text" id="daterange" class="date-input" /></div>
                            <a href="#" class="all_filters"><img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/filter_icon.png'; ?>" alt="filter_icon"><?php esc_html_e('All filters', 'meshulam-payment-gateway'); ?></a>
                            <div class="search_col">
                                <form><input type="text" placeholder="<?php esc_html_e('Select Page', 'meshulam-payment-gateway'); ?>"></form>
                            </div>
                        </div>
                        <a href="#" class="create_webhook"><?php esc_html_e( 'Create a new webhook', 'meshulam-payment-gateway' ); ?></a>
                    </div>
                    <div class="automation_table">
                        <ul class="title">
                            <li><?php esc_html_e('Webhook Name', 'meshulam-payment-gateway') ?></li>
                            <li><?php esc_html_e('Date Created', 'meshulam-payment-gateway'); ?></li>
                            <li><?php esc_html_e('HTTP Status', 'meshulam-payment-gateway'); ?></li>
                            <li><?php esc_html_e('Number of trys', 'meshulam-payment-gateway') ?></li>
                            <li><?php esc_html_e('Platform', 'meshulam-payment-gateway'); ?></li>
                            <li><?php esc_html_e('Webhook URL', 'meshulam-payment-gateway'); ?></li>
                            <li><?php esc_html_e('Action', 'meshulam-payment-gateway'); ?></li>
                        </ul>

                        <?php
                        $webhooks = get_option('meshulam_webhooks', []);
                        if( $webhooks ) :
                        ?>
                        <div class="table_contain">

                            <?php foreach( $webhooks as $id => $webhook ) : ?>
                            <ul data-id="<?php echo esc_attr( $id ); ?>">
                                <li data-title="<?php esc_html_e('Webhook Name', 'meshulam-payment-gateway') ?>">
                                    <span class="webhook_name id_experience"><?php echo !empty($webhook['name']) ? esc_html( $webhook['name'] ) : ''; ?></span>
                                </li>
                                <li data-title="<?php esc_html_e( 'Date Created', 'meshulam-payment-gateway'); ?>">
                                    <span class="date_time"><?php echo !empty($webhook['created_at']) ? esc_html( $webhook['created_at'] ) : ''; ?></span>
                                </li>
                                <li data-title="<?php esc_html_e( 'HTTP Status', 'meshulam-payment-gateway'); ?>">
                                    <span class="http_status">200</span>
                                </li>
                                <li data-title="<?php esc_html_e('Number of trys', 'meshulam-payment-gateway') ?>">
                                    <span class="number_of_trys">1</span>
                                </li>
                                <li data-title="<?php esc_html_e('Platform', 'meshulam-payment-gateway'); ?>">
                                    <span class="platform id_experience"><?php echo !empty($webhook['platform']) ? esc_html( $webhook['platform'] ) : ''; ?></span>
                                </li>

                                <li data-title="<?php esc_html_e('Webhook URL', 'meshulam-payment-gateway'); ?>">
                                    <span class="webhook_url"><?php echo !empty($webhook['url']) ? esc_html( $webhook['url'] ) : ''; ?></span>
                                </li>

                                <li data-title="<?php esc_html_e('Action', 'meshulam-payment-gateway'); ?>">
                                    <a href="#" data-id="<?php echo esc_attr( $id ); ?>" class="button edit-webhook"><?php esc_html_e('Edit', 'meshulam-payment-gateway'); ?></a>
                                    <a href="#" data-id="<?php echo esc_attr( $id ); ?>" class="button delete-webhook"><?php esc_html_e('Delete', 'meshulam-payment-gateway') ?></a>
                                </li>
                            </ul>
                            <?php endforeach; ?>

                        </div>
                        <?php endif; ?>

                    </div>
                </div>
                <?php */ ?>

            </div>

        </div>

    </div>

    <?php /* ?>
    <div class="popup_webhook_added">
        <div class="bg"></div>
        <div class="wrap">
            <div class="webhook_title">
                <h2><?php esc_html_e('Add New Webhook', 'meshulam-payment-gateway'); ?></h2>
                <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/close_book_pop.svg'; ?>" class="close_book_pop" alt="Maclose_book_pop">
            </div>
            <form method="post" action="" name="add-webhook" class="add_webhook">
                <div class="webhook_containt">
                    <div class="right_col">
                        <div class="input_data">
                            <h4><?php esc_html_e('Unique name for webhook', 'meshulam-payment-gateway'); ?></h4>
                            <input type="text" name="webhook_name" placeholder="<?php esc_html_e('Unique name for webhook', 'meshulam-payment-gateway'); ?>" class="in">
                        </div>

                        <div class="input_data">
                            <h4><?php esc_html_e('Webhook URL', 'meshulam-payment-gateway'); ?></h4>
                            <input type="text" name="webhook_url" placeholder="<?php esc_html_e('Target URL', 'meshulam-payment-gateway'); ?>" class="in">
                        </div>

                        <div class="input_data">
                            <h4><?php esc_html_e('Secret code ( Only if webhook require )', 'meshulam-payment-gateway'); ?></h4>
                            <input type="text" name="webhook_secret_code" placeholder="secret_1412341" class="in">
                        </div>

                        <div class="input_data">
                            <h4><?php esc_html_e('Platform', 'meshulam-payment-gateway'); ?></h4>
                            <input type="text" name="webhook_platform" placeholder="monday/zapiar/crm/" class="in">
                        </div>
                    </div>
                    <div class="left_col">
                        <h3><?php esc_html_e('Fields', 'meshulam-payment-gateway'); ?></h3>
                        <div class="events_radio">
                            <label for="eventall">
                                <input type="radio" name="field_type" id="eventall" value="all_fields" checked>
                                <span><?php esc_html_e('All fields', 'meshulam-payment-gateway'); ?></span>
                            </label>
                            <label for="eventselection">
                                <input type="radio" name="field_type" value="specific_fields" id="eventselection">
                                <span><?php esc_html_e('Select specific fields', 'meshulam-payment-gateway'); ?></span>
                            </label>
                        </div>
                        <div class="events_containts">
                            <?php
                            foreach (WC()->checkout()->get_checkout_fields() as $section => $fields) {
                                    if (empty($fields)) {
                                    continue;
                                }
                                echo '<div class="colin">';
                                echo "<h3>".ucwords($section)."</h3>";
                                foreach ($fields as $key => $field) {
                                    echo '<label><input name="specific_selected_field[]" type="checkbox" value="'.$key.'"><span>'.$field['label'].'</span></label>';
                                }
                                echo '</div>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="webhook_button">
                    <input type="hidden" name="action" value="meshulam_add_new_webhook_ajax">
                    <span class="edit_item_id"></span>
                    <a href="#" class="btn cancellation close_book_pop">
                        <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/bookcancle.svg'; ?>" alt="bookcancle">
                        <?php esc_html_e('Cancel', 'meshulam-payment-gateway'); ?>
                    </a>
                    <button type="submit" class="btn save button">
                        <img src="<?php  echo MESHULAM_PLUGIN_URL. 'assets/images/booksave.svg'; ?>" alt="booksave">
                        <?php esc_html_e('Save', 'meshulam-payment-gateway'); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php */ ?>

<?php }