<?php
defined('ABSPATH') || exit; // Exit if accessed directly

add_action('wp_ajax_meshulam_add_new_webhook_ajax', 'meshulam_add_new_webhook_ajax_cb');
function meshulam_add_new_webhook_ajax_cb() {
    $webhook_name = !empty($_POST['webhook_name']) ? sanitize_text_field($_POST['webhook_name']) : false;
    $webhook_url = !empty($_POST['webhook_url']) ? esc_url_raw($_POST['webhook_url']) : false;
    $webhook_secret_code = !empty($_POST['webhook_secret_code']) ? sanitize_text_field($_POST['webhook_secret_code']) : false;
    $webhook_platform = !empty($_POST['webhook_platform']) ? sanitize_text_field($_POST['webhook_platform']) : false;
    $field_type = !empty($_POST['field_type']) ? sanitize_text_field($_POST['field_type']) : false;
    $specific_selected_field = !empty($_POST['specific_selected_field']) ? $_POST['specific_selected_field'] : false;
    $edit_id = isset($_POST['edit_id']) ? (int) $_POST['edit_id'] : null;
    $error = [];

    if (!$webhook_name || !$webhook_url) {
        if( !$webhook_name ){
            $error['webhook_name'] = __('Webhook name is required.');
        }

        if( !$webhook_url ){
            $error['webhook_url'] = __('Webhook url is required.');
        }

        wp_send_json_error([
            'message'       => __('Please fill all required fields.', 'meshulam-payment-gateway'),
            'error_fields'  => $error,
            'time'          => current_time('mysql'),
        ]);
    }

    $webhooks = get_option('meshulam_webhooks', []);
    if (!is_array($webhooks)) {
        $webhooks = [];
    }

    // If editing
    if ($edit_id && isset($webhooks[$edit_id])) {
        $existing = $webhooks[$edit_id];
        $webhooks[$edit_id] = [
            'name'              => $webhook_name ?: $existing['name'],
            'url'               => $webhook_url ?: $existing['url'],
            'secret_code'       => $webhook_secret_code ?: $existing['secret_code'],
            'platform'          => $webhook_platform ?: $existing['platform'],
            'field_type'        => $field_type ?: $existing['field_type'],
            'specific_field'    => !empty($specific_selected_field) ? $specific_selected_field : $existing['specific_field'],
            'created_at'        => isset($existing['created_at']) ? $existing['created_at'] : current_time('mysql'),
            'updated_at'        => current_time('mysql'),
        ];
    } else {
        // Get next ID
        $next_id = !empty($webhooks) ? max(array_keys($webhooks)) + 1 : 1;

        $webhooks[$next_id] = [
            'name'              => $webhook_name,
            'url'               => $webhook_url,
            'secret_code'       => $webhook_secret_code,
            'platform'          => $webhook_platform,
            'field_type'        => $field_type,
            'specific_field'    => $specific_selected_field,
            'created_at'        => current_time('mysql'),
        ];
    }

    update_option('meshulam_webhooks', $webhooks);

    wp_send_json_success([
        'message'   => __('New webhook added.', 'meshulam-payment-gateway'),
        'webhooks'  => $webhooks,
        'time'      => current_time('mysql'),
    ]);

    wp_die();
}

add_action('wp_ajax_meshulam_get_webhook_ajax', 'meshulam_get_webhook_ajax_cb');
function meshulam_get_webhook_ajax_cb() {
    $id = !empty($_POST['id']) ? sanitize_text_field($_POST['id']) : false;
    $webhooks = get_option('meshulam_webhooks', []);

     if (!$id) {
        wp_send_json_error([
            'message' => __('Missing webhook ID.', 'meshulam-payment-gateway')
        ]);
    }

    // Get existing webhooks
    $webhooks = get_option('meshulam_webhooks');

    // Ensure we have a valid array
    if (!is_array($webhooks)) {
        $webhooks = [];
    }

    // Check if the requested webhook ID exists
    if (!isset($webhooks[$id])) {
        wp_send_json_error([
            'message' => __('Webhook not found.', 'meshulam-payment-gateway')
        ]);
    }

    // Return the webhook data
    wp_send_json_success([
        'webhook' => $webhooks[$id]
    ]);

    wp_die();
}

add_action('wp_ajax_meshulam_activation_ajax', 'meshulam_activation_ajax_cb');
function meshulam_activation_ajax_cb() {

    $user_email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $user_access_key = isset($_POST['access_key']) ? $_POST['access_key'] : '';
    $sdk_gateway = new WC_Grow_Wallet_Gateway();

    if (!is_email($user_email) || empty($user_access_key)) {
        wp_send_json_error([
            'message'       => __('Please submit email and access key', 'meshulam-payment-gateway'),
            'time'          => current_time('mysql'),
        ]);
    }

    $return_url = str_replace(['http:', 'https:'], '', home_url());
    $args = array(
        'method'    => 'POST',
        'timeout'   => 120,
        'sslverify' => false,
        'headers'   => array(),
        'body'      => array(
            'email'             => $user_email,
            'access_key'        => $user_access_key,
            'return_url'        => $return_url,
            'plugin_version'    => MESHULAM_VERSION,
        ),
    );
    $response = wp_remote_post('https://meshulamplugin.co.il/new_dashboard/index.php/admin/update_plugin_data_client', $args);
    if (!is_wp_error($response)) {
        $res = json_decode($response['body'], true);
        $status = $res['status'];
        if ($status == '0') {
            update_option('meshulam_bit_payment_code', '');
            update_option('meshulam_bit_payment_status', '');
            update_option('bitpay_payment_status', '');
            update_option('meshulam_apple_payment_status', '');
            update_option('meshulam_apple_payment_status', '');
            update_option('meshulam_cal_payment_status', '');
            update_option('meshulam_googlepay_payment_status', '');
            update_option('meshulam_manage_recurring', '');
            update_option('grow_wallet_payment_status', '');
        } else {
            update_option('meshulam_payment_user_access_key', $user_access_key);
            update_option('meshulam_payment_user_email', $user_email);

            if( isset($res['code']) ){
                update_option('meshulam_bit_payment_code', $res['code']);
                update_option('bitpay_payment_code', $res['code']);
            }

            if( isset($res['bit_status']) ){
                if ($res['bit_status'] == '1') {
                    update_option('bitpay_payment_status', '1');
                } else {
                    update_option('bitpay_payment_status', '');
                }
            }

            if( isset($res['sdk_status']) ){

                if ($res['sdk_status'] == '1') {

                    update_option('grow_wallet_payment_status', '1');

                    $sdk_payment_list = [];
                    if( isset($res['sdk_credit_card']) ){
                        if ($res['sdk_credit_card'] == '1') {
                            update_option('sdk_credit_card', '1');
                            $sdk_payment_list[] = 'sdk_credit_card';
                        } else {
                            update_option('sdk_credit_card', '');
                        }
                    }

                    if( isset($res['sdk_bit']) ){
                        if ($res['sdk_bit'] == '1') {
                            update_option('sdk_bit', '1');
                            $sdk_payment_list[] = 'sdk_bit';
                        } else {
                            update_option('sdk_bit', '');
                        }
                    }

                    if( isset($res['sdk_apple']) ){
                        if ($res['sdk_apple'] == '1') {
                            update_option('sdk_apple', '1');
                            // $sdk_payment_list[] = 'sdk_apple';
                        } else {
                            update_option('sdk_apple', '');
                        }
                    }

                    if( isset($res['sdk_google']) ){
                        if ($res['sdk_google'] == '1') {
                            update_option('sdk_google', '1');
                            $sdk_payment_list[] = 'sdk_google';
                        } else {
                            update_option('sdk_google', '');
                        }
                    }

                    if( isset($res['sdk_bank_transfer']) ){
                        if ($res['sdk_bank_transfer'] == '1') {
                            update_option('sdk_bank_transfer', '1');
                            $sdk_payment_list[] = 'sdk_bank_transfer';
                        } else {
                            update_option('sdk_bank_transfer', '');
                        }
                    }

                    if( isset($res['sdk_pay_box']) ){
                        if ($res['sdk_pay_box'] == '1') {
                            update_option('sdk_pay_box', '1');
                            $sdk_payment_list[] = 'sdk_pay_box';
                        } else {
                            update_option('sdk_pay_box', '');
                        }
                    }

                    $sdk_gateway->update_option('sdk_payment_list', $sdk_payment_list);

                } else {
                    update_option('grow_wallet_payment_status', '');
                }
            }



            if( isset($res['manage_recurring']) ){
                if ($res['manage_recurring'] == '1') {
                    update_option('meshulam_manage_recurring', '1');
                } else {
                    update_option('meshulam_manage_recurring', '');
                }
            }

            if( isset($res['apple_status']) ){
                if ($res['apple_status'] == '1') {
                    update_option('meshulam_apple_payment_status', '1');
                } else {
                    update_option('meshulam_apple_payment_status', '');
                }
            }

            if( isset($res['cal_status']) ){
                if ($res['cal_status'] == '1') {
                    update_option('meshulam_cal_payment_status', '1');
                } else {
                    update_option('meshulam_cal_payment_status', '');
                }
            }

            if( isset($res['googlepay_status']) ){
                if ($res['googlepay_status'] == '1') {
                    update_option('meshulam_googlepay_payment_status', '1');
                } else {
                    update_option('meshulam_googlepay_payment_status', '');
                }
            }

            if( isset($res['recurring_status']) ){
                if ($res['recurring_status'] == '1') {
                    update_option('meshulam_recurring_payment_status', '1');
                } else {
                    update_option('meshulam_recurring_payment_status', '');
                }
            }

            if( isset($res['regular_status']) ){
                if ($res['regular_status'] == '1') {
                    update_option('meshulam_bit_payment_status', '1');
                } else {
                    update_option('meshulam_bit_payment_status', '');
                }
            }

            if( isset($res['refund_status']) ){
                if ($res['refund_status'] == '1') {
                    update_option('meshulam_refund_status', '1');
                } else {
                    update_option('meshulam_refund_status', '');
                }
            }

            if( isset($res['j5_status']) ){
                if ($res['j5_status'] == '1') {
                    update_option('meshulam_j5_status', '1');
                } else {
                    update_option('meshulam_j5_status', '');
                }
            }

            if( isset($res['j4_status']) ){
                if ($res['j4_status'] == '1') {
                    update_option('meshulam_force_regular_payment', '1');
                } else {
                    update_option('meshulam_force_regular_payment', '');
                }
            }

            if( isset($res['pagecodes']) ){
                $pagecodes = $res['pagecodes'];

                if( isset( $pagecodes['meshulam_regular']['live_pagecode'] ) ){
                    $meshulam_regular_live_pagecode = $pagecodes['meshulam_regular']['live_pagecode'];
                    update_option('meshulam_regular_live_pagecode', $meshulam_regular_live_pagecode);
                }

                if( isset( $pagecodes['meshulam_regular']['test_pagecode'] ) ){
                    $meshulam_regular_test_pagecode = $pagecodes['meshulam_regular']['test_pagecode'];
                    update_option('meshulam_regular_test_pagecode', $meshulam_regular_test_pagecode);
                }

                if( isset( $pagecodes['meshulam_recurring']['live_pagecode'] ) ){
                    $meshulam_recurring_live_pagecode = $pagecodes['meshulam_recurring']['live_pagecode'];
                    update_option('meshulam_recurring_live_pagecode', $meshulam_recurring_live_pagecode);
                }

                if( isset( $pagecodes['meshulam_recurring']['test_pagecode'] ) ){
                    $meshulam_recurring_test_pagecode = $pagecodes['meshulam_recurring']['test_pagecode'];
                    update_option('meshulam_recurring_test_pagecode', $meshulam_recurring_test_pagecode);
                }

                if( isset( $pagecodes['bit_payment']['live_pagecode'] ) ){
                    $meshulam_bit_live_pagecode = $pagecodes['bit_payment']['live_pagecode'];
                    update_option('meshulam_bit_live_pagecode', $meshulam_bit_live_pagecode);
                }

                if( isset( $pagecodes['bit_payment']['test_pagecode'] ) ){
                    $meshulam_bit_test_pagecode = $pagecodes['bit_payment']['test_pagecode'];
                    update_option('meshulam_bit_test_pagecode', $meshulam_bit_test_pagecode);
                }

                if( isset( $pagecodes['apple_payment']['live_pagecode'] ) ){
                    $meshulam_apple_live_pagecode = $pagecodes['apple_payment']['live_pagecode'];
                    update_option('meshulam_apple_live_pagecode', $meshulam_apple_live_pagecode);
                }

                if( isset( $pagecodes['apple_payment']['test_pagecode'] ) ){
                    $meshulam_apple_test_pagecode = $pagecodes['apple_payment']['test_pagecode'];
                    update_option('meshulam_apple_test_pagecode', $meshulam_apple_test_pagecode);
                }

                if( isset( $pagecodes['cal_payment']['live_pagecode'] ) ){
                    $meshulam_cal_live_pagecode = $pagecodes['cal_payment']['live_pagecode'];
                    update_option('meshulam_cal_live_pagecode', $meshulam_cal_live_pagecode);
                }

                if( isset( $pagecodes['cal_payment']['test_pagecode'] ) ){
                    $meshulam_cal_test_pagecode = $pagecodes['cal_payment']['test_pagecode'];
                    update_option('meshulam_cal_test_pagecode', $meshulam_cal_test_pagecode);
                }

                if( isset( $pagecodes['googlepay_payment']['live_pagecode'] ) ){
                    $meshulam_googlepay_live_pagecode = $pagecodes['googlepay_payment']['live_pagecode'];
                    update_option('meshulam_googlepay_live_pagecode', $meshulam_googlepay_live_pagecode);
                }

                if( isset( $pagecodes['googlepay_payment']['test_pagecode'] ) ){
                    $meshulam_googlepay_test_pagecode = $pagecodes['googlepay_payment']['test_pagecode'];
                    update_option('meshulam_googlepay_test_pagecode', $meshulam_googlepay_test_pagecode);
                }

                if( isset( $pagecodes['grow_wallet_payment']['live_pagecode'] ) ){
                    $meshulam_grow_wallet_live_pagecode = $pagecodes['grow_wallet_payment']['live_pagecode'];
                    update_option('meshulam_grow_wallet_live_pagecode', $meshulam_grow_wallet_live_pagecode);
                }

                if( isset( $pagecodes['grow_wallet_payment']['test_pagecode'] ) ){
                    $meshulam_grow_wallet_test_pagecode = $pagecodes['grow_wallet_payment']['test_pagecode'];
                    update_option('meshulam_grow_wallet_test_pagecode', $meshulam_grow_wallet_test_pagecode);
                }

                if( isset( $pagecodes['grow_wallet_recurring']['live_pagecode'] ) ){
                    $meshulam_grow_wallet_recurring_live_pagecode = $pagecodes['grow_wallet_recurring']['live_pagecode'];
                    update_option('meshulam_grow_wallet_recurring_live_pagecode', $meshulam_grow_wallet_recurring_live_pagecode);
                }

                if( isset( $pagecodes['grow_wallet_recurring']['test_pagecode'] ) ){
                    $meshulam_grow_wallet_recurring_test_pagecode = $pagecodes['grow_wallet_recurring']['test_pagecode'];
                    update_option('meshulam_grow_wallet_recurring_test_pagecode', $meshulam_grow_wallet_recurring_test_pagecode);
                }
            }
        }
        if ('success' != $res['message']) {
            wp_send_json_error([
                'message'       => __($res['message'], 'meshulam-payment-gateway'),
                'server_res'    => $res,
                'time'          => current_time('mysql'),
            ]);
        }

    } else {
        wp_send_json_error([
            'message'       => __('The connection failed, please contact the server company and check why there is a block', 'meshulam-payment-gateway'),
            'time'          => current_time('mysql'),
        ]);
    }

    wp_send_json_success([
        'message'       => __('Settings saved.'),
        'server_res'    => $res,
        'time'          => current_time('mysql'),
    ]);

    wp_die();

}

add_action('wp_ajax_meshulam_checkout_settings_ajax', 'meshulam_checkout_settings_ajax_cb');
function meshulam_checkout_settings_ajax_cb() {

    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        $id_or_company_number = !empty($_POST['id_or_company_number']) ? true : false;
        $company_name = !empty($_POST['company_name']) ? true : false;

        update_option('checkout_id_or_company_number', $id_or_company_number);
        update_option('checkout_company_name', $company_name);

        wp_send_json_success([
            'message'       => __('Settings saved.', 'meshulam-payment-gateway'),
            'time'          => current_time('mysql'),
        ]);

    }else{
        wp_send_json_error([
            'message'       => __('Invalid request.', 'meshulam-payment-gateway'),
            'time'          => current_time('mysql'),
        ]);
    }

}

//creating custom column in order list of admin for show pdf icon
add_filter('manage_edit-shop_order_columns', 'show_column_meshulam_invoice_odf', 20);
add_filter('manage_woocommerce_page_wc-orders_columns', 'show_column_meshulam_invoice_odf', 20);
function show_column_meshulam_invoice_odf($columns) {
    $columns['meshulam-ivoice'] = __('Invoice', 'meshulam-payment-gateway');
    return $columns;
}

// Adding custom fields meta data for each new column (example)
add_action('manage_shop_order_posts_custom_column', 'meshulam_custom_orders_list_column_content', 20, 2);
add_action('manage_woocommerce_page_wc-orders_custom_column', 'meshulam_custom_orders_list_column_content', 20, 2);
function meshulam_custom_orders_list_column_content($column, $order_or_order_id) {

    $order = $order_or_order_id instanceof WC_Order ? $order_or_order_id : wc_get_order( $order_or_order_id );
    switch ($column) {
        case 'meshulam-ivoice':
            // Get custom post meta data
            $meshulam_invoice_url = $order->get_meta('meshulam_invoice_url');
            if (!empty($meshulam_invoice_url)) {
                echo '<a href="' . $meshulam_invoice_url . '" target="_blank"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/pdf.png" height="30"></a>';
            }
            else {
                echo '';
            }

            break;
    }
}

//hook for J5 on and admin change order items we need to set meta and send updated data to meshulam again
add_action('woocommerce_saved_order_items', 'meshulam_changed_order_data_admin');
function meshulam_changed_order_data_admin($order_id) {
    $order = wc_get_order($order_id);
    if (isset($_POST['order_id']) && isset($_POST['items'])) {
        $order->update_meta_data('order_updated_byadmin_j5', '1');
        $order->save();
    }
}

add_action('wp_ajax_meshulam_j5_release_ajax', 'meshulam_j5_release_ajax_cb');
function meshulam_j5_release_ajax_cb() {

    $order_id = !empty($_POST['order_id']) ? $_POST['order_id'] : false;
    $order = wc_get_order($order_id);
    $result = [];

    if( $order ){
        $passed = $order->get_meta('order_already_passed');

        if ($passed == '1'){
            $result['status'] = true;
            $result['message'] = __('Order already released.', 'meshulam-payment-gateway');
        } else {
            $j5_mode = $order->get_meta('meshulam_j5_on');
            $transactionId = $order->get_meta('approved_transactionId');
            $transactionToken = $order->get_meta('approved_transactionToken');
            $order_updated = $order->get_meta('order_updated_byadmin_j5');

            if ($j5_mode == 'yes' && $transactionId != '' && $transactionToken != '') {

                if ($order->get_payment_method() == 'bitpay-payment') {
                    $cls = new WC_BitPay_Meshulam_Gateway();
                } elseif ( $order->get_payment_method() == 'apple-payment' ){
                    $cls = new WC_Apple_Meshulam_Gateway();
                } elseif ( $order->get_payment_method() == 'googlepay-payment' ){
                    $cls = new WC_GooglePay_Meshulam_Gateway();
                } elseif ( $order->get_payment_method() == 'grow-wallet-payment' ){
                    $cls = new WC_Grow_Wallet_Gateway();
                } elseif ( $order->get_payment_method() == 'meshulam-payment' ){
                    $cls = new WC_MeshulamPay_Gateway();
                }

                if( empty($cls) ) return;

                $auth_code = $cls->auth_code;
                $userId = $cls->api_userid;
                $pagecode = $cls->pagecode;
                $j5_approve_url = $cls->j5_approve_url;
                $update_url = $cls->update_url;
                $response_url = $cls->response_url;
                $chargeType = $cls->chargeType;

                $pay_type = unserialize($order->get_meta('meshulam_pay_payment-type'));
                if ($pay_type == 1) {
                    $pagecode = $cls->recurring_pagecode; //for recurring
                }
                else {
                    $pagecode = $cls->regular_pagecode; // for simple
                }

                $args_body = array(
                    'apiKey'            => $auth_code,
                    'userId'            => $userId,
                    'transactionId'     => $transactionId,
                    'transactionToken'  => $transactionToken,
                    'sum'               => $order->get_total(),
                );

                if ($order_updated == '1') {
                    $first_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                    //get all items from order
                    $items = $order->get_items();
                    $fee = $order->get_items('fee');

                    $giftcard_amount = 0;
                    $giftcards = $order->get_items('gift_card');
                    if ($giftcards) {
                        foreach ($giftcards as $gift_item) {
                            $giftcard_amount = $gift_item->get_captured_amount();
                        }
                    }

                    $pw_gift_card = $order->get_items('pw_gift_card');
                    $gift_amnt = 0;
                    $coupons = $order->get_items('coupon');
                    if (!empty($coupons)) {
                        $extra = $order->get_meta('smart_coupons_contribution');
                        if (!empty($extra)) {
                            foreach ($extra as $ext) {
                                $gift_amnt += $ext;
                            }
                        }
                    }
                    if (!empty($pw_gift_card)) {
                        foreach ($pw_gift_card as $key => $line) {
                            $gift_amnt += $line->get_amount();
                        }
                    }

                    if (!empty($giftcard_amount)) {
                        $gift_amnt += $giftcard_amount;
                    }

                    if( $order->get_total_discount() > 0 ){
                        $gift_amnt += $order->get_total_discount();
                    }

                    $order_id = $order->get_id();
                    $order->update_meta_data('order_already_passed', '0');

                    $customer_note = array();
                    foreach ($items as $item) {
                        $item_total = $item->get_total();
                        $item_quantity = $item->get_quantity();
                        $customer_note[] = $item->get_name() . '[ כמות: ' . $item_quantity . ' | מחיר: ' . number_format($item_total, 2) . ']';
                    }
                    $customer_note = implode(',', $customer_note);
                    $pay_num = unserialize($order->get_meta('meshulam_pay_payment-number'));

                    if ($pay_num == '' || $pay_num == '0') {
                        $pay_num = 1;
                    }
                    $shipping_charge = $order->get_total_shipping();
                    $tax_total = $order->get_total_tax();
                    //send it to API as a description
                    $customer_note = 'תשלום עבור הזמנה:' . $order_id;
                    $cls->invoiceNotifyUrl = add_query_arg('order_id', $order_id, $cls->invoiceNotifyUrl);

                    $args_body['pageCode'] = $pagecode;
                    if ($pay_num != '180') {
                        $args_body['paymentNum'] = $pay_num;
                    }
                    $args_body['successUrl'] = $response_url;
                    $args_body['cancelUrl'] = wc_get_checkout_url();
                    $args_body['notifyUrl'] = $update_url;
                    $args_body['invoiceNotifyUrl'] = $cls->invoiceNotifyUrl;
                    $args_body['description'] = $customer_note;
                    $args_body['pageField[fullName]'] = $first_name;
                    $args_body['pageField[phone]'] = $order->get_billing_phone();
                    $args_body['pageField[email]'] = $order->get_billing_email();
                    $args_body['cField1'] = $order->get_id();
                    $args_body['chargeType'] = $chargeType;

                    $i = 0;
                    foreach ($items as $item) {
                        $prdct_name = $item->get_name();
                        $product_variation_id = $item['variation_id'];
                        if ($product_variation_id) {
                            $product = wc_get_product($item['variation_id']);
                            $product_id = $item['variation_id'];
                        } else {
                            $product = wc_get_product($item['product_id']);
                            $product_id = $item['product_id'];
                        }
                        $sku = $product->get_sku();
                        if ($sku == '') {
                            $sku = $product_id;
                        }

                        $args_body['productData'][$i]['catalogNumber'] = $sku;
                        $args_body['productData'][$i]['price'] = $item->get_subtotal();
                        $args_body['productData'][$i]['itemDescription'] = $prdct_name;
                        $args_body['productData'][$i]['quantity'] = $item->get_quantity();
                        $i++;
                    }
                    foreach ($items as $item_id => $item) {
                        $all_meta_data = get_metadata( 'order_item', $item_id, "", "" );
                        if( !empty($all_meta_data) && !empty($all_meta_data['extra_services_str']['0']) ) {
                            $extra_services_str = $all_meta_data['extra_services_str']['0'];
                            $extra_services_arr = explode(';',$extra_services_str);

                            foreach($extra_services_arr as $extra_services){

                                $extra_service_inn_arr = explode(':', $extra_services);
                                $extra_service_id = $extra_service_inn_arr[0];
                                $extra_service_name = get_the_title($extra_service_id);
                                $extra_service_price = get_post_meta($extra_service_id, 'price', true);
                                $extra_service_qty_arr = explode(',', $extra_service_inn_arr[1]);
                                $total_qty = 0;

                                foreach($extra_service_qty_arr as $extra_service_qty){
                                    $extra_service_qty_inn_arr = explode('-', $extra_service_qty);
                                    $total_qty += $extra_service_qty_inn_arr[1];
                                }

                                $services_total = $total_qty*$extra_service_price;
                                $args_body['productData'][$i]['catalogNumber'] = $extra_service_id;
                                $args_body['productData'][$i]['price'] = $services_total;
                                $args_body['productData'][$i]['itemDescription'] = "שירותים נוספים - ".$extra_service_name;
                                $args_body['productData'][$i]['quantity'] = $total_qty;

                                $i++;

                            }
                        }
                    }

                    if (!empty($fee)) {
                        foreach ($fee as $item) {
                            $args_body['productData'][$i]['catalogNumber'] = '000000';
                            $args_body['productData'][$i]['price'] = $item->get_total();
                            $args_body['productData'][$i]['itemDescription'] = $item->get_name();
                            $args_body['productData'][$i]['quantity'] = $item->get_quantity();
                            $i++;
                        }
                    }

                    if ($gift_amnt > 0) {
                        $args_body['productData'][$i]['catalogNumber'] = '000000';
                        $args_body['productData'][$i]['price'] = '-' . $gift_amnt;
                        $args_body['productData'][$i]['itemDescription'] = 'כרטיס מתנה';
                        $args_body['productData'][$i]['quantity'] = '1';
                        $i++;
                    }
                    if ($shipping_charge > 0) {
                        $args_body['productData'][$i]['catalogNumber'] = '000000';
                        $args_body['productData'][$i]['price'] = $shipping_charge;
                        $args_body['productData'][$i]['itemDescription'] = 'עלות משלוח';
                        $args_body['productData'][$i]['quantity'] = '1';
                        $i++;
                    }
                    if ($tax_total > 0) {
                        $args_body['productData'][$i]['catalogNumber'] = '000001';
                        $args_body['productData'][$i]['price'] = $tax_total;
                        $args_body['productData'][$i]['itemDescription'] = 'תוספת מס';
                        $args_body['productData'][$i]['quantity'] = '1';
                        $i++;
                    }
                }

                if ($cls->debug == 'yes') {
                    $logger = wc_get_logger();
                    $logger->add('meshulam_j5_process', 'Before Sending Data to Meshulam');
                    $logger->add('meshulam_j5_process', 'Request: ' . print_r($args_body, true));
                }

                $args = [
                    'method' => 'POST',
                    'timeout' => 45,
                    'redirection' => 5,
                    'httpversion' => '1.0',
                    'blocking' => true,
                    'headers' => [],
                    'body' => $args_body,
                    'cookies' => [],
                ];



                $res = wp_remote_post($j5_approve_url, $args);
                if (is_wp_error($res)) {
                    if ($cls->debug == 'yes') {
                        $logger->add('meshulam_j5_process', 'WP Remote Post Error: ' . print_r($res->get_error_message(), true));
                    }

                    $result['status'] = false;
                    $result['message'] = $res->get_error_message();

                } else {
                    if ($cls->debug == 'yes') {
                        $logger->add('meshulam_j5_process', 'WP Remote Post Completed');
                        $data = json_decode($res['body']);
                        $file_data = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
                        $logger->add('meshulam_j5_process', 'WP Remote Post Response: ' . print_r($file_data, true));
                    }
                    $body = json_decode($res['body'], true);
                    if ($body["status"] == 1) {
                        $asmachta = $body['data']['asmachta'];
                        $order->update_meta_data('order_already_passed', '1');
                        $order->update_meta_data('meshula_order_asmachta', $asmachta);
                        $order->add_order_note(sprintf(__('Payment complete<br/>Asmachta: %s<br/>Transaction ID: %s', 'meshulam-payment-gateway'), $asmachta, $transactionId));

                        $result['status'] = true;
                        $result['message'] = __('Order released successfully.', 'meshulam-payment-gateway');

                    } else {

                        $err_msg = __('Please Try Again, Or contact to grow.', 'meshulam-payment-gateway');;

                        if( isset($body['err']['message']) ){
                            $err_msg = $body['err']['message'];
                        }elseif( isset($body['err']['error_msg']) ){
                            $err_msg = $body['err']['error_msg'];
                        }

                        $order->update_status('on-hold', $err_msg);
                        $order->add_meta_data('meshulam_payment_error', 'בבקשה נסה שוב', true);

                        $result['status'] = false;
                        $result['message'] = __($err_msg, 'meshulam-payment-gateway');
                    }
                }
            }else{
                $result['status'] = false;
                $result['message'] = __('Please Try Again, Or contact to grow.', 'meshulam-payment-gateway');
            }
            $order->save();
        }
    }

    $result = json_encode($result);
    echo $result;
    die();
}

add_filter('manage_edit-shop_order_columns', 'meshulam_add_payment_gateway_column', 20);
add_filter('manage_woocommerce_page_wc-orders_columns', 'meshulam_add_payment_gateway_column', 20);
function meshulam_add_payment_gateway_column($columns) {
    // Position it after 'order_total'
    $new_columns = [];
    foreach ($columns as $key => $column) {
        $new_columns[$key] = $column;
        if ('order_total' === $key) {
            $new_columns['payment_gateway'] = __('Payment Gateway', 'meshulam-payment-gateway');
        }
    }
    return $new_columns;
}

// Populate the new column
add_action('manage_shop_order_posts_custom_column', 'meshulam_show_payment_gateway_column_content', 20, 2);
add_action('manage_woocommerce_page_wc-orders_custom_column', 'meshulam_show_payment_gateway_column_content', 20, 2);
function meshulam_show_payment_gateway_column_content($column, $order_or_order_id) {
    $order = $order_or_order_id instanceof WC_Order ? $order_or_order_id : wc_get_order( $order_or_order_id );
    if ('payment_gateway' === $column) {
        if ($order) {
            $payment_method_title = $order->get_payment_method();
            if( $payment_method_title == 'grow-wallet-payment' ){
                $payment_method_title = $order->get_meta('wallet_payment_title');
            }else{
                $payment_method_title = ucwords(str_replace("-", " ", $payment_method_title));
            }
            echo esc_html($payment_method_title);
        }
    }
}

function get_first_order_date_all_orders() {
    $orders = wc_get_orders( array(
        'limit'    => 1,
        'orderby'  => 'date',
        'order'    => 'ASC',
        'return'   => 'objects',
    ) );

    if ( ! empty( $orders ) ) {
        $first_order = reset( $orders );
        return $first_order->get_date_created()->date( 'd.m.Y' );
    }

    return false;
}

add_action( 'template_redirect', function () {
    if ( is_checkout() && ! is_wc_endpoint_url() ) {
        if ( ! WC()->session->get( 'checkout_start_time' ) ) {
            WC()->session->set( 'checkout_start_time', time() );
        }
    }
});

add_action( 'woocommerce_thankyou', function ( $order_id ) {
    $order = wc_get_order( $order_id );
    $checkout_start_time = WC()->session->get( 'checkout_start_time' );
    if ( $checkout_start_time ) {
        $duration = time() - $checkout_start_time;
        $order->update_meta_data( '_checkout_duration', $duration );
        $order->save();
        WC()->session->__unset( 'checkout_start_time' );
    }
});