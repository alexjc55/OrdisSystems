<?php
defined('ABSPATH') || exit; // Exit if accessed directly

add_action( 'woocommerce_init', 'meshulam_register_additional_checkout_field' );
function meshulam_register_additional_checkout_field() {

    $is_enabled = get_option('checkout_id_or_company_number');
    if( $is_enabled ){
        woocommerce_register_additional_checkout_field(
            array(
                'id'            => 'company/id',
                'label'         => __('ID/Company Number', 'meshulam-payment-gateway'),
                'optionalLabel' => __('ID/Company Number (optional)', 'meshulam-payment-gateway'),
                'location'      => 'address',
                'required'      => true,
                'attributes'    => array(
                    'autocomplete'     => 'company-id',
                    'aria-describedby' => __('ID/Company Number', 'meshulam-payment-gateway'),
                    'aria-label'       => __('ID/Company Number', 'meshulam-payment-gateway'),
                    'title'            => __('ID/Company Number', 'meshulam-payment-gateway'),
                ),
                'validation'    => array(
                    'type'         => 'string',
                    'pattern'      => '^[0-9]{8,10}$',
                    'errorMessage' => __('Please enter a valid ID/Company Number (8‑10 digits).', 'meshulam-payment-gateway'),
                )

            ),
        );
    }
}

add_action( 'woocommerce_sanitize_additional_field', 'meshulam_sanitize_additional_field', 10, 2 );
function meshulam_sanitize_additional_field( $field_value, $field_key ) {
    if ( 'company/id' === $field_key ) {
        $field_value = str_replace( ' ', '', $field_value );
        $field_value = strtoupper( $field_value );
    }
    return $field_value;
}

add_action( 'woocommerce_validate_additional_field', 'meshulam_validate_additional_field', 10, 3 );
function meshulam_validate_additional_field( WP_Error $errors, $field_key, $field_value ) {
    if ( 'company/id' === $field_key ) {
        $match = preg_match( '/^\d{8,10}$/', $field_value );
        if ( 0 === $match || false === $match ) {
            $errors->add( 'invalid_company-id', __('Please enter a valid ID/Company Number (8‑10 digits).', 'meshulam-payment-gateway') );
        }
    }
    return $errors;
}

add_filter( 'woocommerce_get_country_locale', 'meshulam_company_name_field' );
function meshulam_company_name_field( $locale ) {
    $is_enabled = get_option('checkout_company_name');
    if( $is_enabled ){
        foreach ( $locale as $key => $value ) {
            $locale[ $key ]['company'] = [
                'required'      => true,
                'hidden'        => false
            ];
        }
    }
    return $locale;
}


add_filter( 'woocommerce_checkout_fields' , 'meshulam_customise_checkout_field' );
function meshulam_customise_checkout_field( $fields ) {

    $is_company_name_enabled = get_option('checkout_company_name');
    $is_id_or_company_number_enabled = get_option('checkout_id_or_company_number');

    if( $is_company_name_enabled ){
        if (isset($fields['billing']['billing_company'])) {
            // Make sure the field is enabled and visible
            $fields['billing']['billing_company']['required'] = true;
            $fields['billing']['billing_company']['class'] = ['form-row-wide'];
            $fields['billing']['billing_company']['label'] = __('Company Name', 'woocommerce');
            $fields['billing']['billing_company']['priority'] = 25; // controls position
        } else {
            // If for some reason it doesn’t exist, create it
            $fields['billing']['billing_company'] = [
                'type'     => 'text',
                'label'    => __('Company Name', 'woocommerce'),
                'required' => true,
                'class'    => ['form-row-wide'],
                'priority' => 25,
            ];
        }
    }

    if( $is_id_or_company_number_enabled ){
        $fields['billing']['billing_id_or_company_number'] = [
            'type'     => 'text',
            'label'    => __('ID/Company Number', 'meshulam-payment-gateway'),
            'required' => true,
            'class'    => ['form-row-wide'],
            'priority' => 26,
        ];
    }

    return $fields;
}

// Update custom field data to order
add_action( 'woocommerce_checkout_create_order', 'meshulam_save_custom_checkout_fields', 10, 2 );
function meshulam_save_custom_checkout_fields( $order, $data ) {
    if ( isset( $_POST['billing_id_or_company_number'] ) ) {
        $order->update_meta_data(
            '_billing_id_or_company_number',
            sanitize_text_field( $_POST['billing_id_or_company_number'] )
        );
    }
}

add_action( 'woocommerce_set_additional_field_value', function ( $key, $value, $group, $order_object ) {
    if ( 'company/id' !== $key ) {
        return;
    }
    $order_object->update_meta_data( '_billing_id_or_company_number', $value, true );
}, 10, 4 );


// Showing the Field in the Admin
add_action( 'woocommerce_admin_order_data_after_billing_address', 'meshulam_show_custom_field_in_admin' );
function meshulam_show_custom_field_in_admin( $order ) {
    $id_number = $order->get_meta( '_billing_id_or_company_number' );
    $block_id_number = $order->get_meta('_wc_billing/company/id');
    if ( $id_number && !$block_id_number ) {
        echo '<p><strong>' . __( 'ID/Company Number', 'meshulam-payment-gateway' ) . ':</strong> ' . esc_html( $id_number ) . '</p>';
    }
}

// Add custom billing field to WooCommerce emails
add_filter( 'woocommerce_email_order_meta_fields', 'meshulam_add_custom_field_to_emails', 10, 3 );
function meshulam_add_custom_field_to_emails( $fields, $sent_to_admin, $order ) {
    $id_number = $order->get_meta( '_billing_id_or_company_number' );

    if ( ! empty( $id_number ) ) {
        $fields['billing_id_or_company_number'] = array(
            'label' => __( 'ID/Company Number', 'meshulam-payment-gateway' ),
            'value' => $id_number,
        );
    }

    return $fields;
}


add_action( 'woocommerce_after_checkout_validation', 'meshulam_validate_custom_checkout_fields', 10, 2 );
function meshulam_validate_custom_checkout_fields( $fields, $errors ){
    $is_id_or_company_number_enabled = get_option('checkout_id_or_company_number');
    if( $is_id_or_company_number_enabled ){
        $id_number = trim( $_POST['billing_id_or_company_number'] );

        if( $id_number !== '' && ! preg_match( '/^[0-9]{8,10}$/', $id_number ) ) {
            $errors->add( 'billing_id_or_company_number', __('Please enter a valid ID/Company Number (8–10 digits).', 'meshulam-payment-gateway'), array( 'id' => 'billing_id_or_company_number' ) );
        }
    }
}