<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Dummy Payments Blocks integration
 *
 * @since 1.0.3
 */
final class WC_Meshulam_Wallet_Gateway_Blocks_Support extends AbstractPaymentMethodType {

	/**
	 * The gateway instance.
	 *
	 * @var WC_BitPay_Meshulam_Gateway
	 */
	private $gateway;

	/**
	 * Payment method name/id/slug.
	 *
	 * @var string
	 */
	protected $name = 'grow-wallet-payment';

	/**
	 * Initializes the payment method type.
	 */
	public function initialize() {
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = $gateways[ $this->name ];
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		return $this->gateway->is_available();
	}

	/**
	 * Returns an array of scripts/handles to be registered for this payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		$script_path       = 'build/wallet_block.js';
		$script_asset_path = MESHULAM_PLUGIN_DIR . 'wallet_block.asset.php';
		$script_asset      = file_exists( $script_asset_path )
			? require( $script_asset_path )
			: array(
				'dependencies' => array(),
				'version'      => MESHULAM_VERSION
			);

		$script_url        = MESHULAM_PLUGIN_URL . $script_path;

		wp_register_script(
			'wc-'.$this->name.'-blocks',
			$script_url,
			$script_asset[ 'dependencies' ],
			$script_asset[ 'version' ],
			true
		);

		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( 'wc-'.$this->name.'-blocks', 'meshulam-payment-gateway', WC_Meshulam::plugin_abspath() . 'languages/' );
		}

		return [ 'wc-'.$this->name.'-blocks' ];
	}

	/**
	 * Returns an array of key=>value pairs of data made available to the payment methods script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {

		ob_start();
		$this->gateway->payment_fields();
		$payment_fields = ob_get_clean();

		$pay_list = $this->gateway->sdk_payment_list;
		$all_pay_list = $this->gateway->sdk_payment_list_options;
		$pay_list = array_values(array_intersect($pay_list, array_keys($all_pay_list)));

		$icon   = '<div class="wallet_icon_wrapp">';

		if( in_array('sdk_apple', $pay_list)){
			$icon  .= '<div class="icon_box"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/wallet_apple.png" alt="apple" class="wallet_apple" /></div>';
		}

		if( in_array('sdk_google', $pay_list)){
			$icon  .= '<div class="icon_box"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/wallet_google.png" alt="google" class="wallet_google" /></div>';
		}

		if( in_array('sdk_bit', $pay_list)){
			$icon  .= '<div class="icon_box"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/wallet_bit.png" alt="bit" class="wallet_bit" /></div>';
		}
		if( in_array('sdk_credit_card', $pay_list)){
			$icon  .= '<div class="icon_box"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/wallet_master.png" alt="master" class="wallet_master" /></div>';
			$icon  .= '<div class="icon_box"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/wallet_visa.png" alt="visa" class="wallet_visa" /></div>';
		}

		if( in_array('sdk_bank_transfer', $pay_list)){
			$icon  .= '<div class="icon_box"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/wallet_bank.png" alt="bank transfer" class="wallet_bank" /></div>';
		}

		if( in_array('sdk_pay_box', $pay_list)){
			$icon  .= '<div class="icon_box"><img src="' . MESHULAM_PLUGIN_URL . 'assets/images/wallet_paybox.png" alt="pay box" class="wallet_paybox" /></div>';
		}

		$icon  .= '</div>';

		return [
			'icon'				=> $icon,
			'name'				=> $this->name,
			'title'       		=> $this->gateway->title,
			'description' 		=> $this->gateway->description_payer,
			'button_title' 		=> $this->gateway->pay_title,
			'supports'    		=> array_filter( $this->gateway->supports, [ $this->gateway, 'supports' ] ),
			'ajax_url'			=> admin_url( 'admin-ajax.php' ),
			'mode'				=> ($this->gateway->api_test_mode == 'yes') ? 'DEV' : 'PRODUCTION',
			'payment_fields' 	=> $payment_fields,
		];
	}
}
