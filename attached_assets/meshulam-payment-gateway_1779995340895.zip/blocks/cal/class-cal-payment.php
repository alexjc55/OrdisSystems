<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Dummy Payments Blocks integration
 *
 * @since 1.0.3
 */
final class WC_Cal_Meshulam_Gateway_Blocks_Support extends AbstractPaymentMethodType {

	/**
	 * The gateway instance.
	 *
	 * @var WC_BitPay_Meshulam_Gateway
	 */
	private $gateway;

	/**
	 * Payment method name/id/slug.
	 *
	 * @var string
	 */
	protected $name = 'cal-payment';

	/**
	 * Initializes the payment method type.
	 */
	public function initialize() {
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = $gateways[$this->name];
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		return $this->gateway->is_available();
	}

	/**
	 * Returns an array of scripts/handles to be registered for this payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		$script_path       = 'build/cal_block.js';
		$script_asset_path = MESHULAM_PLUGIN_DIR . 'cal_block.asset.php';
		$script_asset      = file_exists( $script_asset_path )
			? require( $script_asset_path )
			: array(
				'dependencies' => array(),
				'version'      => MESHULAM_VERSION
			);

		$script_url        = MESHULAM_PLUGIN_URL . $script_path;

		wp_register_script(
			'wc-'.$this->name.'-blocks',
			$script_url,
			$script_asset[ 'dependencies' ],
			$script_asset[ 'version' ],
			true
		);

		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( 'wc-'.$this->name.'-blocks', 'meshulam-payment-gateway', WC_Meshulam::plugin_abspath() . 'languages/' );
		}

		return [ 'wc-'.$this->name.'-blocks' ];
	}

	/**
	 * Returns an array of key=>value pairs of data made available to the payment methods script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		return [
			'icon'			=> $this->gateway->icon,
			'name'			=> $this->name,
			'title'       	=> $this->gateway->title,
			'description' 	=> $this->gateway->description,
			'button_title' 	=> $this->gateway->cal_pay_title,
			'supports'    	=> array_filter( $this->gateway->supports, [ $this->gateway, 'supports' ] ),
			'ajax_url'		=> admin_url( 'admin-ajax.php' ),
		];
	}
}
